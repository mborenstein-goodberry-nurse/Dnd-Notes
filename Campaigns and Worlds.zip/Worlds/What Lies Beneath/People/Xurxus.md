---
type: Creature
subtype: NPC
date: 10-23-2026
world: What Lies Beneath
campaigns:
  - What Lies Beneath
status: Alive
statusAsOf: "[[Campaigns/What Lies Beneath/Session Journal/Session 0|Session 0]]"
attitude: Unknown
location: "[[Xurxus's Capital]]"
home: "[[Xurxus's Capital]]"
origin: Unknown
affiliations:
  - organization: "[[Church of Xurxus]]"
    status: Active
    certainty: Confirmed
    role: Deity and central authority
relations:
  - person: "[[Phoerah]]"
    type: Friend
    certainty: Confirmed
  - person: "[[Nexalus]]"
    type: Friend
    certainty: Confirmed
  - person: "[[Kiara Bashara]]"
    type: Patron deity
    certainty: Confirmed
  - person: "[[Revelar]]"
    type: Patron deity
    certainty: Confirmed
  - person: "[[Darian Pageweather]]"
    type: Follower
    certainty: Confirmed
aliases: []
summary: God of balance and planar balance; leads a church-centered mountain polity and commissioned the recovery of a stolen artifact.
portrait:
tags: []
---

# Xurxus

> [!fas-infobox|right] ✧ NPC Overview
> ```dataviewjs
> const portrait = dv.current().portrait;
> if (portrait) {
>   const path = typeof portrait === "string"
>     ? portrait.replace(/^\[\[|\]\]$/g, "")
>     : portrait.path;
>   const file = app.metadataCache.getFirstLinkpathDest(path, dv.current().file.path);
>   if (file) {
>     const img = dv.el("img", "", {
>       attr: { src: app.vault.getResourcePath(file), alt: dv.current().file.name }
>     });
>     img.style.width = "100%";
>     img.style.maxHeight = "260px";
>     img.style.objectFit = "contain";
>   }
> }
> ```
> *`=this.summary`*
> 
> **Status:** `INPUT[inlineSelect(option(Unknown), option(Alive), option(Dead), option(Missing), option(Presumed Dead)):status]`
>
> **Status As Of:** `=this.statusAsOf`
>
> **Attitude**: `INPUT[inlineSelect(option(Unknown), option(Helpful), option(Friendly), option(Indifferent), option(Mixed), option(Unhelpful), option(Hostile)):attitude]`
>
> **Last Known Location:** `=this.location`
>
> **Aliases:** `INPUT[inlineList:aliases]`

## Description

**Xurxus** is a physically present god associated with **balance and planar balance**. His mountain realm is governed through a **church structure**, rather than a conventional monarchy. The name of its high mountain capital may be **Xurxus’ Peak**, but this is not confirmed.

Xurxus is close friends with [[Phoerah]] and [[Nexalus]]; the three gods visit one another frequently (confirmed by the DM between sessions).

Xurxus is revered by [[Kiara Bashara]] and [[Revelar]]. He personally summoned them to recover a stolen artifact whose misuse could have dire consequences. The artifact’s identity, powers, and thief remain unknown.


## Relationships & Affiliations
```dataviewjs
const current = dv.current();
const affiliations = current.affiliations ?? [];

if (affiliations.length) {
    dv.table(
        ["Organization", "Status", "Certainty", "Role"],
        affiliations.map(a => [
            a.organization ?? "-",
            a.status ?? "Unknown",
            a.certainty ?? "Unknown",
            a.role || "-"
        ])
    );
}
```
```dataviewjs
const current = dv.current();
const relations = current.relations ?? [];

if (relations.length) {
    dv.header(3, "Known Personal Relationships");

    dv.table(
        ["Person", "Relationship", "Certainty"],
        relations.map(r => [
            r.person ?? "-",
            r.type ?? "Unknown",
            r.certainty ?? "Unknown"
        ])
    );
}
```
```dataviewjs
const current = dv.current();

const worldPeople = dv.pages(`"Worlds/${current.world}/People"`);

const partyMembers = dv.pages('"Campaigns"')
    .where(p =>
        p.type === "Creature" &&
        p.subtype === "PC" &&
        p.world === current.world
    );

const people = [...worldPeople, ...partyMembers]
    .filter(p =>
        p.type === "Creature" &&
        ["NPC", "PC"].includes(p.subtype) &&
        p.file.path !== current.file.path
    );

const incoming = [];

for (const person of people) {
    for (const relation of person.relations ?? []) {
        const target = relation.person;
        if (!target) continue;

        const matches =
            target.path === current.file.path ||
            String(target) === current.file.name ||
            String(target) === `[[${current.file.name}]]`;

        if (matches) {
            incoming.push({
                person: person.file.link,
                type: relation.type ?? "Unknown",
                certainty: relation.certainty ?? "Unknown"
            });
        }
    }
}

if (incoming.length) {
    incoming.sort((a, b) =>
        a.person.path.localeCompare(b.person.path)
    );

    dv.header(3, "Referenced By");

    dv.table(
        ["Person", "Their Relationship", "Certainty"],
        incoming.map(r => [
            r.person,
            r.type,
            r.certainty
        ])
    );
}
```


## Related Quests
```dataviewjs
const current = dv.current();

// Search quests across campaigns.
const quests = dv.pages('"Campaigns"')
    .where(q =>
        q.type === "Quest" &&
        q.world === current.world
    );

// Normalize arrays, Dataview DataArrays, and single values.
function toArray(value) {
    if (value == null) return [];
    if (Array.isArray(value)) return value;
    if (typeof value.array === "function") return value.array();
    return [value];
}

// Resolve a wikilink or Dataview link to its actual file.
function resolveFile(value, sourcePath) {
    if (!value) return null;

    const raw = value.path
        ? value.path
        : String(value)
            .replace(/^!?\[\[|\]\]$/g, "")
            .split("|")[0];

    return app.metadataCache.getFirstLinkpathDest(
        raw,
        sourcePath
    );
}

const results = [];

for (const quest of quests) {
    const roles = [];

    // Check whether this NPC is the quest giver.
    const giver = resolveFile(
        quest.questGiver,
        quest.file.path
    );

    if (giver?.path === current.file.path) {
        roles.push("Quest Giver");
    }

    // Check general quest involvement.
    const involved = toArray(quest.people).some(value => {
        const file = resolveFile(value, quest.file.path);
        return file?.path === current.file.path;
    });

    if (involved && !roles.includes("Quest Giver")) {
        roles.push("Involved");
    }

    if (roles.length) {
        results.push({
            quest: quest.file.link,
            campaign: quest.campaign ?? "-",
            involvement: roles.join(", "),
            status: quest.status ?? "Unknown"
        });
    }
}

if (results.length) {
    results.sort((a, b) =>
        String(a.campaign).localeCompare(String(b.campaign)) ||
        a.quest.path.localeCompare(b.quest.path)
    );

    dv.table(
        ["Quest", "Campaign", "Involvement", "Status"],
        results.map(r => [
            r.quest,
            r.campaign,
            r.involvement,
            r.status
        ])
    );
}
```
```dataviewjs
const current = dv.current();

const matchesLink = (value, target) => {
    if (!value) return false;

    if (value.path) {
        const resolved = dv.page(value.path);
        return resolved?.file.path === target.file.path ||
               value.path === target.file.path;
    }

    const name = String(value)
        .replace(/^\[\[/, "")
        .replace(/\]\]$/, "")
        .split("|")[0];

    const resolved = dv.page(name);

    return resolved?.file.path === target.file.path ||
           name === target.file.name ||
           name === target.file.path;
};

const mysteries = dv.pages('"Campaigns"')
    .where(m =>
        m.type === "Mystery" &&
        Array.from(m.people ?? [])
            .some(person => matchesLink(person, current))
    )
    .sort(m => m.file.name, "asc");

if (mysteries.length) {
    dv.header(2, "Related Mysteries");

    dv.table(
        ["Mystery", "Campaign", "Status"],
        mysteries.map(m => [
            m.file.link,
            m.campaign ?? "-",
            m.status ?? "Unknown"
        ])
    );
}
```


- **[[Kiara Bashara]]:** Devout Redemption Paladin chosen for the artifact recovery mission.
- **[[Revelar]]:** Follower of Xurxus who describes himself as the council or church’s “viper.”
- **[[Phoerah]] and [[Nexalus]]:** Close friends who visit one another frequently.
- **[[Church of Xurxus]]:** The institution through which his realm is governed. The church’s past treatment of Shayann does **not** establish Xurxus’s personal knowledge or approval.

## Campaign History & Knowledge

### Before Session 1
- Personally tasked Kiara and Revelar with retrieving a stolen artifact.
- Directed the search toward the Keeper of Knowledge in [[Stal'hgite]], beginning at a local tavern.

### Questions to follow
- What is the artifact, and why is it dangerous?
- What authority does Xurxus exercise directly versus through his church?
- Did Xurxus know of the priest’s actions or [[Shayann]]’s banishment?


## Additional Details

### Unconfirmed details
- The capital’s name may be **Xurxus’ Peak**.
- Whether Xurxus defeated the invading dragons alone or with allies is unknown.

### Historical lore
Xurxus is credited with defeating dragons that attempted to conquer the world. Their remains and ruins are associated with the great southwestern crater; the date and circumstances are not established.


> [!warning]- ✧ Out-of-Character Knowledge
> *Player-only information. Record the source of each revelation and do not treat it as party knowledge.*

