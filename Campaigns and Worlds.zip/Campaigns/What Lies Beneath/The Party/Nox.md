---
type: Creature
subtype: PC
date: 10-23-2026
campaign: What Lies Beneath
world: What Lies Beneath
player: Vanessa
race: "[[Genasi (Water)|Water Genasi]]"
class: "[[Sorcerer]] ([[Storm Sorcery|Storm Sorcerer]])"
level: 5
status: Active
statusAsOf: "[[The Things That Haunt Us]]"
home:
location: "[[The Wasteland]]"
affiliations: []
relations: []
aliases: []
summary:
image:
tags: []
---
# Nox

> [!fas-infobox] ✧ Party Member Overview
> **Player:** `VIEW[{player}]`
>
> **Race:** `=this.race`
>
> **Class:** `=this.class`
>
> **Level:** `VIEW[{level}]`
>
> **Status:** `VIEW[{status}]`
>
> **Home:** `=this.home`
>
> **Last Known Location:** `=this.location`

## Description

Nox is a quiet, androgynous [[Genasi (Water)|water genasi]] [[Sorcerer]] with a seafaring background. They first appeared at the Leaky Tights, listening to the discussion surrounding the artifact mission before following the group to the Keeper of Knowledge's library. Their physical appearance beyond their water-genasi heritage has not yet been described in detail.

## Background & History

Nox has a history as a pirate and recalled having brought a ship to the region near the orc lands before. The identity of their crew, their home, and their reasons for seeking the artifact are not yet known. Their heritage alone does not establish a connection to the [[Seas of Stormglade]].

## Personality & Motivations

Nox initially presented as quiet, watchful, and curious. They showed particular interest in the strong magical energies within [[Darian Pageweather]]'s private chamber. Revelar's suspicion of Nox led to a tense encounter at the library, but the situation was defused. Their personal ambitions and loyalties remain unclear.

## Relationships & Affiliations
```dataviewjs
const current = dv.current();
const affiliations = current.affiliations ?? [];

if (affiliations.length) {
    dv.table(
        ["Organization", "Status", "Certainty", "Role"],
        affiliations.map(a => [
            a.organization ?? "-",
            a.status ?? "Unknown",
            a.certainty ?? "Unknown",
            a.role || "-"
        ])
    );
}
```
```dataviewjs
const current = dv.current();
const relations = current.relations ?? [];

if (relations.length) {
    dv.header(3, "Known Personal Relationships");

    dv.table(
        ["Person", "Relationship", "Certainty"],
        relations.map(r => [
            r.person ?? "-",
            r.type ?? "Unknown",
            r.certainty ?? "Unknown"
        ])
    );
}
```
```dataviewjs
const current = dv.current();

const worldPeople = dv.pages(`"Worlds/${current.world}/People"`);

const partyMembers = dv.pages('"Campaigns"')
    .where(p =>
        p.type === "Creature" &&
        p.subtype === "PC" &&
        p.world === current.world
    );

const people = [...worldPeople, ...partyMembers]
    .filter(p =>
        p.type === "Creature" &&
        ["NPC", "PC"].includes(p.subtype) &&
        p.file.path !== current.file.path
    );

const incoming = [];

for (const person of people) {
    for (const relation of person.relations ?? []) {
        const target = relation.person;
        if (!target) continue;

        const matches =
            target.path === current.file.path ||
            String(target) === current.file.name ||
            String(target) === `[[${current.file.name}]]`;

        if (matches) {
            incoming.push({
                person: person.file.link,
                type: relation.type ?? "Unknown",
                certainty: relation.certainty ?? "Unknown"
            });
        }
    }
}

if (incoming.length) {
    incoming.sort((a, b) =>
        a.person.path.localeCompare(b.person.path)
    );

    dv.header(3, "Referenced By");

    dv.table(
        ["Person", "Their Relationship", "Certainty"],
        incoming.map(r => [
            r.person,
            r.type,
            r.certainty
        ])
    );
}
```
```dataviewjs
const current = dv.current();

// Search quests across campaigns.
const quests = dv.pages('"Campaigns"')
    .where(q =>
        q.type === "Quest" &&
        q.world === current.world
    );

// Normalize arrays, Dataview DataArrays, and single values.
function toArray(value) {
    if (value == null) return [];
    if (Array.isArray(value)) return value;
    if (typeof value.array === "function") return value.array();
    return [value];
}

// Resolve a wikilink or Dataview link to its actual file.
function resolveFile(value, sourcePath) {
    if (!value) return null;

    const raw = value.path
        ? value.path
        : String(value)
            .replace(/^!?\[\[|\]\]$/g, "")
            .split("|")[0];

    return app.metadataCache.getFirstLinkpathDest(
        raw,
        sourcePath
    );
}

const results = [];

for (const quest of quests) {
    const roles = [];

    // Check whether this Character is the quest giver.
    const giver = resolveFile(
        quest.questGiver,
        quest.file.path
    );

    if (giver?.path === current.file.path) {
        roles.push("Quest Giver");
    }

    // Check general quest involvement.
    const involved = toArray(quest.people).some(value => {
        const file = resolveFile(value, quest.file.path);
        return file?.path === current.file.path;
    });

    if (involved && !roles.includes("Quest Giver")) {
        roles.push("Involved");
    }

    if (roles.length) {
        results.push({
            quest: quest.file.link,
            campaign: quest.campaign ?? "-",
            involvement: roles.join(", "),
            status: quest.status ?? "Unknown"
        });
    }
}

if (results.length) {
    dv.header(2, "Related Quests");

    results.sort((a, b) =>
        String(a.campaign).localeCompare(String(b.campaign)) ||
        a.quest.path.localeCompare(b.quest.path)
    );

    dv.table(
        ["Quest", "Campaign", "Involvement", "Status"],
        results.map(r => [
            r.quest,
            r.campaign,
            r.involvement,
            r.status
        ])
    );
}
```
```dataviewjs
const current = dv.current();

const matchesLink = (value, target) => {
    if (!value) return false;

    if (value.path) {
        const resolved = dv.page(value.path);
        return resolved?.file.path === target.file.path ||
               value.path === target.file.path;
    }

    const name = String(value)
        .replace(/^\[\[/, "")
        .replace(/\]\]$/, "")
        .split("|")[0];

    const resolved = dv.page(name);

    return resolved?.file.path === target.file.path ||
           name === target.file.name ||
           name === target.file.path;
};

const mysteries = dv.pages('"Campaigns"')
    .where(m =>
        m.type === "Mystery" &&
        Array.from(m.people ?? [])
            .some(person => matchesLink(person, current))
    )
    .sort(m => m.file.name, "asc");

if (mysteries.length) {
    dv.header(2, "Related Mysteries");

    dv.table(
        ["Mystery", "Campaign", "Status"],
        mysteries.map(m => [
            m.file.link,
            m.campaign ?? "-",
            m.status ?? "Unknown"
        ])
    );
}
```


## Campaign History & Knowledge

### Session 1 — [[Leaky Tights to Freaky Fights]]
Nox overheard the group's conversation at the Leaky Tights and followed the others to the library. There, they were drawn to the intense magic in Darian's chamber and became the target of [[Revelar]]'s suspicion when he raised a crossbow toward them. After the confrontation subsided, Nox joined the expedition. They recognized the region near the goblin cave from an earlier voyage.

Nox participated in the party's exploration of the cave and the confrontation surrounding the artifact. After the appearance of the many-faced aberration, they were among the adventurers who pursued it and experienced the apparent displacement to an unfamiliar wasteland.

### Session 2 — [[The Things That Haunt Us]]
Nox noticed that everyone else had become unresponsive during the Wasteland journey and attempted to move ahead before blacking out. Her vision took place aboard her ship during a storm. She recognized a scream as belonging to her **Captain**, and discovered a many-eyed, multi-mouthed sea monster attacking the crew and holding the captain in a tentacle. She used [[Detect Magic]], which did not indicate unusual magic on the monster within the vision. She severed the grasping tentacles with [[Ice Knife]], freed her captain, and finished the creature with a firearm; it sank and dissolved into mist. The ichor it produced resembled the Wasteland's, but its independent existence is unconfirmed.

## Additional Details

- **Still unknown:** Nox's crew, origins, personal objectives, and any connection to the artifact beyond joining the expedition.
- **Do not assume:** Being a water genasi does not by itself mean Nox is from Stormglade.

**Follow-up:** Who is Catherine and what is her role aboard Nox's ship? Was any of the vision based on an actual encounter? Do not infer that the sea creature or crew casualties happened in real history.

