---
aliases:
---
**Class**: [[Rogue]] 

**_Many rogues walk a fine line between life and death, risking their own lives and taking the lives of others. While adventuring on that line, some rogues discover a mystical connection to death itself. These rogues take knowledge from the dead and become immersed in negative energy, eventually becoming like ghosts. Thieves' guilds value them as highly effective information gatherers and spies._**

**_Many shadar-kai of the Shadowfell are masters of these macabre techniques, and some are willing to teach this path. In places like Thay in the Forgotten Realms and Karrnath in Eberron, where many necromancers practice their craft, a Phantom can become a wizard's confidant and right hand. In temples of gods of death, the Phantom might work as an agent to track down those who try to cheat death and to recover knowledge that might otherwise be lost to the grave._**

**_How did you discover this grim power? Did you sleep in a graveyard and awaken to your new abilities? Or did you cultivate them in a temple or thieves' guild dedicated to a deity of death?_**

Source: Tasha's Cauldron of Everything

### Whispers of the Dead

When you choose this archetype at 3rd level, echoes of those who have died cling to you. Whenever you finish a [[Short Rest|short]] or [[Long Rest]], you can gain one skill or tool proficiency of your choice, as a ghostly presence shares its knowledge with you. You lose this proficiency when you use this feature to choose a different proficiency that you lack.

### Wails from the Grave

At 3rd level, as you nudge someone closer to the grave, you can channel the power of death to harm someone else as well. Immediately after you deal your [[Rogue#Sneak Attack|Sneak Attack]] damage to a creature on your turn, you can target a second creature that you can see within **30 feet** of the first creature. Roll **half** the number of Sneak Attack dice for your level (**round up**), and the second creature takes [[Necrotic]] damage equal to the roll's total, as wails of the dead sound around them for a moment.

You can use this feature a number of times equal to your [[Proficiency Bonus]], and you regain all expended uses when you finish a [[Long Rest]].

### Tokens of the Departed

At 9th level, when a life ends in your presence, you're able to snatch a token from the departing soul, a sliver of its life essence that takes physical form: as a [[Reaction]] when a creature you can see dies within **30 feet** of you, you can open your free hand and cause a Tiny trinket to appear there, a soul trinket. The DM determines the trinket's form or has you roll on the Trinkets table in the _Player's Handbook_ to generate it.

You can have a maximum number of soul trinkets equal to your [[Proficiency Bonus]], and you can't create one while at your maximum.

You can use soul trinkets in the following ways:

- While a soul trinket is on your person, you have [[Advantage]] on [[Death Saving Throw|Death Saving Throws]] and **[[Constitution]] saving throws**, for your vitality is enhanced by the life essence within the object.

- When you deal [[Rogue#Sneak Attack]] damage on your turn, you can destroy one of your soul trinkets that's on your person and then immediately use [[#Wails from the Grave]], without expending a use of that feature.

- As an [[Action]], you can destroy one of your soul trinkets, no matter where it's located. When you do so, you can ask the spirit associated with the trinket one question. The spirit appears to you and answers in a language it knew in life. It's under no obligation to be truthful, and it answers as concisely as possible, eager to be free. The spirit knows only what it knew in life, as determined by the DM.

### Ghost Walk

At 13th level, you can phase partially into the realm of the dead, becoming like a ghost. As a [[Bonus Action]], you assume a spectral form. While in this form, you have a flying speed of 10 feet, you can hover, and attack rolls have [[Disadvantage]] against you. You can also move through creatures and objects as if they were [[Difficult Terrain]], but you take **1d10 [[Force]]** damage if you end your turn inside a creature or an object.

You stay in this form for **10 minutes** or until you end it as a [[Bonus Action]]. To use this feature again, you must finish a [[Long Rest]] or destroy one of your soul trinkets as part of the [[Bonus Action]] you use to activate Ghost Walk.

### Death's Friend

At 17th level, your association with death has become so close that you gain the following benefits:

- When you use your [[#Wails from the Grave]], you can now deal the [[Necrotic]] damage to both the first and the second creature.

- At the end of a [[Long Rest]], a soul trinket appears in your hand if you don't have any soul trinkets, as the spirits of the dead are drawn to you.