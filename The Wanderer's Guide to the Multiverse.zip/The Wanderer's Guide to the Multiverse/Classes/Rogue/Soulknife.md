---
aliases:
---
**Class**: [[Rogue]] 

**_Most assassins strike with physical weapons, and many burglars and spies use thieves' tools to infiltrate secure locations. In contrast, a Soulknife strikes and infiltrates with the mind, cutting through barriers both physical and psychic. These rogues discover psionic power within themselves and channel it to do their roguish work. They find easy employment as members of thieves' guilds, though they are often mistrusted by rogues who are leery of anyone using strange mind powers to conduct their business. Most governments would also be happy to employ a Soulknife as a spy._**

**_Amid the trees of ancient forests on the Material Plane and in the Feywild, some wood elves walk the path of the Soulknife, serving as silent, lethal guardians of their woods. In the endless war among the gith, a githzerai is encouraged to become a Soulknife when stealth is required against the githyanki foe._**

**_As a Soulknife, your psionic abilities might have haunted you since you were a child, only revealing their full potential as you experienced the stress of adventure. Or you might have sought out a reclusive order of psychic adepts and spent years learning how to manifest your power._**

Source: Tasha's Cauldron of Everything

### Psionic Power

Starting at 3rd level, you harbor a wellspring of psionic energy within yourself. This energy is represented by your Psionic Energy dice, which are each a **d6**. You have a number of these dice equal to **twice** your [[Proficiency Bonus]], and they fuel various psionic powers you have, which are detailed below.

Some of your powers expend the Psionic Energy die they use, as specified in a power's description, and you can't use a power if it requires you to use a die when your dice are all expended. You regain all your expended Psionic Energy dice when you finish a [[Long Rest]]. In addition, as a [[Bonus Action]], you can regain one expended Psionic Energy die, but you can't do so again until you finish a [[Short Rest|short]] or [[Long Rest]].

When you reach certain levels in this class, the size of your Psionic Energy dice increases: at 5th level (**d8**), 11th level (**d10**), and 17th level (**d12**).

The powers below use your Psionic Energy dice.

**_Psi-Bolstered Knack._** When your nonpsionic training fails you, your psionic power can help: if you fail an ability check using a skill or tool with which you have proficiency, you can roll one Psionic Energy die and add the number rolled to the check, potentially turning failure into success. You expend the die only if the roll succeeds.

**_Psychic Whispers._** You can establish telepathic communication between yourself and others — perfect for quiet infiltration. As an [[Action]], choose one or more creatures you can see, up to a number of creatures equal to your [[Proficiency Bonus]], and then roll one Psionic Energy die. For a number of hours equal to the number rolled, the chosen creatures can speak telepathically with you, and you can speak telepathically with them. To send or receive a message (no action required), you and the other creature must be within **1 mile** of each other. A creature can't use this telepathy if it can't speak any languages, and a creature can end the telepathic connection at any time (no action required). You and the creature don't need to speak a common language to understand each other.

The first time you use this power after each [[Long Rest]], you don't expend the Psionic Energy die. All other times you use the power, you expend the die.

### Psychic Blades

Also at 3rd level, You can manifest your psionic power as shimmering blades of psychic energy. Whenever you take the [[Attack]] action, you can manifest a psychic blade from your free hand and make the attack with that blade. This magic blade is a [[Simple Melee Weapon]] with the [[Finesse]] and [[Thrown]] properties. It has a normal range of **60 feet** and no long range, and on a hit, it deals [[Psychic]] damage equal to **1d6** plus the ability modifier you used for the attack roll. The blade vanishes immediately after it hits or misses its target, and it leaves no mark on its target if it deals damage.

After you attack with the blade, you can make a melee or ranged weapon attack with a second psychic blade as a [[Bonus Action]] on the same turn, provided your other hand is free to create it. The damage die of this bonus attack is **1d4**, instead of **1d6**.

### Soul Blades

Starting at 9th level, your Psychic Blades are now an expression of your psi-suffused soul, giving you these powers that use your Psionic Energy dice:

**_Homing Strikes._** If you make an attack roll with your [[#Psychic Blades]] and miss the target, you can roll one Psionic Energy die and add the number rolled to the attack roll. If this causes the attack to hit, you expend the Psionic Energy die.

**_Psychic Teleportation._** As a [[Bonus Action]], you manifest one of your [[#Psychic Blades]], expend one Psionic Energy die and roll it, and throw the blade at an unoccupied space you can see, up to a number of feet away equal to **10 times the number rolled**. You then teleport to that space, and the blade vanishes.

### Psychic Veil

At 13th level, you can weave a veil of psychic static to mask yourself. As an [[Action]], you can magically become [[Invisible]], along with anything you are wearing or carrying, for **1 hour** or until you dismiss this effect (no action required). This invisibility ends early immediately after you deal damage to a creature, or you force a creature to make a saving throw.

Once you use this feature, you can't do so again until you finish a [[Long Rest]], unless you expend a Psionic Energy die to use this feature again.

### Rend Mind

When you reach 17th level, you can sweep your [[#Psychic Blades]] directly through a creature's mind. When you use your Psychic Blades to deal [[Rogue#Sneak Attack|Sneak Attack]] damage to a creature, you can force that target to make a **[[Wisdom]] saving throw** (DC equal to 8 + your [[Proficiency Bonus]] + your [[Dexterity]] modifier). If the save fails, the target is [[Stunned]] for **1 minute**. The stunned target can repeat the saving throw at the end of each of its turns, ending the effect on itself on a success.

Once you use this feature, you can't do so again until you finish a [[Long Rest]], unless you expend three Psionic Energy dice to use it again.