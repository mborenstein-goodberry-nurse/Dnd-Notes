---
aliases:
---
**Class**: [[Rogue]] 

**_Your focus is on people and on the influence and secrets they have. Many spies, courtiers, and schemers follow this archetype, leading lives of intrigue. Words are your weapons as often as knives or poison, and secrets and favors are some of your favorite treasures._**

Source: Xanathar's Guide to Everything

### Master of Intrigue

When you choose this archetype at 3rd level, you gain proficiency with the [[Disguise Kit]], the [[Forgery Kit]], and one [[Gaming Set]] of your choice. You also learn two [[Languages]] of your choice.

Additionally, you can unerringly mimic the speech patterns and accent of a creature that you hear speak for at least **1 minute**, enabling you to pass yourself off as a native speaker of a particular land, provided that you know the language.

### Master of Tactics
Starting at 3rd level, you can use the [[Help]] action as a [[Bonus Action]]. Additionally, when you use the [[Help]] action to aid an ally in attacking a creature, the target of that attack can be within **30 feet** of you, rather than 5 feet of you, if the target can see or hear you.

### Insightful Manipulator

Starting at 9th level, if you spend at least 1 minute observing or interacting with another creature outside combat, you can learn certain information about its capabilities compared to your own. The DM tells you if the creature is your equal, superior, or inferior in regard to two of the following characteristics of your choice:

- [[Intelligence]] score
- [[Wisdom]] score
- [[Charisma]] score
- Class levels (if any)

At the DM's option, you might also realize you know a piece of the creature's history or one of its personality traits, if it has any.

### Misdirection

Beginning at 13th level, you can sometimes cause another creature to suffer an attack meant for you. When you are targeted by an attack while a creature within **5 feet** of you is granting you cover against that attack, you can use your [[Reaction]] to have the attack target that creature instead of you.

### Soul of Deceit

Starting at 17th level, your thoughts can't be read by telepathy or other means, unless you allow it. You can present false thoughts by making a [[Deception|Charisma (Deception)]] check contested by the mind reader's [[Insight|Wisdom (Insight)]] check.

Additionally, no matter what you say, magic that would determine if you are telling the truth indicates you are being truthful if you so choose, and you can't be compelled to tell the truth by magic.