---
aliases:
---
**Class**: [[Rogue]] 

**_You hone your skills in the larcenous arts. Burglars, bandits, cutpurses, and other criminals typically follow this archetype, but so do rogues who prefer to think of themselves as professional treasure seekers, explorers, delvers, and investigators. In addition to improving your agility and stealth, you learn skills useful for delving into ancient ruins, reading unfamiliar languages, and using magic items you normally couldn't employ._**

Source: Player's Handbook

### Fast Hands

Starting at 3rd level, you can use the [[Bonus Action]] granted by your Cunning Action to make a [[Sleight of Hand|Dexterity (Sleight of Hand)]] check, use your [[Thieves' Tools]] to disarm a trap or open a lock, or take the Use an Object action.

### Second-Story Work

When you choose this archetype at 3rd level, you gain the ability to climb faster than normal; climbing no longer costs you extra movement.

In addition, when you make a running jump, the distance you cover increases by a number of feet equal to your [[Dexterity]] modifier.

### Supreme Sneak

Starting at 9th level, you have [[Advantage]] on a [[Stealth|Dexterity (Stealth)]] check if you move no more than half your speed on the same turn.

### Use Magic Device

By 13th level, you have learned enough about the workings of magic that you can improvise the use of items even when they are not intended for you. You ignore all class, race, and level requirements on the use of magic items.

### Thief's Reflexes

When you reach 17th level, you have become adept at laying ambushes and quickly escaping danger. You can take two turns during the first round of any combat. You take your first turn at your normal [[The Wanderer's Guide to the Multiverse/Gameplay/Initiative]] and your second turn at your [[The Wanderer's Guide to the Multiverse/Gameplay/Initiative]] minus **10**. You can't use this feature when you are [[Surprise|surprised]]. 