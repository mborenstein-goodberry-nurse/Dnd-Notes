---
aliases:
  - Inquisitive Rogue
---
**Class**: [[Rogue]] 

**_As an archetypal Inquisitive, you excel at rooting out secrets and unraveling mysteries. You rely on your sharp eye for detail, but also on your finely honed ability to read the words and deeds of other creatures to determine their true intent. You excel at defeating creatures that hide among and prey upon ordinary folk, and your mastery of lore and your sharp eye make you well equipped to expose and end hidden evils._**

Source: Xanathar's Guide to Everything

### Ear for Deceit

When you choose this archetype at 3rd level, you develop a keen ear for picking out lies. Whenever you make a [[Insight|Wisdom (Insight)]] check to determine whether a creature is lying, treat a roll of **7** or **lower** on the d20 as an **8**.

### Eye for Detail

Starting at 3rd level, you can use a [[Bonus Action]] to make a [[Perception|Wisdom (Perception)]] check to spot a hidden creature or object or to make an [[Investigation|Intelligence (Investigation)]] check to uncover or decipher clues.

### Insightful Fighting

At 3rd level, you gain the ability to decipher an opponent's tactics and develop a counter to them. As a [[Bonus Action]], you make a [[Insight|Wisdom (Insight)]] check against a creature you can see that isn't incapacitated, contested by the target's [[Deception|Charisma (Deception)]] check. If you succeed, you can use your [[Rogue#Sneak Attack|Sneak Attack]] against that target even if you don't have [[Advantage]] on the attack roll, but not if you have [[Disadvantage]] on it.

This benefit lasts for **1 minute** or until you successfully use this feature against a different target.

### Steady Eye

At 9th level, you gain advantage on any [[Perception|Wisdom (Perception)]] or [[Investigation|Intelligence (Investigation)]] check if you move no more than half your speed on the same turn.

### Unerring Eye

At 13th level, your senses are almost impossible to foil. As an [[Action]], you sense the presence of illusions, shapechangers not in their original form, and other magic designed to deceive the senses within **30 feet** of you, provided you aren't [[Blinded]] or [[Deafened]]. You sense that an effect is attempting to trick you, but you gain no insight into what is hidden or into its true nature.

You can use this feature a number of times equal to your [[Wisdom]] modifier (minimum of once), and you regain all expended uses of it when you finish a [[Long Rest]].

### Eye for Weakness

At 17th level, you learn to exploit a creature's weaknesses by carefully studying its tactics and movement. While your Insightful Fighting feature applies to a creature, your [[Rogue#Sneak Attack|Sneak Attack]] damage against that creature increases by **3d6**.