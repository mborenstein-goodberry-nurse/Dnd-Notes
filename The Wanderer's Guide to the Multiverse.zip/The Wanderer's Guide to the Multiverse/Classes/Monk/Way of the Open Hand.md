---
aliases:
  - Open Hand Monk
---
**Class**: [[Monk]] 

**_Monks of the Way of the Open Hand are the ultimate masters of martial arts combat, whether armed or unarmed. They learn techniques to push and trip their opponents, manipulate ki to heal damage to their bodies, and practice advanced meditation that can protect them from harm._**

Source: Player's Handbook

### Open Hand Technique

Starting when you choose this tradition at 3rd level, you can manipulate your enemy's ki when you harness your own. Whenever you hit a creature with one of the attacks granted by your [[Monk#Flurry of Blows|move]], you can impose one of the following effects on that target:

- It must succeed on a **[[Dexterity]] saving throw** or be knocked [[Prone]].

- It must make a **[[Strength]] saving throw**. If it fails, you can push it up to 15 feet away from you.

- It can't take [[Reaction|Reactions]] until the end of your next turn.

### Wholeness of Body

At 6th level, you gain the ability to heal yourself. As an [[Action]], you can regain [[Hit Points]] equal to **three** **times** your monk level. You must finish a [[Long Rest]] before you can use this feature again.

### Tranquility

Beginning at 11th level, you can enter a special meditation that surrounds you with an aura of peace. At the end of a [[Long Rest]], you gain the effect of a [[Sanctuary]] spell that lasts until the start of your next [[Long Rest]] (the spell can end early as normal). The saving throw DC for the spell equals 8 + your **[[Wisdom]] modifier** + your [[Proficiency Bonus]].

### Quivering Palm

At 17th level, you gain the ability to set up lethal vibrations in someone's body. When you hit a creature with an unarmed strike, you can spend 3 ki points to start these imperceptible vibrations, which last for a number of days equal to your monk level. The vibrations are harmless unless you use your action to end them. To do so, you and the target must be on the same plane of existence. When you use this [[Action]], the creature must make a **[[Constitution]] saving throw**. If it fails, it is reduced to 0 hit points. If it succeeds, it takes **10d10 [[Necrotic]]** damage.

You can have only one creature under the effect of this feature at a time. You can choose to end the vibrations harmlessly without using an action.