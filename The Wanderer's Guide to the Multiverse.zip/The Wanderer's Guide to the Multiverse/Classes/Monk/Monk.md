---
aliases:
  - Monks
---
# Monk

### Class Features

As a monk, you gain the following class features.

#### Hit Points

**[[Hit Dice]]:** 1d8 per monk level

**[[Hit Points]] at 1st Level:** 8 + your [[Constitution]] modifier

**[[Hit Points]] at Higher Levels:** 1d8 (or 5) + your [[Constitution]] modifier per monk level after 1st

#### Proficiencies

**Armor:** None

**Weapons:** [[Simple Weapon|Simple Weapons]], shortswords

**Tools:** Choose one type of [[Artisan's Tools]] or one [[Musical Instrument]] 

**Saving Throws:** [[Strength]], [[Dexterity]]

**Skills:** Choose two from [[Acrobatics]], [[Athletics]], [[History]], [[Insight]], [[Religion]], and [[Stealth]]

#### Equipment

You start with the following equipment, in addition to the equipment granted by your background:

- (*a*) a shortsword or (*b*) any [[Simple Weapon]]
- (*a*) a [[Dungeoneer's Pack]] or (*b*) an [[Explorer's Pack]]
- 10 darts

### Monk Table 

| Level | Proficiency Bonus | Martial Arts | Ki Points | Unarmored Movement | Features                                                |
| ----- | ----------------- | ------------ | --------- | ------------------ | ------------------------------------------------------- |
| 1st   | +2                | 1d4          | -         | -                  | [[#Unarmored Defense]], [[#Martial Arts]]               |
| 2nd   | +2                | 1d4          | 2         | +10 ft.            | [[#Ki]], [[#Unarmored Movement]]                        |
| 3rd   | +2                | 1d4          | 3         | +10 ft.            | [[#Monastic Tradition]], [[#Deflect Missiles]]          |
| 4th   | +2                | 1d4          | 4         | +10 ft.            | Ability Score Improvement, Slow Fall                    |
| 5th   | +3                | 1d6          | 5         | +10 ft.            | [[#Extra Attack]], [[#Stunning Strike]]                 |
| 6th   | +3                | 1d6          | 6         | +15 ft.            | [[#Ki-Empowered Strikes]], Monastic Tradition Feature   |
| 7th   | +3                | 1d6          | 7         | +15 ft.            | [[#Evasion]], [[#Stillness of Mind]]                    |
| 8th   | +3                | 1d6          | 8         | +15 ft.            | Ability Score Improvement                               |
| 9th   | +4                | 1d6          | 9         | +15 ft.            | [[#Unarmored Movement\|Unarmored Movement improvement]] |
| 10th  | +4                | 1d6          | 10        | +20 ft.            | [[#Purity of Body]]                                     |
| 11th  | +4                | 1d8          | 11        | +20 ft.            | Monastic Tradition Feature                              |
| 12th  | +4                | 1d8          | 12        | +20 ft.            | Ability Score Improvement                               |
| 13th  | +5                | 1d8          | 13        | +20 ft.            | [[#Tongue of the Sun and Moon]]                         |
| 14th  | +5                | 1d8          | 14        | +25 ft.            | [[#Diamond Soul]]                                       |
| 15th  | +5                | 1d8          | 15        | +25 ft.            | [[#Timeless Body]]                                      |
| 16th  | +5                | 1d8          | 16        | +25 ft.            | Ability Score Improvement                               |
| 17th  | +6                | 1d10         | 17        | +25 ft.            | Monastic Tradition Feature                              |
| 18th  | +6                | 1d10         | 18        | +30 ft.            | [[#Empty Body]]                                         |
| 19th  | +6                | 1d10         | 19        | +30 ft.            | Ability Score Improvement                               |
| 20th  | +6                | 1d10         | 20        | +30 ft.            | [[#Perfect Self]]                                       |
|       |                   |              |           |                    |                                                         |

### Unarmored Defense

Beginning at 1st level, while you are wearing no armor and not wielding a shield, your AC equals 10 + your [[Dexterity]] modifier + your [[Wisdom]] modifier.

### Martial Arts

At 1st level, your practice of martial arts gives you mastery of combat styles that use unarmed strikes and monk weapons, which are shortswords and any [[Simple Melee Weapon|Simple Melee Weapons]] that don't have the [[Two-Handed]] or [[Heavy]] property.

You gain the following benefits while you are unarmed or wielding only monk weapons and you aren't wearing [[Armor]] or wielding a [[The Wanderer's Guide to the Multiverse/Spells/Shield]]:

- You can use [[Dexterity]] instead of [[Strength]] for the attack and damage rolls of your unarmed strikes and monk weapons.
- You can roll a **d4** in place of the normal damage of your unarmed strike or monk weapon. This die changes as you gain monk levels, as shown in the Martial Arts column of the Monk table.
- When you use the [[Attack]] action with an unarmed strike or a monk weapon on your turn, you can make one unarmed strike as a [[Bonus Action]]. For example, if you take the [[Attack]] action and attack with a quarterstaff, you can also make an unarmed strike as a [[Bonus Action]], assuming you haven't already taken a [[Bonus Action]] this turn.

Certain monasteries use specialized forms of the monk weapons. For example, you might use a club that is two lengths of wood connected by a short chain (called a nunchaku) or a sickle with a shorter, straighter blade (called a kama). Whatever name you use for a monk weapon, you can use the game statistics provided for the weapon.

### Ki

Starting at 2nd level, your training allows you to harness the mystic energy of ki. Your access to this energy is represented by a number of ki points. Your monk level determines the number of points you have, as shown in the Ki Points column of the Monk table.

You can spend these points to fuel various ki features. You start knowing three such features: Flurry of Blows, Patient Defense, and Step of the Wind. You learn more ki features as you gain levels in this class.

When you spend a ki point, it is unavailable until you finish a [[Short Rest|short]] or [[Long Rest]], at the end of which you draw all of your expended ki back into yourself. You must spend at least 30 minutes of the rest meditating to regain your ki points.

Some of your ki features require your target to make a saving throw to resist the feature's effects. The saving throw DC is calculated as follows:

**Ki save DC** = 8 + your proficiency bonus + your [[Wisdom]] modifier

#### Flurry of Blows

Immediately after you take the [[Attack]] action on your turn, you can spend 1 ki point to make two unarmed strikes as a [[Bonus Action]].

#### Patient Defense

You can spend 1 ki point to take the [[Dodge]] action as a [[Bonus Action]] on your turn.

#### Step of the Wind

You can spend 1 ki point to take the [[Disengage]] or [[Dash]] action as a [[Bonus Action]] on your turn, and your [[Jumping|Jump]] distance is doubled for the turn.

### Unarmored Movement

Starting at 2nd level, your speed increases by **10 feet** while you are not wearing armor or wielding a shield. This bonus increases when you reach certain monk levels, as shown in the Monk table.

At 9th level, you gain the ability to move along vertical surfaces and across liquids on your turn without falling during the move.

### Monastic Tradition

When you reach 3rd level, you commit yourself to a monastic tradition. Your tradition grants you features at 3rd level and again at 6th, 11th, and 17th level.

| Tradition                       | Source                                                             |
| ------------------------------- | ------------------------------------------------------------------ |
| [[Way of the Astral Self]]      | Tasha's Cauldron of Everything                                     |
| [[Way of the Ascendent Dragon]] | Fizban's Treasury of Dragons                                       |
| [[Way of the Drunken Master]]   | Xanathar's Guide to Everything                                     |
| [[Way of the Four Elements]]    | Player's Handbook                                                  |
| [[Way of the Kensai\|Kensai]]   | Xanathar's Guide to Everything                                     |
| [[Way of the Long Death]]       | Sword Coast Adventurer's Guide                                     |
| [[Way of Mercy]]                | Tasha's Cauldron of Everything                                     |
| [[Way of the Open Hand]]        | Player's Handbook                                                  |
| [[Way of Shadow]]               | Player's Handbook                                                  |
| [[Way of the Sun Soul]]         | Sword Coast Adventurer's Guide  <br>Xanathar's Guide to Everything |

### Deflect Missiles

Starting at 3rd level, you can use your [[Reaction]] to deflect or catch the missile when you are hit by a ranged weapon attack. When you do so, the damage you take from the attack is reduced by 1d10 + your [[Dexterity]] modifier + your monk level.

If you reduce the damage to 0, you can catch the missile if it is small enough for you to hold in one hand and you have at least one hand free. If you catch a missile in this way, you can spend 1 ki point to make a ranged attack with the weapon or piece of ammunition you just caught, as part of the same [[Reaction]]. You make this attack with proficiency, regardless of your weapon proficiencies, and the missile counts as a monk weapon for the attack, which has a normal range of **20 feet** and a long range of **60 feet**.

### Ability Score Improvement

When you reach 4th level, and again at 8th, 12th, 16th, and 19th level, you can increase one ability score of your choice by 2, or you can increase two ability scores of your choice by 1. As normal, you can't increase an ability score above 20 using this feature.

### Slow Fall

Beginning at 4th level, you can use your [[Reaction]] when you fall to reduce any falling damage you take by an amount equal to **five times your monk level**.

### Quickened Healing (Optional)

Also at 4th level, as an [[Action]], you can spend 2 ki points and roll a Martial Arts die. You regain a number of [[Hit Points]] equal to the number rolled plus your [[Proficiency Bonus]].

### Extra Attack

Beginning at 5th level, you can attack twice, instead of once, whenever you take the [[Attack]] action on your turn.

### Stunning Strike

Starting at 5th level, you can interfere with the flow of ki in an opponent's body. When you hit another creature with a melee weapon attack, you can spend 1 ki point to attempt a stunning strike. The target must succeed on a **[[Constitution]] saving throw** or be [[Stunned]] until the end of your next turn.

### Focused Aim (Optional)

Also at 5th level, when you miss with an attack roll, you can spend 1 to 3 ki points to increase your attack roll by 2 for each of these ki points you spend, potentially turning the miss into a hit.

### Ki-Empowered Strikes

Starting at 6th level, your unarmed strikes count as magical for the purpose of overcoming resistance and immunity to nonmagical attacks and damage.

### Evasion

At 7th level, your instinctive agility lets you dodge out of the way of certain area effects, such as a blue dragon's lightning breath or a *[[Fireball]]* spell. When you are subjected to an effect that allows you to make a **[[Dexterity]] saving throw** to take only **half** damage, you instead take **no** damage if you **succeed** on the saving throw, and only **half** damage if you **fail**.

### Stillness of Mind

Starting at 7th level, you can use your [[Action]] to end one effect on yourself that is causing you to be [[Charmed]] or [[Frightened]].

### Purity of Body

At 10th level, your mastery of the ki flowing through you makes you **immune** to **disease** and **poison**.

### Tongue of the Sun and Moon

Starting at 13th level, you learn to touch the ki of other minds so that you understand all spoken languages. Moreover, any creature that can understand a language can understand what you say.

### Diamond Soul

Beginning at 14th level, your mastery of ki grants you proficiency in all saving throws.

Additionally, whenever you make a saving throw and fail, you can spend 1 ki point to reroll it and take the second result.

### Timeless Body

At 15th level, your ki sustains you so that you suffer none of the frailty of old age, and you can't be aged magically. You can still die of old age, however. In addition, you no longer need food or water.

### Empty Body

Beginning at 18th level, you can use your [[Action]] to spend 4 ki points to become [[Invisible]] for **1 minute**. During that time, you also have **resistance** to all damage but [[Force]] damage.

Additionally, you can spend 8 ki points to cast the *[[Astral Projection]]* spell, without needing material components. When you do so, you can't take any other creatures with you.

### Perfect Self

At 20th level, when you roll for [[The Wanderer's Guide to the Multiverse/Gameplay/Initiative]] and have no ki points remaining, you regain 4 ki points.
