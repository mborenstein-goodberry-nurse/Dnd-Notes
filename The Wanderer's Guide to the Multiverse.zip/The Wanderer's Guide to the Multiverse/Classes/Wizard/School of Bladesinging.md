---
aliases:
  - Bladesinging
  - Bladesinging Wizard
---
**_Bladesingers master a tradition of wizardry that incorporates swordplay and dance. Originally created by elves, this tradition has been adopted by non-elf practitioners, who honor and expand on the elven ways._**

**_In combat, a bladesinger uses a series of intricate, elegant maneuvers that fend off harm and allow the bladesinger to channel magic into devastating attacks and a cunning defense. Many who have observed a bladesinger at work remember the display as one of the more beautiful experiences in their life, a glorious dance accompanied by a singing blade._**

Sources: Tasha's Cauldron of Everything

### Training in War and Song

When you adopt this tradition at 2nd level, you gain proficiency with [[Light Armor]], and you gain proficiency with one type of one-handed melee weapon of your choice.

You also gain proficiency in the [[Performance]] skill if you don’t already have it.

### Bladesong

Starting at 2nd level, you can invoke an elven magic called the Bladesong, provided that you aren't wearing [[Medium Armor|medium]] or [[Heavy Armor]] or using a [[The Wanderer's Guide to the Multiverse/Spells/Shield]]. It graces you with supernatural speed, agility, and focus.

You can use a [[Bonus Action]] to start the Bladesong, which lasts for **1 minute**. It ends early if you are [[Incapacitated]], if you don [[Medium Armor|medium]] or [[Heavy Armor]] or a [[The Wanderer's Guide to the Multiverse/Spells/Shield]], or if you use two hands to make an attack with a weapon. You can also dismiss the Bladesong at any time (no action required).

While your Bladesong is active, you gain the following benefits:

- You gain a bonus to your AC equal to your [[Intelligence]] modifier (minimum of +1)

- Your walking speed increases by **10 feet**.

- You have [[Advantage]] on [[Acrobatics|Dexterity (Acrobatics)]] checks.

- You gain a bonus to any **[[Constitution]] saving throw** you make to maintain your [[Concentration]] on a spell. The bonus equals your [[Intelligence]] modifier (minimum of +1).

You can use this feature a number of times equal to your [[Proficiency Bonus]], and you regain all expended uses of it when you finish a [[Long Rest]].

### Extra Attack

Starting at 6th level, you can attack twice, instead of once, whenever you take the [[Attack]] action on your turn. Moreover, you can cast one of your cantrips in place of one of those attacks.

### Song of Defense

Beginning at 10th level, you can direct your magic to absorb damage while your [[#Bladesong]] is active. When you take damage, you can use your [[Reaction]] to expend one spell slot and reduce that damage to you by an amount equal to **five** **times** the spell slot's level.

### Song of Victory

Starting at 14th level, you can add your [[Intelligence]] modifier (minimum of +1) to the damage of your melee weapon attacks while your [[#Bladesong]] is active.