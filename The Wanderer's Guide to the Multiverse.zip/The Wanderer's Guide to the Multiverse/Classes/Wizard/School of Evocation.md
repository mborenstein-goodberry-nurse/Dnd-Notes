---
aliases:
  - Evocation Wizard
---
**_You focus your study on magic that creates powerful elemental effects such as bitter cold, searing flame, rolling thunder, crackling lightning, and burning acid. Some evokers find employment in military forces, serving as artillery to blast enemy armies from afar. Others use their spectacular power to protect the weak, while some seek their own gain as bandits, adventurers, or aspiring tyrants._**

Sources: Player's Handbook

### Evocation Savant

Beginning when you select this school at 2nd level, the gold and time you must spend to copy a Evocation spell into your spellbook is halved.

### Sculpt Spells

Beginning at 2nd level, you can create pockets of relative safety within the effects of your [[Evocation|evocation spells]]. When you cast an [[Evocation|evocation spell]] that affects other creatures that you can see, you can choose a number of them equal to 1 + the spell's level. The chosen creatures automatically **succeed** on their saving throws against the spell, and they take **no** damage if they would normally take **half** damage on a successful save.

### Potent Cantrip

Starting at 6th level, your damaging cantrips affect even creatures that avoid the brunt of the effect. When a creature succeeds on a saving throw against your cantrip, the creature takes **half** the cantrip's damage (if any) but suffers no additional effect from the cantrip.

### Empowered Evocation

Beginning at 10th level, you can add your **[[Intelligence]] modifier** (minimum of +1) to one damage roll of any wizard evocation spell that you cast.

### Overchannel

Starting at 14th level, you can increase the power of your simpler spells. When you cast a wizard spell of **1st** through **5th** level that deals damage, you can deal maximum damage with that spell.

The first time you do so, you suffer no adverse effect. If you use this feature again before you finish a [[Long Rest]], you take **2d12 [[Necrotic]]** damage for each level of the spell, immediately after you cast it. Each time you use this feature again before finishing a [[Long Rest]], the [[Necrotic]] damage per spell level increases by **1d12**. This damage ignores resistance and immunity. 