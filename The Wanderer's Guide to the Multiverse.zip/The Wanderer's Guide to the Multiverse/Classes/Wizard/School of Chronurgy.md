---
aliases:
  - Chronurgy Magic
  - Chronurgy Wizard
---
**_Focusing on the manipulation of time, those who follow the Chronurgy tradition learn to alter the pace of reality to their liking. Using the ramping of anticipatory dunamis energy, these mages can bend the flow of time as adroitly as a skilled musician plays an instrument, lending themselves and their allies an advantage in the blink of an eye._**

Sources: Explorer's Guide to Wildemount

### Chronal Shift

At 2nd level, you can magically exert limited control over the flow of time around a creature. As a [[Reaction]], after you or a creature you can see within **30 feet** of you makes an attack roll, an ability check, or a saving throw, you can force the creature to reroll. You make this decision after you see whether the roll succeeds or fails. The target must use the result of the second roll.

You can use this ability twice, and you regain any expended uses when you finish a [[Long Rest]].

### Temporal Awareness

Starting at 2nd level, you can add your [[Intelligence]] modifiers to your [[The Wanderer's Guide to the Multiverse/Gameplay/Initiative]] rolls.

### Momentary Stasis

When you reach 6th level, as an [[Action]], you can magically force a **Large** or smaller creature you can see within **60 feet** of you to make a **[[Constitution]] saving throw** against your spell save DC. Unless the saving throw is a success, the creature is encased in a field of magical energy until the end of your next turn or until the creature takes any damage. While encased in this way, the creature is [[Incapacitated]] and has a **speed of 0**.

You can use this feature a number of times equal to your [[Intelligence]] modifier (a minimum of once). You regain all expended uses when you finish a [[Long Rest]].

### Arcane Abeyance

At 10th level, when you cast a spell using a spell slot of 4th level or lower, you can condense the spell's magic into a mote. The spell is frozen in time at the moment of casting and held within a gray bead for **1 hour**. This bead is a Tiny object with AC 15 and 1 hit point, and it is **immune** to [[The Wanderer's Guide to the Multiverse/Dictionary/Damage Types/Poison]] and [[Psychic]] damage. When the duration ends, or if the bead is destroyed, it vanishes in a flash of light, and the spell is lost.

A creature holding the bead can use its [[Action]] to release the spell within, whereupon the bead disappears. The spell uses your spell attack bonus and save DC, and the spell treats the creature who released it as the caster for all other purposes.

Once you create a bead with this feature, you can't do so again until you finish a [[Short Rest|short]] or [[Long Rest]].

### Convergent Future

Starting at 14th level, you can peer through possible futures and magically pull one of them into events around you, ensuring a particular outcome. When you or a creature you can see within **60 feet** of you makes an attack roll, an ability check, or a saving throw, you can use your reaction to ignore the die roll and decide whether the number rolled is the minimum needed to succeed or one less than that number (your choice).

When you use this feature, you gain one level of [[Exhaustion]]. Only by finishing a [[Long Rest]] can you remove a level of [[Exhaustion]] gained in this way.