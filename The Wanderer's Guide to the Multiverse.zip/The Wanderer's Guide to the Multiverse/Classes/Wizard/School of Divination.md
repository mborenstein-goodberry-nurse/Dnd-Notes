---
aliases:
  - Divination Wizard
---
**_The counsel of a diviner is sought by royalty and commoners alike, for all seek a clearer understanding of the past, present, and future. As a diviner, you strive to part the veils of space, time, and consciousness so that you can see clearly. You work to master spells of discernment, remote viewing, supernatural knowledge, and foresight._**

Sources: Player's Handbook

### Divination Savant

Beginning when you select this school at 2nd level, the gold and time you must spend to copy a Divination spell into your spellbook is halved.

### Portent

Starting at 2nd level when you choose this school, glimpses of the future begin to press in on your awareness. When you finish a [[Long Rest]], roll **two** **d20s** and record the numbers rolled. You can replace any attack roll, saving throw, or ability check made by you or a creature that you can see with one of these foretelling rolls. You must choose to do so before the roll, and you can replace a roll in this way only once per turn.

Each foretelling roll can be used only once. When you finish a [[Long Rest]], you lose any unused foretelling rolls.

### Expert Divination

Beginning at 6th level, casting [[The Wanderer's Guide to the Multiverse/Spells/Divination|divination spells]] comes so easily to you that it expends only a fraction of your spellcasting efforts. When you cast a divination spell of **2nd level or higher** using a spell slot, you regain **one** expended spell slot. The slot you regain must be of a level lower than the spell you cast and **can't** be **higher** than **5th level**.

### The Third Eye

Starting at 10th level, you can use your [[Action]] to increase your powers of perception. When you do so, choose one of the following benefits, which lasts until you are [[Incapacitated]] or you take a [[Short Rest|short]] or [[Long Rest]]. You can't use the feature again until you finish a [[Short Rest|short]] or [[Long Rest]].

**_Darkvision._** You gain **darkvision** out to a range of **60 feet**.

**_Ethereal Sight._** You can see into the Ethereal Plane within **60 feet** of you.

**_Greater Comprehension._** You can read any language.

**_See Invisibility._** You can see [[Invisible]] creatures and objects within **10 feet** of you that are within line of sight.

### Greater Portent

Starting at 14th level, the visions in your dreams intensify and paint a more accurate picture in your mind of what is to come. You roll **three** **d20s** for your [[#Portent]] feature, rather than two.