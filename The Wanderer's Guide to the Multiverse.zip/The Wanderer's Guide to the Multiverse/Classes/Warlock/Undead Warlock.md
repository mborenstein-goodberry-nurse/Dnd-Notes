---
aliases:
---
**Class**: [[Warlock]] 

**_You've made a pact with a deathless being, a creature that defies the cycle and life and death, forsaking its mortal shell so it might eternally pursue its unfathomable ambitions. For such beings, time and morality are fleeting things, the concerns of those for whom grains of sand still rush through life's hourglass. Having once been mortal themselves, these ancient undead know firsthand the paths of ambition and the routes past the doors of death. They eagerly share this profane knowledge, along with other secrets, with those who work their will among the living._**

**_Beings of this type include the demilich Acererak, the vampire tyrant Kas the Bloody-Handed, the githyanki lich-queen Vlaakith, the dracolich Dragotha, the undead pharaoh Ankhtepot, and the elusive Darklord, Azalin Rex._**

Source: Van Richten's Guide to Ravenloft

### Expanded Spell List

At 1st level, the Undead lets you choose from an expanded list of spells when you learn a warlock spell. The following spells are added to the warlock spell list for you.

| Undead Expanded Spells |                                                                  |
| ---------------------- | ---------------------------------------------------------------- |
| Spell Level            | Spells                                                           |
| 1st                    | [[Bane]], [[False Life]]                                         |
| 2nd                    | [[Blindness-Deafness\|Blindness/Deafness]], [[Phantasmal Force]] |
| 3rd                    | [[Phantom Steed]], [[Speak with Dead]]                           |
| 4th                    | [[Death Ward]], [[Greater Invisibility]]                         |
| 5th                    | [[Antilife Shell]], [[Cloudkill]]                                |

### Form of Dread

At 1st level, you manifest an aspect of your patron’s dreadful power. As a [[Bonus Action]], you transform for **1 minute**. You gain the following benefits while transformed:

- You gain [[Temporary Hit Points]] equal to **1d10** + your warlock level.

- Once during each of your turns, when you hit a creature with an attack, you can force it to make a **[[Wisdom]] saving throw**, and if the saving throw fails, the target is [[Frightened]] of you until the **end** **of** **your** **next turn**.

- You are **immune** to the [[Frightened]] condition.

You can transform a number of times equal to your [[Proficiency Bonus]], and you regain all expended uses when you finish a [[Long Rest]].

The appearance of your Form of Dread reflects some aspect of your patron. For example, your form could be a shroud of shadows forming the crown and robes of your lich patron, or your body might glow with glyphs from ancient funerary rites and be surrounded by desert winds, suggesting your mummy patron.

### Grave Touched

At 6th level, your patron’s powers have a profound effect on your body and magic. You don’t need to eat, drink, or breathe.

In addition, once during each of your turns, when you hit a creature with an attack and roll damage against the creature, you can replace the damage type with [[Necrotic]] damage. While you are using your [[#Form of Dread]], you can roll one additional damage die when determining the [[Necrotic]] damage the target takes.

### Necrotic Husk

At 10th level, Your connection to undeath and necrotic energy now saturates your body. You have resistance to [[Necrotic]] damage. If you are transformed using your [[#Form of Dread]], you instead become immune to [[Necrotic]] damage.

In addition, when you are reduced to **0 [[Hit Points]]**, you can use your [[Reaction]] to drop to **1 [[Hit Points|hit point]]** instead and cause your body to erupt with deathly energy. Each creature of your choice that is within **30 feet** of you takes [[Necrotic]] damage equal to **2d10** + your warlock level. You then gain **1 level** of [[Exhaustion]]. Once you use this [[Reaction]], you can’t do so again until you finish **1d4** [[Long Rest|long rests]].

### Spirit Projection

At 14th level, your spirit can become untethered from your physical form. As an [[Action]], you can project your spirit from your body. The body you leave behind is [[Unconscious]] and in a state of suspended animation.

Your spirit resembles your mortal form in almost every way, replicating game statistics but not your possessions. Any damage or other effects that apply to your spirit or physical body affects the other. Your spirit can remain outside your body for up to **1 hour** or until your [[Concentration]] is broken (as if concentrating on a spell). When your projection ends, your spirit returns to your body or your body magically teleports to your spirit’s space (your choice).

While projecting your spirit, you gain the following benefits:

- Your spirit and body gain **resistance** to [[Bludgeoning]], [[Piercing]], and [[Slashing]] damage.

- When you cast a spell of the [[Conjuration]] or [[Necromancy]] school, the spell doesn’t require verbal or somatic components or material components that lack a gold cost.

- You have a **flying speed** equal to your walking speed and can hover. You can move through creatures and objects as if they were [[Difficult Terrain]], but you take **1d10 [[Force]]** damage if you end your turn inside a creature or an object.

- While you are using your [[#Form of Dread]], once during each of your turns when you deal [[Necrotic]] damage to a creature, you regain [[Hit Points]] equal to **half** the amount of [[Necrotic]] damage dealt.

Once you use this feature, you can’t do so again until you finish a [[Long Rest]]. 