---
aliases:
---
**Class**: [[Warlock]] 

**_You have made a pact with one of the rarest kinds of genie, a noble genie. Such entities rule vast fiefs on the Elemental Planes and have great influence over lesser genies and elemental creatures. Noble genies are varied in their motivations, but most are arrogant and wield power that rivals that of lesser deities. They delight in turning the table on mortals, who often bind genies into servitude, and readily enter into pacts that expand their reach._**

**_You choose your patron's kind or determine it randomly, using the Genie Kind table._**

| Genie Kind |         |         |
| ---------- | ------- | ------- |
| d4         | Kind    | Element |
| 1          | Dao     | Earth   |
| 2          | Djinni  | Air     |
| 3          | Efreeti | Fire    |
| 4          | Marid   | Water   |

Source: Tasha's Cauldron of Everything

### Expanded Spell List

At 1st level, the Genie lets you choose from an expanded list of spells when you learn a warlock spell. The Genie Expanded Spells table shows the genie spells that are added to the warlock spell list for you, along with the spells associated in the table with your patron's kind: dao, djinni, efreeti, or marid.

| Genie Expanded Spells |                           |                     |                          |                   |                   |
| --------------------- | ------------------------- | ------------------- | ------------------------ | ----------------- | ----------------- |
| Spell Level           | Genie Spells              | Dao Spells          | Djinni Spells            | Efreeti Spells    | Marid Spells      |
| 1st                   | [[Detect Evil and Good]]  | [[Sanctuary]]       | [[Thunderwave]]          | [[Burning Hands]] | [[Fog Cloud]]     |
| 2nd                   | [[Phantasmal Force]]      | [[Spike Growth]]    | [[Gust of Wind]]         | [[Scorching Ray]] | [[Blur]]          |
| 3rd                   | [[Create Food and Water]] | [[Meld into Stone]] | [[Wind Wall]]            | [[Fireball]]      | [[Sleet Storm]]   |
| 4th                   | [[Phantasmal Killer]]     | [[Stone Shape]]     | [[Greater Invisibility]] | [[Fire Shield]]   | [[Control Water]] |
| 5th                   | [[Creation]]              | [[Wall of Stone]]   | [[Seeming]]              | [[Flame Strike]]  | [[Cone of Cold]]  |
| 9th                   | [[Wish]]                  | —                   | —                        | —                 | —                 |

### Genie's Vessel

Also at 1st level, your patron gifts you a magical vessel that grants you a measure of the genie's power. The vessel is a Tiny object, and you can use it as a spellcasting focus for your warlock spells. You decide what the object is, or you can determine what it is randomly by rolling on the Genie's Vessel table.

|Genie's Vessel|   |
|---|---|
|d6|Vessel|
|1|Oil lamp|
|2|Urn|
|3|Ring with a compartment|
|4|Stoppered bottle|
|5|Hollow statuette|
|6|Ornate lantern|

While you are touching the vessel, you can use it in the following ways:

- **Bottled Respite:** As an [[Action]], you can magically vanish and enter your vessel, which remains in the space you left. The interior of the vessel is an extradimensional space in the shape of a **20-foot-radius cylinder**, **20 feet** high, and resembles your vessel. The interior is appointed with cushions and low tables and is a comfortable temperature. While inside, you can hear the area around your vessel as if you were in its space. You can remain inside the vessel up to a number of **hours** equal to **twice** your [[Proficiency Bonus]]. You exit the vessel early if you use a [[Bonus Action]] to leave, if you die, or if the vessel is destroyed. When you exit the vessel, you appear in the unoccupied space closest to it. Any objects left in the vessel remain there until carried out, and if the vessel is destroyed, every object stored there harmlessly appears in the unoccupied spaces closest to the vessel's former space. Once you enter the vessel, you can't enter again until you finish a [[Long Rest]].

- **Genie's Wrath:** Once during each of your turns when you hit with an attack roll, you can deal extra damage to the target equal to your [[Proficiency Bonus]]. The type of this damage is determined by your patron: [[Bludgeoning]] (dao), [[Thunder]] (djinni), [[Fire]] (efreeti), or [[Cold]] (marid).

The vessel's AC equals your spell save DC. Its **hit points** equal your warlock level plus your [[Proficiency Bonus]], and it is immune to [[The Wanderer's Guide to the Multiverse/Dictionary/Damage Types/Poison]] and [[Psychic]] damage.

If the vessel is destroyed or you lose it, you can perform a **1-hour** ceremony to receive a replacement from your patron. This ceremony can be performed during a [[Short Rest|short]] or [[Long Rest]], and the previous vessel is destroyed if it still exists. The vessel vanishes in a flare of elemental power when you die.

### Elemental Gift

At 6th level, you begin to take on characteristics of your patron's kind. You now have **resistance** to a damage type determined by your patron's kind: [[Bludgeoning]] (dao), [[Thunder]] (djinni), [[Fire]] (efreeti), or [[Cold]] (marid).

In addition, as a [[Bonus Action]], you can give yourself a flying speed of **30 feet** that lasts for **10 minutes**, during which you can hover. You can use this [[Bonus Action]] a number of times equal to your [[Proficiency Bonus]], and you regain all expended uses when you finish a [[Long Rest]].

### Sanctuary Vessel

At 10th level, when you enter your Genie's Vessel via the Bottled Respite feature, you can now choose up to **five** willing creatures that you can see within **30 feet** of you, and the chosen creatures are drawn into the vessel with you.

As a [[Bonus Action]], you can eject any number of creatures from the vessel, and everyone is ejected if you leave or die or if the vessel is destroyed.

In addition, anyone (including you) who remains within the vessel for at least **10 minutes** gains the benefit of finishing a [[Short Rest]], and anyone can add your [[Proficiency Bonus]] to the number of [[Hit Points]] they regain if they spend any Hit Dice as part of a short rest there.

### Limited Wish

At 14th level, you entreat your patron to grant you a small wish. As an [[Action]], you can speak your desire to your Genie's Vessel, requesting the effect of one spell that is 6th level or lower and has a casting time of 1 [[Action]]. The spell can be from any class's spell list, and you don't need to meet the requirements in that spell, including costly components: the spell simply takes effect as part of this action.

Once you use this feature, you can't use it again until you finish **1d4** [[Long Rest|long rests]].