---
aliases:
  - Great Old One
---
**Class**: [[Warlock]] 

**_Your patron is a mysterious entity whose nature is utterly foreign to the fabric of reality. It might come from the Far Realm, the space beyond reality, or it could be one of the elder gods known only in legends. Its motives are incomprehensible to mortals, and its knowledge so immense and ancient that even the greatest libraries pale in comparison to the vast secrets it holds. The Great Old One might be unaware of your existence or entirely indifferent to you, but the secrets you have learned allow you to draw your magic from it._**

**_Entities of this type include Ghaunadar, called That Which Lurks; Tharizdun, the Chained God; Dendar, the Night Serpent; Zargon, the Returner; Great Cthulhu; and other unfathomable beings._**

Source: Player's Handbook

### Expanded Spell List

The Great Old One lets you choose from an expanded list of spells when you learn a warlock spell. The following spells are added to the warlock spell list for you.

| Great Old One Expanded Spells |                                                      |
| ----------------------------- | ---------------------------------------------------- |
| Spell Level                   | Spells                                               |
| 1st                           | [[Dissonant Whispers]], [[Tasha's Hideous Laughter]] |
| 2nd                           | [[Detect Thoughts]], [[Phantasmal Force]]            |
| 3rd                           | [[Clairvoyance]], [[Sending]]                        |
| 4th                           | [[Dominate Beast]], [[Evard's Black Tentacles]]      |
| 5th                           | [[Dominate Person]], [[Telekinesis]]                 |

### Awakened Mind

Starting at 1st level, your alien knowledge gives you the ability to touch the minds of other creatures. You can telepathically speak to any creature you can see within **30 feet** of you. You don't need to share a language with the creature for it to understand your telepathic utterances, but the creature must be able to understand at least one language.

### Entropic Ward

At 6th level, you learn to magically ward yourself against attack and to turn an enemy's failed strike into good luck for yourself. When a creature makes an attack roll against you, you can use your [[Reaction]] to impose [[Disadvantage]] on that roll. If the attack misses you, your next attack roll against the creature has [[Advantage]] if you make it before the end of your next turn.

Once you use this feature, you can't use it again until you finish a [[Short Rest|short]] or [[Long Rest]].

### Thought Shield

Starting at 10th level, your thoughts can't be read by telepathy or other means unless you allow it. You also have **resistance** to [[Psychic]] damage, and whenever a creature deals [[Psychic]] damage to you, that creature takes the same amount of damage that you do.

### Create Thrall

At 14th level, you gain the ability to infect a humanoid's mind with the alien magic of your patron. You can use your [[Action]] to touch an [[Incapacitated]] humanoid. That creature is then [[Charmed]] by you until a [[Remove Curse]] spell is cast on it, the [[Charmed]] condition is removed from it, or you use this feature again.

You can communicate telepathically with the charmed creature as long as the two of you are on the same plane of existence.