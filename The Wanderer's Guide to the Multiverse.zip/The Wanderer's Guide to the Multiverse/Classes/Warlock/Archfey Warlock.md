---
aliases:
---
**Class**: [[Warlock]] 

**_Your patron is a lord or lady of the fey, a creature of legend who holds secrets that were forgotten before the mortal races were born. This being's motivations are often inscrutable, and sometimes whimsical, and might involve a striving for greater magical power or the settling of age-old grudges. Beings of this sort include the Prince of Frost; the Queen of Air and Darkness, ruler of the Gloaming Court; Titania of the Summer Court; her consort Oberon, the Green Lord; Hyrsam, the Prince of Fools; and ancient hags._**

Source: Player's Handbook

### Expanded Spell List

The Archfey lets you choose from an expanded list of spells when you learn a warlock spell. The following spells are added to the warlock spell list for you.

| Archfey Expanded Spells |                                              |
| ----------------------- | -------------------------------------------- |
| Spell Level             | Spells                                       |
| 1st                     | [[Faerie Fire]], [[Sleep]]                   |
| 2nd                     | [[Calm Emotions]], [[Phantasmal Force]]      |
| 3rd                     | [[Blink]], [[Plant Growth]]                  |
| 4th                     | [[Dominate Beast]], [[Greater Invisibility]] |
| 5th                     | [[Dominate Person]], [[Seeming]]             |

### Fey Presence

Starting at 1st level, your patron bestows upon you the ability to project the beguiling and fearsome presence of the fey. As an [[Action]], you can cause each creature in a **10-foot cube** originating from you to make a **[[Wisdom]] saving throw** against your warlock spell save DC. The creatures that fail their saving throws are all [[Charmed]] or [[Frightened]] by you (your choice) until the end of your next turn.

Once you use this feature, you can't use it again until you finish a [[Short Rest|short]] or [[Long Rest]].

### Misty Escape

Starting at 6th level, you can vanish in a puff of mist in response to harm. When you take damage, you can use your [[Reaction]] to turn [[Invisible]] and teleport up to **60 feet** to an unoccupied space you can see. You remain [[Invisible]] until the **start of your next turn** or until you attack or cast a spell.

Once you use this feature, you can't use it again until you finish a [[Short Rest|short]] or [[Long Rest]].

### Beguiling Defenses

Beginning at 10th level, your patron teaches you how to turn the mind-affecting magic of your enemies against them. You are **immune** to being [[Charmed]], and when another creature attempts to charm you, you can use your [[Reaction]] to attempt to turn the charm back on that creature. The creature must succeed on a **[[Wisdom]] saving throw** against your warlock spell save DC or be [[Charmed]] by you for **1 minute** or until the creature takes any damage.

### Dark Delirium

Starting at 14th level, you can plunge a creature into an illusory realm. As an [[Action]], choose a creature that you can see within **60 feet** of you. It must make a **[[Wisdom]] saving throw** against your warlock spell save DC. On a failed save, it is [[Charmed]] or [[Frightened]] by you (your choice) for **1 minute** or until your [[Concentration]] is broken (as if you are concentrating on a spell). This effect ends early if the creature takes any damage.

Until this illusion ends, the creature thinks it is lost in a misty realm, the appearance of which you choose. The creature can see and hear only itself, you, and the illusion.

You must finish a [[Short Rest|short]] or [[Long Rest]] before you can use this feature again.