---
aliases:
---
**Class**: [[Warlock]] 

**_You have made your pact with a mysterious entity from the Shadowfell – a force that manifests in sentient magic weapons carved from the stuff of shadow. The mighty sword Blackrazor is the most notable of these weapons, which have been spread across the multiverse over the ages. The shadowy force behind these weapons can offer power to warlocks who form pacts with it. Many hexblade warlocks create weapons that emulate those formed in the Shadowfell. Others forgo such arms, content to weave the dark magic of that plane into their spellcasting._**

_**Because the Raven Queen is known to have forged the first of these weapons, many sages speculate that she and the force are one and that the weapons, along with hexblade warlocks, are tools she uses to manipulate events on the Material Plane to her inscrutable ends.**_

Source: Xanathar's Guide to Everything

### Expanded Spell List

The Hexblade lets you choose from an expanded list of spells when you learn a warlock spell. The following spells are added to the warlock spell list for you.

| Hexblade Expanded Spells |                                                         |
| ------------------------ | ------------------------------------------------------- |
| Spell Level              | Spells                                                  |
| 1st                      | [[The Wanderer's Guide to the Multiverse/Spells/Shield\|Shield]], [[Wrathful Smite]] |
| 2nd                      | [[Blur]], [[Branding Smite]]                            |
| 3rd                      | [[Blink]], [[Elemental Weapon]]                         |
| 4th                      | [[Phantasmal Killer]], [[Staggering Smite]]             |
| 5th                      | [[Banishing Smite]], [[Cone of Cold]]                   |

### Hexblade's Curse

Starting at 1st level, you gain the ability to place a baleful curse on someone. As a [[Bonus Action]], choose **one creature** you can see within **30 feet** of you. The target is cursed for **1 minute**. The curse ends early if the target dies, you die, or you are [[Incapacitated]]. Until the curse ends, you gain the following benefits:

- You gain a bonus to damage rolls against the cursed target. The bonus equals your [[Proficiency Bonus]].

- Any attack roll you make against the cursed target is a [[Critical Hit]] on a roll of **19** or **20** on the d20.

- If the cursed target dies, you regain [[Hit Points]] equal to your warlock level + your **[[Charisma]] modifier** (minimum of 1 hit point).

You can't use this feature again until you finish a [[Short Rest|short]] or [[Long Rest]].

### Hex Warrior

At 1st level, you acquire the training necessary to effectively arm yourself for battle. You gain proficiency with [[Medium Armor]], [[The Wanderer's Guide to the Multiverse/Spells/Shield|Shields]], and [[Martial Weapon|Martial Weapons]].

The influence of your patron also allows you to mystically channel your will through a particular weapon. Whenever you finish a [[Long Rest]], you can touch one weapon that you are proficient with and that lacks the [[Two-Handed]] property. When you attack with that weapon, you can use your [[Charisma]] modifier, instead of [[Strength]] or [[Dexterity]], for the attack and damage rolls. This benefit lasts until you finish a [[Long Rest]]. If you later gain the [[Warlock#^c337d1|Pact of the Blade]] feature, this benefit extends to every pact weapon you conjure with that feature, no matter the weapon's type.

### Accursed Specter

Starting at 6th level, you can curse the soul of a person you slay, temporarily binding it in your service. When you slay a humanoid, you can cause its spirit to rise from its corpse as a specter, the statistics of which are in the _Monster Manual_. When the specter appears, it gains [[Temporary Hit Points]] equal to half your warlock level. Roll [[The Wanderer's Guide to the Multiverse/Gameplay/Initiative]] for the specter, which has its own turns. It obeys your verbal commands, and it gains a special bonus to its attack rolls equal to your [[Charisma]] modifier (minimum of +0).

The specter remains in your service until the end of your next [[Long Rest]], at which point it vanishes to the afterlife.

Once you bind a specter with this feature, you can't use the feature again until you finish a [[Long Rest]].

### Armor of Hexes

At 10th level, your hex grows more powerful. If the target cursed by your [[#Hexblade's Curse]] hits you with an attack roll, you can use your [[Reaction]] to roll a **d6**. On a 4 or higher, the attack instead misses you, regardless of its roll.

### Master of Hexes

Starting at 14th level, you can spread your [[#Hexblade's Curse]] from a slain creature to another creature. When the creature cursed by your [[#Hexblade's Curse]] dies, you can apply the curse to a different creature you can see within **30 feet** of you, provided you aren't [[Incapacitated]]. When you apply the curse in this way, you don't regain [[Hit Points]] from the death of the previously cursed creature. 