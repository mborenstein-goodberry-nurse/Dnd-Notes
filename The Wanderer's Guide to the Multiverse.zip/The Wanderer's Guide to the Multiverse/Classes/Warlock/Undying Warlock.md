---
aliases:
---
**Class**: [[Warlock]] 

**_Death holds no sway over your patron, who has unlocked the secrets of everlasting life, although such a prize – like all power – comes at a price. Once mortal, the Undying has seen mortal lifetimes pass like the seasons, like the flicker of endless days and nights. It has the secrets of the ages to share, secrets of life and death. Beings of this sort include Vecna, Lord of the Hand and the Eye; the dread Iuz; the lich-queen Vol; the Undying Court of Aerenal; Vlaakith, lich-queen of the githyanki; and the deathless wizard Fistandantalus._**

**_In the Realms, Undying patrons include Larloch the Shadow King, legendary master of Warlock's Crypt, and Gilgeam, the God-King of Unther._**

Source: Sword Coast Adventurer's Guide

### Expanded Spell List

The Undying lets you choose from an expanded list of spells when you learn a warlock spell. The following spells are added to the warlock spell list for you.

| Undying Expanded Spells |                                                         |
| ----------------------- | ------------------------------------------------------- |
| Spell Level             | Spells                                                  |
| 1st                     | [[False Life]], [[Ray of Sickness]]                     |
| 2nd                     | [[Blindness-Deafness\|Blindness/Deafness]], [[Silence]] |
| 3rd                     | [[Feign Death]], [[Speak with Dead]]                    |
| 4th                     | [[Aura of Life]], [[Death Ward]]                        |
| 5th                     | [[Contagion]], [[Legend Lore]]                          |

### Among the Dead

Starting at 1st level, you learn the [[Spare the Dying]] cantrip, which counts as a warlock cantrip for you. You also have [[Advantage]] on saving throws against any disease.

Additionally, undead have difficulty harming you. If an **undead** targets you directly with an attack or a harmful spell, that creature must make a **[[Wisdom]] saving throw** against your spell save DC (an undead needn't make the save when it includes you in an area effect, such as the explosion of [[Fireball]]). On a failed save, the creature must choose a new target or forfeit targeting someone instead of you, potentially wasting the attack or spell. On a successful save, the creature is **immune** to this effect for **24 hours**. An **undead** is also immune to this effect for **24 hours** if you target it with an attack or a harmful spell.

### Defy Death

Starting at 6th level, you can give yourself vitality when you cheat death or when you help someone else cheat it. You can regain [[Hit Points]] equal to **1d8** + your **[[Constitution]] modifier** (minimum of 1 hit point) when you succeed on a [[Death Saving Throw]] or when you stabilize a creature with [[Spare the Dying]].

Once you use this feature, you can't use it again until you finish a [[Long Rest]].

### Undying Nature

Beginning at 10th level, you can hold your breath indefinitely, and you don't require food, water, or sleep, although you still require rest to reduce exhaustion and still benefit from finishing [[Short Rest|short]] and [[Long Rest|long rests]].

In addition, you age at a slower rate. For every 10 years that pass, your body ages only 1 year, and you are **immune** to being magically aged.

### Indestructible Life

When you reach 14th level, you partake of some of the true secrets of the Undying. On your turn, you can use a [[Bonus Action]] to regain [[Hit Points]] equal to **1d8** + your warlock level. Additionally, if you put a severed body part of yours back in place when you use this feature, the part reattaches.

Once you use this feature, you can't use it again until you finish a [[Short Rest|short]] or [[Long Rest]].