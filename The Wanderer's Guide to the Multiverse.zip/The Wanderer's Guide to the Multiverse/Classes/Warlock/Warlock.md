---
aliases:
  - Warlocks
---
# Warlock
**_Warlocks are seekers of the knowledge that lies hidden in the fabric of the multiverse. Through pacts made with mysterious beings of supernatural power, warlocks unlock magical effects both subtle and spectacular._**

_You must have a [[Charisma]] score of 13 or higher in order to multiclass in or out of this class._

### The Warlock Table 
| Level | Proficiency Bonus | Features                                                               | Cantrips Known | Spells Known | Spell Slots | Slot Level | Invocations Known |
| ----- | ----------------- | ---------------------------------------------------------------------- | -------------- | ------------ | ----------- | ---------- | ----------------- |
| 1st   | +2                | [[#Otherworldly Patron]], [[#Pact Magic]]                              | 2              | 2            | 1           | 1st        | -                 |
| 2nd   | +2                | [[#Eldritch Invocations]]                                              | 2              | 3            | 2           | 1st        | 2                 |
| 3rd   | +2                | [[#Pact Boon]]                                                         | 2              | 4            | 2           | 2nd        | 2                 |
| 4th   | +2                | [[#Ability Score Improvement]], _[[#Eldritch Versatility (Optional)]]_ | 3              | 5            | 2           | 2nd        | 2                 |
| 5th   | +3                |                                                                        | 3              | 6            | 2           | 3rd        | 3                 |
| 6th   | +3                | Otherworldly Patron feature                                            | 3              | 7            | 2           | 3rd        | 3                 |
| 7th   | +3                |                                                                        | 3              | 8            | 2           | 4th        | 4                 |
| 8th   | +3                | [[#Ability Score Improvement]], _[[#Eldritch Versatility (Optional)]]_ | 3              | 9            | 2           | 4th        | 4                 |
| 9th   | +4                |                                                                        | 3              | 10           | 2           | 5th        | 5                 |
| 10th  | +4                | Otherworldly Patron feature                                            | 4              | 10           | 2           | 5th        | 5                 |
| 11th  | +4                | [[#Mystic Arcanum]] (6th level)                                        | 4              | 11           | 3           | 5th        | 5                 |
| 12th  | +4                | [[#Ability Score Improvement]], _[[#Eldritch Versatility (Optional)]]_ | 4              | 11           | 3           | 5th        | 6                 |
| 13th  | +5                | [[#Mystic Arcanum]] (7th level)                                        | 4              | 12           | 3           | 5th        | 6                 |
| 14th  | +5                | Otherworldly Patron feature                                            | 4              | 12           | 3           | 5th        | 6                 |
| 15th  | +5                | [[#Mystic Arcanum]] (8th level)                                        | 4              | 13           | 3           | 5th        | 7                 |
| 16th  | +5                | [[#Ability Score Improvement]], _[[#Eldritch Versatility (Optional)]]_ | 4              | 13           | 3           | 5th        | 7                 |
| 17th  | +6                | [[#Mystic Arcanum]] (9th level)                                        | 4              | 14           | 4           | 5th        | 7                 |
| 18th  | +6                |                                                                        | 4              | 14           | 4           | 5th        | 8                 |
| 19th  | +6                | [[#Ability Score Improvement]], _[[#Eldritch Versatility (Optional)]]_ | 4              | 15           | 4           | 5th        | 8                 |
| 20th  | +6                | [[#Eldritch Master]]                                                   | 4              | 15           | 4           | 5th        | 8                 |

# Class Features

As a warlock, you gain the following class features.

##### Hit Points

**[[Hit Dice]]:** 1d8 per warlock level  
**[[Hit Points]] at 1st Level:** 8 + your [[Constitution]] modifier  
**[[Hit Points]] at Higher Levels:** 1d8 (or 5) + your [[Constitution]] modifier per warlock level after 1st

##### Proficiencies

**Armor:** [[Light Armor]]  
**Weapons:** [[Simple Weapon|Simple Weapons]]  
**Tools:** None  
**Saving Throws:** [[Wisdom]], [[Charisma]]  
**Skills:** Choose two from [[Arcana]], [[Deception]], [[History]], [[Intimidation]], [[Investigation]], [[Nature]], and [[Religion]]

##### Equipment

You start with the following equipment, in addition to the equipment granted by your background:

- (a) a light crossbow and 20 bolts or (b) any [[Simple Weapon]]
- (a) a component pouch or (b) an arcane focus
- (a) a [[Scholar's Pack]] or (b) a [[Dungeoneer's Pack]]
- Leather armor, any [[Simple Weapon]], and two daggers

### Otherworldly Patron

At 1st level, you have struck a bargain with an otherworldly being of your choice. Your choice grants you features at 1st level and again at 6th, 10th, and 14th level.

| Patron                                   | Source                           |
| ---------------------------------------- | -------------------------------- |
| [[Archfey Warlock\|Archfey]]             | Player's Handbook                |
| [[Celestial Warlock\|Celestial]]         | Xanathar's Guide to Everything   |
| [[Fathomless Warlock\|Fathomless]]       | Tasha's Cauldron of Everything   |
| [[Fiend Warlock\|Fiend]]                 | Player's Handbook                |
| [[Genie Warlock\|Genie]]                 | Tasha's Cauldron of Everything   |
| [[Great Old One Warlock\|Great Old One]] | Player's Handbook                |
| [[Hexblade Warlock\|Hexblade]]           | Xanathar's Guide to Everything   |
| [[Undead Warlock\|Undead]]               | Van Richten's Guide to Ravenloft |
| [[Undying Warlock\|Undying]]             | Sword Coast Adventurer's Guide   |

### Pact Magic

Your arcane research and the magic bestowed on you by your patron have given you facility with spells.

##### Cantrips

You know two cantrips of your choice from the [[Warlock Spells#Cantrip|warlock spell list]]. You learn additional warlock cantrips of your choice at higher levels, as shown in the Cantrips Known column of the Warlock table.

##### Spell Slots

[[#The Warlock table]] shows how many spell slots you have to cast your [[Warlock Spells]] of 1st through 5th level. The table also shows what the level of those slots is; all of your spell slots are the same level. To cast one of your warlock spells of 1st level or higher, you must expend a spell slot. You regain all expended spell slots when you finish a [[Short Rest|short]] or [[Long Rest]].

For example, when you are 5th level, you have two 3rd-level spell slots. To cast the 1st-level spell _[[Witch Bolt]]_, you must spend one of those slots, and you cast it as a 3rd-level spell.

##### Spells Known of 1st Level and Higher

At 1st level, you know two 1st-level spells of your choice from the [[Warlock Spells|warlock spell list]].

The Spells Known column of the Warlock table shows when you learn more warlock spells of your choice of 1st level or higher. A spell you choose must be of a level no higher than what's shown in the table's Slot Level column for your level. When you reach 6th level, for example, you learn a new warlock spell, which can be 1st, 2nd, or 3rd level.

Additionally, when you gain a level in this class, you can choose one of the warlock spells you know and replace it with another spell from the warlock spell list, which also must be of a level for which you have spell slots.

##### Spellcasting Ability

[[Charisma]] is your spellcasting ability for your warlock spells, so you use your [[Charisma]] whenever a spell refers to your spellcasting ability. In addition, you use your [[Charisma]] modifier when setting the saving throw DC for a warlock spell you cast and when making an attack roll with one.

**Spell save DC** = 8 + your [[Proficiency Bonus]] + your [[Charisma]] modifier

**Spell attack modifier** = your [[Proficiency Bonus]] + your [[Charisma]] modifier

##### Spellcasting Focus

You can use an arcane focus as a spellcasting focus for your warlock spells.

### Eldritch Invocations

In your study of occult lore, you have unearthed [[Eldritch Invocations]], fragments of forbidden knowledge that imbue you with an abiding magical ability.

At 2nd level, you gain **two** eldritch invocations of your choice. When you gain certain warlock levels, you gain additional invocations of your choice, as shown in the Invocations Known column of the Warlock table. A level prerequisite refers to your level in this class.

Additionally, when you gain a level in this class, you can choose one of the invocations you know and replace it with another invocation that you could learn at that level.

### Pact Boon

At 3rd level, your otherworldly patron bestows a gift upon you for your loyal service. You gain one of the following features of your choice.

- **Pact of the Blade** ^c337d1
    - You can use your action to create a pact [[Weapons|weapon]] in your empty hand. You can choose the form that this [[Melee Weapon]] takes each time you create it. You are proficient with it while you wield it. This weapon counts as magical for the purpose of overcoming resistance and immunity to nonmagical attacks and damage.
    - Your pact weapon disappears if it is more than **5 feet** away from you for **1 minute** or more. It also disappears if you use this feature again, if you dismiss the weapon (no action required), or if you die.
    - You can transform one magic weapon into your pact weapon by performing a special [[Ritual]] while you hold the weapon. You perform the ritual over the course of 1 hour, which can be done during a [[Short Rest]].
    - You can then dismiss the weapon, shunting it into an extradimensional space, and it appears whenever you create your pact weapon thereafter. You can't affect an artifact or a sentient weapon in this way. The weapon ceases being your pact weapon if you die, if you perform the **1-hour** ritual on a different weapon, or if you use a 1-hour ritual to break your bond to it. The weapon appears at your feet if it is in the extradimensional space when the bond breaks.

- **Pact of the Chain** ^6ff047
    - You learn the _[[Find Familiar]]_ spell and can cast it as a [[Ritual]]. The spell doesn't count against your number of spells known.
    - When you cast the spell, you can choose one of the normal forms for your familiar or one of the following special forms: imp, pseudodragon, quasit, or sprite.
    - Additionally, when you take the [[Attack]] action, you can forgo one of your own attacks to allow your familiar to make one attack with its [[Reaction]].

- **Pact of the Tome** ^2ad1fa
    - Your patron gives you a grimoire called a Book of Shadows. When you gain this feature, choose **three** [[All Spells#Cantrips|cantrips]] from any class's spell list (the three needn't be from the same list). While the book is on your person, you can cast those cantrips at will. They don't count against your number of cantrips known. If they don't appear on the warlock spell list, they are nonetheless warlock spells for you.
    - If you lose your Book of Shadows, you can perform a **1-hour** ceremony to receive a replacement from your patron. This ceremony can be performed during a short or long rest, and it destroys the previous book. The book turns to ash when you die.

- **Pact of the Talisman**   ^7c5dda
    - Your patron gives you an amulet, a talisman that can aid the wearer when the need is great. When the wearer fails an ability check, they can add a d4 to the roll, potentially turning the roll into a success. This benefit can be used a number of times equal to your [[Proficiency Bonus]], and all expended uses are restored when you finish a [[Long Rest]].
    - If you lose the talisman, you can perform a **1-hour** ceremony to receive a replacement from your patron. This ceremony can be performed during a [[Short Rest|short]] or [[Long Rest]], and it destroys the previous amulet. The talisman turns to ash when you die.

### Ability Score Improvement

When you reach 4th level, and again at 8th, 12th, 16th, and 19th level, you can increase one ability score of your choice by 2, or you can increase two ability scores of your choice by 1. As normal, you can't increase an ability score above 20 using this feature.

### Eldritch Versatility (Optional)

Whenever you reach a level in this class that grants the Ability Score Improvement feature, you can do one of the following, representing a change of focus in your occult studies:

- Replace one [[Warlock Spells#Cantrip|cantrip]] you learned from this class's Pact Magic feature with another cantrip from the warlock spell list.

- Replace the option you chose for the [[#Pact Boon]] feature with one of that feature's other options.

- If you're 12th level or higher, replace one spell from your [[#Mystic Arcanum]] feature with another warlock spell of the same level.

If this change makes you ineligible for any of your [[#Eldritch Invocations]], you must also replace them now, choosing invocations for which you qualify.

### Mystic Arcanum

At 11th level, your patron bestows upon you a magical secret called an arcanum. Choose one 6th-level spell from the [[Warlock Spells#6th Level|warlock spell list]] as this arcanum.

You can cast your arcanum spell once without expending a spell slot. You must finish a [[Long Rest]] before you can do so again.

At higher levels, you gain more warlock spells of your choice that can be cast in this way: one [[Warlock Spells#7th Level|7th-level spell]] at 13th level, one [[Warlock Spells#8th Level|8th-level spell]] at 15th level, and one [[Warlock Spells#9th Level|9th-level spell]] at 17th level. You regain all uses of your Mystic Arcanum when you finish a [[Long Rest]].

### Eldritch Master

At 20th level, you can draw on your inner reserve of mystical power while entreating your patron to regain expended spell slots. You can spend **1 minute** entreating your patron for aid to regain all your expended spell slots from your [[#Pact Magic]] feature. Once you regain spell slots with this feature, you must finish a [[Long Rest]] before you can do so again.