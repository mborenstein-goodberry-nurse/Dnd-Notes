---
aliases:
  - Ancients Paladin
---
**Class**: [[Paladin]] 

**_The Oath of the Ancients is as old as the race of elves and the rituals of the druids. Sometimes called fey knights, green knights, or horned knights, paladins who swear this oath cast their lot with the side of the light in the cosmic struggle against darkness because they love the beautiful and life-giving things of the world, not necessarily because they believe in principles of honor, courage, and justice. They adorn their armor and clothing with images of growing things-leaves, antlers, or flowers-to reflect their commitment to preserving life and light in the world._**

Source: Player's Handbook

### Tenets of the Ancients

The tenets of the Oath of the Ancients have been preserved for uncounted centuries. This oath emphasizes the principles of good above any concerns of law or chaos. Its four central principles are simple.

**_Kindle the Light._** Through your acts of mercy, kindness, and forgiveness, kindle the light of hope in the world, beating back despair.

**_Shelter the Light._** Where there is good, beauty, love, and laughter in the world, stand against the wickedness that would swallow it. Where life flourishes, stand against the forces that would render it barren.

**_Preserve Your Own Light._** Delight in song and laughter, in beauty and art. If you allow the light to die in your own heart, you can't preserve it in the world.

**_Be the Light._** Be a glorious beacon for all who live in despair. Let the light of your joy and courage shine forth in all your deeds.

### Oath Spells

You gain oath spells at the paladin levels listed.

| Oath of the Ancients Spells |                                              |
| --------------------------- | -------------------------------------------- |
| Paladin Level               | Spells                                       |
| 3rd                         | [[Ensnaring Strike]], [[Speak with Animals]] |
| 5th                         | [[Moonbeam]], [[Misty Step]]                 |
| 9th                         | [[Plant Growth]], [[Protection from Energy]] |
| 13th                        | [[Ice Storm]], [[Stoneskin]]                 |
| 17th                        | [[Commune with Nature]], [[Tree Stride]]     |

### Channel Divinity

When you take this oath at 3rd level, you gain the following two Channel Divinity options.

- **_Nature's Wrath._** You can use your Channel Divinity to invoke primeval forces to ensnare a foe. As an [[Action]], you can cause spectral vines to spring up and reach for a creature within **10 feet** of you that you can see. The creature must succeed on a **[[Strength]] *or* [[Dexterity]] saving throw** (its choice) or be [[Restrained]]. While [[Restrained]] by the vines, the creature repeats the saving throw at the end of each of its turns. On a success, it frees itself and the vines vanish.

- **_Turn the Faithless._** You can use your Channel Divinity to utter ancient words that are painful for fey and fiends to hear. As an [[Action]], you present your holy symbol, and each **fey** or **fiend** within **30 feet** of you that can hear you must make a **[[Wisdom]] saving throw**. On a failed save, the creature is turned for **1 minute** or until it takes damage.  
      
    A turned creature must spend its turns trying to move as far away from you as it can, and it can't willingly move to a space within **30 feet** of you. It also can't take [[Reaction|Reactions]]. For its [[Action]], it can use only the [[Dash]] action or try to escape from an effect that prevents it from moving. If there's nowhere to move, the creature can use the [[Dodge]] action.  
      
    If the creature's true form is concealed by an illusion, shapeshifting, or other effect, that form is revealed while it is turned.

### Aura of Warding

Beginning at 7th level, ancient magic lies so heavily upon you that it forms an eldritch ward. You and friendly creatures within **10 feet** of you have **resistance** to damage from spells.

At 18th level, the range of this aura increases to **30 feet**.

### Undying Sentinel

Starting at 15th level, when you are reduced to 0 hit points and are not killed outright, you can choose to drop to 1 [[Hit Points|hit point]] instead. Once you use this ability, you can't use it again until you finish a [[Long Rest]].

Additionally, you suffer none of the drawbacks of old age, and you can't be aged magically.

### Elder Champion

At 20th level, you can assume the form of an ancient force of nature, taking on an appearance you choose. For example, your skin might turn green or take on a bark-like texture, your hair might become leafy or moss-like, or you might sprout antlers or a lion-like mane.

Using your action, you undergo a transformation. For **1 minute**, you gain the following benefits:

- At the start of each of your turns, you regain **10 [[Hit Points]]**.

- Whenever you cast a paladin spell that has a casting time of 1 [[Action]], you can cast it using a [[Bonus Action]] instead.

- Enemy creatures within 10 feet of you have [[Disadvantage]] on saving throws against your paladin spells and [[#Channel Divinity]] options.

Once you use this feature, you can't use it again until you finish a [[Long Rest]].