**Class**: [[Paladin]] 

**_The Oath of Devotion binds a paladin to the loftiest ideals of justice, virtue, and order. Sometimes called cavaliers, white knights, or holy warriors, these paladins meet the ideal of the knight in shining armor, acting with honor in pursuit of justice and the greater good. They hold themselves to the highest standards of conduct, and some, for better or worse, hold the rest of the world to the same standards. Many who swear this oath are devoted to gods of law and good and use their gods' tenets as the measure of their devotion. They hold angels – the perfect servants of good – as their ideals, and incorporate images of angelic wings into their helmets or coats of arms._**

Source: Player's Handbook

### Tenets of Devotion

Though the exact words and strictures of the Oath of Devotion vary, paladins of this oath share these tenets.

**_Honesty._** Don't lie or cheat. Let your word be your promise.

**_Courage._** Never fear to act, though caution is wise.

**_Compassion._** Aid others, protect the weak, and punish those who threaten them. Show mercy to your foes, but temper it with wisdom.

**_Honor._** Treat others with fairness, and let your honorable deeds be an example to them. Do as much good as possible while causing the least amount of harm.

**_Duty._** Be responsible for your actions and their consequences, protect those entrusted to your care, and obey those who have just authority over you.

### Oath Spells

You gain oath spells at the paladin levels listed.

| Oath of Devotion Spells |                                                  |
| ----------------------- | ------------------------------------------------ |
| Paladin Level           | Spells                                           |
| 3rd                     | [[Protection from Evil and Good]], [[Sanctuary]] |
| 5th                     | [[Lesser Restoration]], [[Zone of Truth]]        |
| 9th                     | [[Beacon of Hope]], [[Dispel Magic]]             |
| 13th                    | [[Freedom of Movement]], [[Guardian of Faith]]   |
| 17th                    | [[Commune]], [[Flame Strike]]                    |

### Channel Divinity

When you take this oath at 3rd level, you gain the following two Channel Divinity options.

- **_Sacred Weapon._** As an [[Action]], you can imbue one weapon that you are holding with positive energy, using your Channel Divinity. For **1 minute**, you add your **[[Charisma]] modifier** to attack rolls made with that weapon (with a minimum bonus of +1). The weapon also emits **bright light** in a **20-foot radius** and **dim light 20 feet** beyond that. If the weapon is not already magical, it becomes magical for the duration.  
      
    You can end this effect on your turn as part of any other [[Action]]. If you are no longer holding or carrying this weapon, or if you fall [[Unconscious]], this effect ends.

- **_Turn the Unholy._** As an [[Action]], you present your holy symbol and speak a prayer censuring fiends and undead, using your Channel Divinity. Each **fiend** or **undead** that can see or hear you within 30 feet of you must make a **[[Wisdom]] saving throw**. If the creature fails its saving throw, it is **turned** for **1 minute** or until it takes damage.  
      
    A turned creature must spend its turns trying to move as far away from you as it can, and it can't willingly move to a space within **30 feet** of you. It also can't take [[Reaction|reactions]]. For its [[Action]], it can use only the [[Dash]] action or try to escape from an effect that prevents it from moving. If there's nowhere to move, the creature can use the [[Dodge]] action.

### Aura of Devotion

Starting at 7th level, you and friendly creatures within **10 feet** of you can't be [[Charmed]] while you are **conscious**.

At 18th level, the range of this aura increases to **30 feet**.

### Purity of Spirit

Beginning at 15th level, you are always under the effects of a [[Protection from Evil and Good]] spell.

### Holy Nimbus

At 20th level, as an [[Action]], you can emanate an aura of sunlight. For **1 minute**, **bright light** shines from you in a **30-foot radius**, and **dim light** shines **30 feet** beyond that.

Whenever an enemy creature starts its turn in the **bright light**, the creature takes **10 [[Radiant]]** damage.

In addition, for the duration, you have [[Advantage]] on saving throws against spells cast by **fiends** or **undead**.

Once you use this feature, you can't use it again until you finish a [[Long Rest]].