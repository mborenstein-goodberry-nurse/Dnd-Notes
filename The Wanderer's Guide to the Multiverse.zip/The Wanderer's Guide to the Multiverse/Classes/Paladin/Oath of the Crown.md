---
aliases:
  - Crown Paladin
---
**Class**: [[Paladin]] 

**_The Oath of the Crown is sworn to the ideals of civilization, be it the spirit of a nation, fealty to a sovereign, or service to a deity of law and rulership. The paladins who swear this oath dedicate themselves to serving society and, in particular, the just laws that hold society together. These paladins are the watchful guardians on the walls, standing against the chaotic tides of barbarism that threaten to tear down all that civilization has built, and are commonly known as guardians, exemplars, or sentinels. Often, paladins who swear this oath are members of an order of knighthood in service to a nation or a sovereign, and undergo their oath as part of their admission to the order's ranks._**

Source: Sword Coast Adventurer's Guide

### Tenets of the Crown

The tenets of the Oath of the Crown are often set by the sovereign to which their oath is sworn, but generally emphasize the following tenets.

**_Law._** The law is paramount. It is the mortar that holds the stones of civilization together, and it must be respected.

**_Loyalty._** Your word is your bond. Without loyalty, oaths and laws are meaningless.

**_Courage._** You must be willing to do what needs to be done for the sake of order, even in the face of overwhelming odds. If you don't act, then who will?

**_Responsibility._** You must deal with the consequences of your actions, and you are responsible for fulfilling your duties and obligations.

### Oath Spells

You gain oath spells at the paladin levels listed.

| Oath of the Crown Spells |                                            |
| ------------------------ | ------------------------------------------ |
| Paladin Level            | Spells                                     |
| 3rd                      | [[Command]], [[Compelled Duel]]            |
| 5th                      | [[Warding Bond]], [[Zone of Truth]]        |
| 9th                      | [[Aura of Vitality]], [[Spirit Guardians]] |
| 13th                     | [[Banishment]], [[Guardian of Faith]]      |
| 17th                     | [[Circle of Power]], [[Geas]]              |

### Channel Divinity

When you take this oath at 3rd level, you gain the following two Channel Divinity options.

- **_Champion Challenge._** As a [[Bonus Action]], you issue a challenge that compels other creatures to do battle with you. Each creature of your choice that you can see within **30 feet** of you must make a **[[Wisdom]] saving throw**. On a failed save, a creature can't willingly move more than **30 feet** away from you. This effect ends on the creature if you are [[Incapacitated]] or die or if the creature is more than **30 feet** away from you.

- **_Turn the Tide._** As a [[Bonus Action]], you can bolster injured creatures with your Channel Divinity. Each creature of your choice that can hear you **within** **30 feet** of you regains [[Hit Points]] equal to **1d6 + your [[Charisma]] modifier** (minimum of 1) if it has no more than half of its hit points.

### Divine Allegiance

Starting at 7th level, when a creature within 5 feet of you takes damage, you can use your [[Reaction]] to magically substitute your own health for that of the target creature, causing that creature not to take the damage. Instead, you take the damage. This damage to you can't be reduced or prevented in any way.

### Unyielding Saint

Starting at 15th level, you have [[Advantage]] on saving throws to avoid becoming [[Paralyzed]] or [[Stunned]]. 

### Exalted Champion

At 20th level, your presence on the field of battle is an inspiration to those dedicated to your cause. You can use your action to gain the following benefits for **1 hour**:

- You have **resistance** to [[Bludgeoning]], [[Piercing]], and [[Slashing]] damage from nonmagical weapons.

- Your allies have [[Advantage]] on [[Death Saving Throw|Death Saving Throws]] while within 30 feet of you.

- You have [[Advantage]] on **[[Wisdom]] saving throws**, as do your allies within **30 feet** of you.

This effect ends early if you are [[Incapacitated]] or die. Once you use this feature, you can't use it again until you finish a [[Long Rest]]. 