---
aliases:
---
**Class**: [[Artificer]] 

**_An Artillerist specializes in using magic to hurl energy, projectiles, and explosions on a battlefield. This destructive power is valued by armies in the wars on many different worlds. And when war passes, some members of this specialization seek to build a more peaceful world by using their powers to fight the resurgence of strife. The world-hopping gnome artificer Vi has been especially vocal about making things right: "It's about time we fixed things instead of blowing them all to hell."_**

Source: Tasha's Cauldron of Everything/Eberron: Rising from the Last War

### Tool Proficiency

When you adopt this specialization at 3rd level, you gain proficiency with [[Woodcarver's Tools]]. If you already have this proficiency, you gain proficiency with one other type of [[Artisan's Tools]] of your choice.

### Artillerist Spells

Starting at 3rd level, you always have certain spells prepared after you reach particular levels in this class, as shown in the Artillerist Spells table. These spells count as artificer spells for you, but they don’t count against the number of artificer spells you prepare.

| Artillerist Spells |                                                      |
| ------------------ | ---------------------------------------------------- |
| Artificer Level    | Artillerist Spells                                   |
| 3rd                | [[The Wanderer's Guide to the Multiverse/Spells/Shield\|Shield]], [[Thunderwave]] |
| 5th                | [[Scorching Ray]], [[Shatter]]                       |
| 9th                | [[Fireball]], [[Wind Wall]]                          |
| 13th               | [[Ice Storm]], [[Wall of Fire]]                      |
| 17th               | [[Cone of Cold]], [[Wall of Force]]                  |

### Eldritch Cannon

Also at 3rd level, you've learned how to create a magical cannon. Using [[Woodcarver's Tools]] or [[Smith's Tools]], you can take an [[Action]] to magically create a Small or Tiny eldritch cannon in an unoccupied space on a horizontal surface within 5 feet of you. A Small eldritch cannon occupies its space, and a Tiny one can be held in one hand. Once you create a cannon, you can't do so again until you finish a [[Long Rest]] or until you expend a spell slot to create one. You can have only one cannon at a time and can't create one while your cannon is present.

The cannon is a magical object. Regardless of size, the cannon has an AC of 18 and a number of hit points equal to five times your artificer level. It is immune to [[The Wanderer's Guide to the Multiverse/Dictionary/Damage Types/Poison]] damage and [[Psychic]] damage. If it is forced to make an ability check or a saving throw, treat all its ability scores as 10 (+0). If the [[Mending]] spell is cast on it, it regains 2d6 hit points. It disappears if it is reduced to 0 hit points or after 1 hour. You can dismiss it early as an [[Action]].

When you create the cannon, you determine its appearance and whether it has legs. You also decide which type it is, choosing from the options on the Eldritch Cannons table. On each of your turns, you can take a [[Bonus Action]] to cause the cannon to activate if you are within 60 feet of it. As part of the same [[Bonus Action]], you can direct the cannon to walk or climb up to 15 feet to an unoccupied space, provided it has legs.

| Eldritch Cannon |                                                                                                                                                                                                                                                                                                                                                     |
| --------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Cannon          | Activation                                                                                                                                                                                                                                                                                                                                          |
| Flamethrower    | The cannon exhales fire in an adjacent 15-foot cone that you designate. Each creature in that area must make a [[Dexterity]] saving throw against your spell save DC, taking 2d8 [[Fire]] damage on a failed save or half as much damage on a successful one. The fire ignites any flammable objects in the area that aren't being worn or carried. |
| Force Ballista  | Make a ranged spell attack, originating from the cannon, at one creature or object within 120 feet of it. On a hit, the target takes 2d8 [[Force]] damage, and if the target is a creature, it is pushed up to 5 feet away from the cannon.                                                                                                         |
| Protector       | The cannon emits a burst of positive energy that grants itself and each creature of your choice within 10 feet of it a number of [[Temporary Hit Points]] equal to 1d8 + your [[Intelligence]] modifier (minimum of +1).                                                                                                                            |

### Arcane Firearm

At 5th level, You know how to turn a wand, staff, or rod into an arcane firearm, a conduit for your destructive spells. When you finish a [[Long Rest]], you can use [[Woodcarver's Tools]] to carve special sigils into a wand, staff, or rod and thereby turn it into your arcane firearm. The sigils disappear from the object if you later carve them on a different item. The sigils otherwise last indefinitely.

You can use your arcane firearm as a spellcasting focus for your [[Artificer Spells]]. When you cast an artificer spell through the firearm, roll a d8, and you gain a bonus to one of the spell's damage rolls equal to the number rolled.

### Explosive Cannon

Starting at 9th level, every eldritch cannon you create is more destructive:

- The cannon's damage rolls all increase by 1d8.

- As an [[Action]], you can command the cannon to detonate if you are within 60 feet of it. Doing so destroys the cannon and forces each creature within 20 feet of it to make a [[Dexterity]] saving throw against your spell save DC, taking 3d8 [[Force]] damage on a failed save or half as much damage on a successful one.

### Fortified Position

By 15th level, you’re a master at forming well-defended emplacements using Eldritch Cannon:

- You and your allies have half cover while within 10 feet of a cannon you create with Eldritch Cannon, as a result of a shimmering field of magical protection that the cannon emits.

- You can now have two cannons at the same time. You can create two with the same [[Action]] (but not the same spell slot), and you can activate both of them with the same [[Bonus Action]]. You determine whether the cannons are identical to each other or different. You can't create a third cannon while you have two.