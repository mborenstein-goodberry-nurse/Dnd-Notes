---
aliases:
  - Storm Sorcerer
---
**Class**: [[Sorcerer]] 

**_Your innate magic comes from the power of elemental air. Many with this power can trace their magic back to a near-death experience caused by the Great Rain, but perhaps you were born during a howling gale so powerful that folk still tell stories of it, or your lineage might include the influence of potent air creatures such as vaati or djinn. Whatever the case, the magic of the storm permeates your being._**

**_Storm sorcerers are invaluable members of a ship's crew. Their magic allows them to exert control over wind and weather in their immediate area. Their abilities also prove useful in repelling attacks by sahuagin, pirates, and other waterborne threats._**

Source: Sword Coast Adventurer's Guide, Xanathar's Guide to Everything

### Wind Speaker

The arcane magic you command is infused with elemental air. You can speak, read, and write [[Primordial]]. Knowing this language allows you to understand and be understood by those who speak its dialects: [[Aquan]], [[Auran]], [[Ignan]], and [[Terran]].

### Tempestuous Magic

Starting at 1st level, you can use a [[Bonus Action]] on your turn to cause whirling gusts of elemental air to briefly surround you, immediately before or after you cast a spell of 1st level or higher. Doing so allows you to fly up to **10 feet** without provoking [[Opportunity Attack|Opportunity Attacks]].

### Heart of the Storm

At 6th level, you gain resistance to lightning and thunder damage. In addition, whenever you start casting a spell of 1st level or higher that deals [[Lightning]] or [[Thunder]] damage, stormy magic erupts from you. This eruption causes creatures of your choice that you can see within **10 feet** of you to take lightning or thunder damage (choose each time this ability activates) equal to **half** your sorcerer level.

### Storm Guide

At 6th level, you gain the ability to subtly control the weather around you.

If it is raining, you can use an [[Action]] to cause the rain to stop falling in a **20-foot-radius** **sphere** centered on you. You can end this effect as a [[Bonus Action]].

If it is windy, you can use a [[Bonus Action]] each round to choose the direction that the wind blows in a **100-foot-radius** **sphere** centered on you. The wind blows in that direction until the end of your next turn. This feature doesn't alter the speed of the wind.

### Storm's Fury

Starting at 14th level, when you are hit by a melee attack, you can use your [[Reaction]] to deal [[Lightning]] damage to the attacker. The damage equals your sorcerer level. The attacker must also make a **[[Strength]] saving throw** against your sorcerer spell save DC. On a failed save, the attacker is pushed in a straight line **up to 20 feet** away from you.

### Wind Soul

At 18th level, you gain **immunity** to [[Lightning]] and [[Thunder]] damage.

You also gain a magical flying speed of **60 feet**. As an [[Action]], you can reduce your flying speed to **30 feet** for **1 hour** and choose a number of creatures within **30 feet** of you equal to **3 + your [[Charisma]] modifier**. The chosen creatures gain a magical flying speed of **30 feet** for **1 hour**. Once you reduce your flying speed in this way, you can't do so again until you finish a [[Short Rest|short]] or [[Long Rest]].