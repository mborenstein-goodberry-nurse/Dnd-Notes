---
aliases:
---
**Class**: [[Sorcerer]] 

**_Sometimes the spark of magic that fuels a sorcerer comes from a divine source that glimmers within the soul. Having such a blessed soul is a sign that your innate magic might come from a distant but powerful familial connection to a divine being. Perhaps your ancestor was an angel, transformed into a mortal and sent to fight in a god’s name. Or your birth might align with an ancient prophecy, marking you as a servant of the gods or a chosen vessel of divine magic._**

**_A Divine Soul, with natural magnetism, is seen as a threat by some religious hierarchies. As an outsider who commands celestial power, these sorcerers can undermine the existing order by claiming a direct tie to the divine._**

**_In some cultures, only those who can claim the power of a Divine Soul may command religious power. In these lands, ecclesiastical positions are dominated by a few bloodlines and preserved over generations._**

Source: Xanathar's Guide to Everything

### Divine Magic

Your link to the divine allows you to learn spells normally associated with the cleric class. When your Spellcasting feature lets you learn a sorcerer cantrip or a sorcerer spell of 1st level or higher, you can choose the new spell from the [[Cleric Spells|cleric spell list]] or the [[Sorcerer Spells|sorcerer spell list]]. You must otherwise obey all the restrictions for selecting the spell, and it becomes a sorcerer spell for you.

In addition, choose an affinity for the source of your divine power: good, evil, law, chaos, or neutrality. You learn an additional spell based on that affinity, as shown below. It is a sorcerer spell for you, but it doesn't count against your number of sorcerer spells known. If you later replace this spell, you must replace it with a spell from the cleric spell list.

| Affinity   | Spell                             |
| ---------- | --------------------------------- |
| Good       | [[Cure Wounds]]                   |
| Evil       | [[Inflict Wounds]]                |
| Law        | [[Bless]]                         |
| Chaos      | [[Bane]]                          |
| Neutrality | [[Protection from Evil and Good]] |

### Favored by the Gods

Starting at 1st level, divine power guards your destiny. If you fail a saving throw or miss with an attack roll, you can roll **2d4** and add it to the total, possibly changing the outcome.

Once you use this feature, you can't use it again until you finish a [[Short Rest|short]] or [[Long Rest]].

### Empowered Healing

Starting at 6th level, the divine energy coursing through you can empower healing spells. Whenever you or an ally within **5 feet** of you rolls dice to determine the number of [[Hit Points]] a spell restores, you can spend 1 sorcery point to reroll any number of those dice once, provided you aren't [[Incapacitated]]. You can use this feature only once per turn.

### Angelic Form

Starting at 14th level, you can use a [[Bonus Action]] to manifest a pair of spectral wings from your back. While the wings are present, you have a flying speed of **30 feet**. The wings last until you're [[Incapacitated]], you die, or you dismiss them as a [[Bonus Action]].

The affinity you chose for your Divine Magic feature determines the appearance of the spectral wings: eagle wings for good or law, bat wings for evil or chaos, and dragonfly wings for neutrality.

### Unearthly Recovery

At 18th level, you gain the ability to overcome grievous injuries. As a [[Bonus Action]] when you have fewer than half of your [[Hit Points]] remaining, you can regain a number of [[Hit Points]] equal to half your hit point maximum.

Once you use this feature, you can’t use it again until you finish a [[Long Rest]].