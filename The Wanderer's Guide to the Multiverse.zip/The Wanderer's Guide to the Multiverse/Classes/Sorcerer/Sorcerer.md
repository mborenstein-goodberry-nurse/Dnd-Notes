---
aliases:
  - Sorcerers
---
# Sorcerer

**_Sorcerers carry a magical birthright conferred upon them by an exotic bloodline, some otherworldly influence, or exposure to unknown cosmic forces. No one chooses sorcery; the power chooses the sorcerer._**

_You must have a [[Charisma]] score of 13 or higher in order to multiclass in or out of this class._
## Sorcerer Table

| Level | Proficiency Bonus | Sorcery Points | Features                                                                | Cantrips Known | Spells Known | 1st | 2nd | 3rd | 4th | 5th | 6th | 7th | 8th | 9th |
| ----- | ----------------- | -------------- | ----------------------------------------------------------------------- | -------------- | ------------ | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1st   | +2                | -              | [[#Spellcasting]], [[#Sorcerous Origin]]                                | 4              | 2            | 2   | -   | -   | -   | -   | -   | -   | -   | -   |
| 2nd   | +2                | 2              | [[#Font of Magic]]                                                      | 4              | 3            | 3   | -   | -   | -   | -   | -   | -   | -   | -   |
| 3rd   | +2                | 3              | [[#Metamagic]]                                                          | 4              | 4            | 4   | 2   | -   | -   | -   | -   | -   | -   | -   |
| 4th   | +2                | 4              | [[#Ability Score Improvement]], _[[#Sorcerous Versatility (Optional)]]_ | 5              | 5            | 4   | 3   | -   | -   | -   | -   | -   | -   | -   |
| 5th   | +3                | 5              | _[[#Magical Guidance (Optional)]]_                                      | 5              | 6            | 4   | 3   | 2   | -   | -   | -   | -   | -   | -   |
| 6th   | +3                | 6              | Sorcerous Origin feature                                                | 5              | 7            | 4   | 3   | 3   | -   | -   | -   | -   | -   | -   |
| 7th   | +3                | 7              |                                                                         | 5              | 8            | 4   | 3   | 3   | 1   | -   | -   | -   | -   | -   |
| 8th   | +3                | 8              | [[#Ability Score Improvement]], _[[#Sorcerous Versatility (Optional)]]_ | 5              | 9            | 4   | 3   | 3   | 2   | -   | -   | -   | -   | -   |
| 9th   | +4                | 9              |                                                                         | 5              | 10           | 4   | 3   | 3   | 3   | 1   | -   | -   | -   | -   |
| 10th  | +4                | 10             | [[#Metamagic]]                                                          | 6              | 11           | 4   | 3   | 3   | 3   | 2   | -   | -   | -   | -   |
| 11th  | +4                | 11             |                                                                         | 6              | 12           | 4   | 3   | 3   | 3   | 2   | 1   | -   | -   | -   |
| 12th  | +4                | 12             | [[#Ability Score Improvement]], _[[#Sorcerous Versatility (Optional)]]_ | 6              | 12           | 4   | 3   | 3   | 3   | 2   | 1   | -   | -   | -   |
| 13th  | +5                | 13             |                                                                         | 6              | 13           | 4   | 3   | 3   | 3   | 2   | 1   | 1   | -   | -   |
| 14th  | +5                | 14             | Sorcerous Origin feature                                                | 6              | 13           | 4   | 3   | 3   | 3   | 2   | 1   | 1   | -   | -   |
| 15th  | +5                | 15             |                                                                         | 6              | 14           | 4   | 3   | 3   | 3   | 2   | 1   | 1   | 1   | -   |
| 16th  | +5                | 16             | [[#Ability Score Improvement]], _[[#Sorcerous Versatility (Optional)]]_ | 6              | 14           | 4   | 3   | 3   | 3   | 2   | 1   | 1   | 1   | -   |
| 17th  | +6                | 17             | [[#Metamagic]]                                                          | 6              | 15           | 4   | 3   | 3   | 3   | 2   | 1   | 1   | 1   | 1   |
| 18th  | +6                | 18             | Sorcerous Origin feature                                                | 6              | 15           | 4   | 3   | 3   | 3   | 3   | 1   | 1   | 1   | 1   |
| 19th  | +6                | 19             | [[#Ability Score Improvement]], _[[#Sorcerous Versatility (Optional)]]_ | 6              | 15           | 4   | 3   | 3   | 3   | 3   | 2   | 1   | 1   | 1   |
| 20th  | +6                | 20             | [[#Sorcerous Restoration]]                                              | 6              | 15           | 4   | 3   | 3   | 3   | 3   | 2   | 2   | 1   | 1   |

# Class Features

As a sorcerer, you gain the following class features.

##### Hit Points

**[[Hit Dice]]:** 1d6 per sorcerer level  
**[[Hit Points]] at 1st Level:** 6 + your [[Constitution]] modifier  
**[[Hit Points]] at Higher Levels:** 1d6 (or 4) + your [[Constitution]] modifier per sorcerer level after 1st

##### Proficiencies

**Armor:** None  
**Weapons:** Daggers, darts, slings, quarterstaffs, light crossbows  
**Tools:** None  
**Saving Throws:** [[Constitution]], [[Charisma]]  
**Skills:** Choose two from [[Arcana]], [[Deception]], [[Insight]], [[Intimidation]], [[Persuasion]], and [[Religion]]

##### Equipment

You start with the following equipment, in addition to the equipment granted by your background:

- (a) a light crossbow and 20 bolts or (b) any [[Simple Weapon]]
- (a) a component pouch or (b) an arcane focus
- (a) a [[Dungeoneer's Pack]] or (b) an [[Explorer's Pack]]
- Two daggers

### Spellcasting

An event in your past, or in the life of a parent or ancestor, left an indelible mark on you, infusing you with arcane magic. This font of magic, whatever its origin, fuels your spells.

##### Cantrips

At 1st level, you know four cantrips of your choice from the [[Sorcerer Spells#Cantrip|sorcerer spell list]]. You learn additional sorcerer cantrips of your choice at higher levels, as shown in the Cantrips Known column of the Sorcerer table.

##### Spell Slots

The Sorcerer table shows how many spell slots you have to cast your [[Sorcerer Spells]] of 1st level and higher. To cast one of these sorcerer spells, you must expend a slot of the spell's level or higher. You regain all expended spell slots when you finish a [[Long Rest]].

For example, if you know the 1st-level spell _[[Burning Hands]]_ and have a 1st-level and a 2nd-level spell slot available, you can cast _[[Burning Hands]]_ using either slot.

##### Spells Known of 1st Level and Higher

You know two 1st-level spells of your choice from the [[Sorcerer Spells|sorcerer spell list]].

The Spells Known column of the Sorcerer table shows when you learn more sorcerer spells of your choice. Each of these spells must be of a level for which you have spell slots. For instance, when you reach 3rd level in this class, you can learn one new spell of 1st or 2nd level.

Additionally, when you gain a level in this class, you can choose one of the sorcerer spells you know and replace it with another spell from the sorcerer spell list, which also must be of a level for which you have spell slots.

##### Spellcasting Ability

[[Charisma]] is your spellcasting ability for your [[Sorcerer Spells]], since the power of your magic relies on your ability to project your will into the world. You use your [[Charisma]] whenever a spell refers to your spellcasting ability. In addition, you use your [[Charisma]] modifier when setting the saving throw DC for a sorcerer spell you cast and when making an attack roll with one.

**Spell save DC** = 8 + your [[Proficiency Bonus]] + your [[Charisma]] modifier

**Spell attack modifier** = your [[Proficiency Bonus]] + your [[Charisma]] modifier

##### Spellcasting Focus

You can use an arcane focus as a spellcasting focus for your [[Sorcerer Spells]].

### Sorcerous Origin

Choose a sorcerous origin, which describes the source of your innate magical power. Your choice grants you features when you choose it at 1st level and again at 6th, 14th, and 18th level.

| Origin                 | Source                                                             |
| ---------------------- | ------------------------------------------------------------------ |
| [[Abberant Mind]]      | Tasha's Cauldron of Everything                                     |
| [[Clockwork Soul]]     | Tasha's Cauldron of Everything                                     |
| [[Draconic Bloodline]] | Player's Handbook                                                  |
| [[Divine Soul]]        | Xanathar's Guide to Everything                                     |
| [[Lunar Sorcery]]      | Dragonlance: Shadow of the Dragon Queen                            |
| [[Shadow Magic]]       | Xanathar's Guide to Everything                                     |
| [[Storm Sorcery]]      | Sword Coast Adventurer's Guide  <br>Xanathar's Guide to Everything |
| [[Wild Magic]]         | Player's Handbook                                                  |

### Font of Magic

At 2nd level, you tap into a deep wellspring of magic within yourself. This wellspring is represented by sorcery points, which allow you to create a variety of magical effects.

- **Sorcery Points.** You have 2 sorcery points, and you gain more as you reach higher levels, as shown in the Sorcery Points column of the [[#Sorcerer table]]. You can never have more sorcery points than shown on the table for your level. You regain all spent sorcery points when you finish a [[Long Rest]].

- **Flexible Casting.** You can use your sorcery points to gain additional spell slots, or sacrifice spell slots to gain additional sorcery points. You learn other ways to use your sorcery points as you reach higher levels.
    - **_Creating Spell Slots._** You can transform unexpended sorcery points into one spell slot as a [[Bonus Action]] on your turn. The Creating Spell Slots table shows the cost of creating a spell slot of a given level. You can create spell slots no higher in level than 5th. Any spell slot you create with this feature vanishes when you finish a [[Long Rest]].
    - **_Converting a Spell Slot to Sorcery Points._** As a [[Bonus Action]] on your turn, you can expend one spell slot and gain a number of sorcery points equal to the slot's level.

|Creating Spell Slots|   |
|---|---|
|Spell Slot Level|Sorcery Point Cost|
|1st|2|
|2nd|3|
|3rd|5|
|4th|6|
|5th|7|

### Metamagic

At 3rd level, you gain the ability to twist your spells to suit your needs. You gain two of the following Metamagic options of your choice. You gain another one at 10th and 17th level.

You can use only one Metamagic option on a spell when you cast it, unless otherwise noted.

- **Careful Spell.** When you cast a spell that forces other creatures to make a saving throw, you can protect some of those creatures from the spell's full force. To do so, you spend 1 sorcery point and choose a number of those creatures up to your [[Charisma]] modifier (minimum of one creature). A chosen creature automatically succeeds on its saving throw against the spell.

- **Distant Spell.** When you cast a spell that has a range of **5 feet** or greater, you can spend 1 sorcery point to **double** the range of the spell.
    - When you cast a spell that has a range of touch, you can spend 1 sorcery point to make the range of the spell **30 fee**t.

- **Empowered Spell.** When you roll damage for a spell, you can spend 1 sorcery point to reroll a number of the damage dice up to your [[Charisma]] modifier (minimum of one). You must use the new rolls.
    - You can use Empowered Spell even if you have already used a different Metamagic option during the casting of the spell.

- **Extended Spell.** When you cast a spell that has a duration of **1 minute** or longer, you can spend 1 sorcery point to double its duration, to a maximum duration of **24 hours**.

- **Heightened Spell.** When you cast a spell that forces a creature to make a saving throw to resist its effects, you can spend 3 sorcery points to give one target of the spell [[Disadvantage]] on its first saving throw made against the spell.

- **Quickened Spell.** When you cast a spell that has a casting time of 1 [[Action]], you can spend 2 sorcery points to change the casting time to 1 [[Bonus Action]] for this casting.

- **Seeking Spell.** If you make an attack roll for a spell and miss, you can spend 2 sorcery points to reroll the d20, and you must use the new roll.
    - You can use Seeking Spell even if you have already used a different Metamagic option during the casting of the spell.

- **Subtle Spell.** When you cast a spell, you can spend 1 sorcery point to cast it without any somatic or verbal components.

- **Transmuted Spell.** When you cast a spell that deals a type of damage from the following list, you can spend 1 sorcery point to change that damage type to one of the other listed types: [[Acid]], [[Cold]], [[Fire]], [[Lightning]], [[The Wanderer's Guide to the Multiverse/Dictionary/Damage Types/Poison]], [[Thunder]].

- **Twinned Spell.** When you cast a spell that targets only one creature and doesn't have a range of self, you can spend a number of sorcery points equal to the spell's level to target a second creature in range with the same spell (1 sorcery point if the spell is a cantrip). To be eligible, a spell must be incapable of targeting more than one creature at the spell's current level. For example, _[[Magic Missile]]_ and _[[Scorching Ray]]_ aren't eligible, but _[[Ray of Frost]]_ and _[[Chromatic Orb]]_ are.

### Ability Score Improvement

When you reach 4th level, and again at 8th, 12th, 16th, and 19th level, you can increase one ability score of your choice by 2, or you can increase two ability scores of your choice by 1. As normal, you can't increase an ability score above 20 using this feature.

### Sorcerous Versatility (Optional)

When you reach a level in this class that grants the Ability Score Improvement feature, you can do one of the following, representing the magic within you flowing in new ways:

- Replace one of the options you chose for the Metamagic feature with a different Metamagic option available to you.

- Replace one cantrip you learned from this class' spellcasting feature with another cantrip from the sorcerer spell list.

### Magical Guidance (Optional)

When you reach 5th level, you can tap into your inner wellspring of magic to try and conjure success from failure. When you make an ability check that fails, you can spend 1 sorcery point to reroll the d20, and you must use the new roll, potentially turning the failure into a success.

### Sorcerous Restoration

At 20th level, you regain **4** expended sorcery points whenever you finish a [[Short Rest]].