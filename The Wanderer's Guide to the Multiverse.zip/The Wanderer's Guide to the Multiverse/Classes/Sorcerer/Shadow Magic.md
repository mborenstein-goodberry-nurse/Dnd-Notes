---
aliases:
  - Shadow Sorcerer
---
**Class**: [[Sorcerer]] 

**_You are a creature of shadow, for your innate magic comes from the Shadowfell itself. You might trace your lineage to an entity from that place, or perhaps you were exposed to its fell energy and transformed by it._**

_**The power of shadow magic casts a strange pall over your physical presence. The spark of life that sustains you is muffled, as if it struggles to remain viable against the dark energy that imbues your soul.**_

Source: Xanathar's Guide to Everything

### Shadow Sorcerer Quirks

At your option, you can pick from or roll on the Shadow Sorcerer Quirks table to create a quirk for your character.

|d6|Quirk|
|---|---|
|1|You are always icy cold to the touch.|
|2|When you are asleep, you don't appear to breathe (though you must still breathe to survive).|
|3|You barely bleed, even when badly injured.|
|4|Your heart beats once per minute. This event sometimes surprises you.|
|5|You have trouble remembering that living creatures and corpses should be treated differently.|
|6|You blinked. Once. Last week.|

### Eyes of the Dark

From 1st level, you have **darkvision** with a range of **120 feet**.

When you reach 3rd level in this class, you learn the _[[Darkness]]_ spell, which doesn't count against your number of sorcerer spells known. In addition, you can cast it by spending 2 sorcery points or by expending a spell slot. If you cast it with sorcery points, you can see through the darkness created by the spell.

### Strength of the Grave

Starting at 1st level, your existence in a twilight state between life and death makes you difficult to defeat. When damage reduces you to 0 hit points, you can make a **[[Charisma]] saving throw** (DC 5 + the damage taken). On a success, you instead drop to 1 hit point. You can't use this feature if you are reduced to 0 hit points by [[Radiant]] damage or by a [[Critical Hit]].

After the saving throw succeeds, you can't use this feature again until you finish a [[Long Rest]].

### Hound of Ill Omen

At 6th level, you gain the ability to call forth a howling creature of darkness to harass your foes. As a [[Bonus Action]], you can spend 3 sorcery points to summon a hound of ill omen to target one creature you can see within **120 feet** of you. The hound uses the dire wolf's statistics, with the following changes:

- The hound is size Medium, not Large, and it counts as a monstrosity, not a beast.

- It appears with a number of [[Temporary Hit Points]] equal to half your sorcerer level.

- It can move through other creatures and objects as if they were [[Difficult Terrain]]. The hound takes **5 [[Force]]** damage if it ends its turn inside an object.

- At the start of its turn, the hound automatically knows its target's location. If the target was hidden, it is no longer hidden from the hound.

The hound appears in an unoccupied space of your choice within **30 feet** of the target. Roll [[The Wanderer's Guide to the Multiverse/Gameplay/Initiative]] for the hound. On its turn, it can move only toward its target by the most direct route, and it can use its [[Action]] only to attack its target. The hound can make [[Opportunity Attack|Opportunity Attacks]], but only against its target. Additionally, while the hound is within **5 feet** of the target, the target has [[Disadvantage]] on saving throws against any spell you cast. The hound disappears if it is reduced to 0 hit points, if its target is reduced to 0 hit points, or after **5 minutes**.

### Shadow Walk

At 14th level, you gain the ability to step from one shadow into another. When you are in dim light or darkness, as a [[Bonus Action]], you can teleport up to **120 feet** to an unoccupied space you can see that is also in dim light or darkness.

### Umbral Form

Starting at 18th level, you can spend 6 sorcery points as a bonus action to transform yourself into a shadowy form. In this form, you have resistance to all damage except [[Force]] and [[Radiant]] damage, and you can move through other creatures and objects as if they were [[Difficult Terrain]]. You take **5 [[Force]]** damage if you end your turn inside an object.

You remain in this form for **1 minute**. It ends early if you are [[Incapacitated]], if you die, or if you dismiss it as a [[Bonus Action]].