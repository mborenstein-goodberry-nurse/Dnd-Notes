---
aliases:
  - Nature Cleric
---
**Class**: [[Cleric]] 

**_Gods of nature are as varied as the natural world itself; from inscrutable gods of the deep forests (such as Silvanus, Obad-Hai, Chislev, Balinor, and Pan) to friendly deities associated with particular springs and groves (such as Eldath). Druids revere nature as a whole and might serve one of these deities, practicing mysterious rites and reciting all-but-forgotten prayers in their own secret tongue. But many of these gods have clerics as well, champions who take a more active role in advancing the interests of a particular nature god. These clerics might hunt the evil monstrosities that despoil the woodlands, bless the harvest of the faithful, or wither the crops of those who anger their gods._**

Source: Player's Handbook

| Nature Domain Spells |                                               |
| -------------------- | --------------------------------------------- |
| Cleric Level         | Spells                                        |
| 1st                  | [[Animal Friendship]], [[Speak with Animals]] |
| 3rd                  | [[Barkskin]], [[Spike Growth]]                |
| 5th                  | [[Plant Growth]], [[Wind Wall]]               |
| 7th                  | [[Dominate Beast]], [[Grasping Vine]]         |
| 9th                  | [[Insect Plague]], [[Tree Stride]]            |

### Acolyte of Nature

At 1st level, you learn one cantrip of your choice from the [[Druid Spells#Cantrip|druid spell list]]. This cantrip counts as a cleric cantrip for you, but it doesn’t count against the number of cleric cantrips you know. You also gain proficiency in one of the following skills of your choice: [[Animal Handling]], [[Nature]], or [[Survival]].

### Bonus Proficiency

Also at 1st level, you gain proficiency with [[Heavy Armor]].

### Channel Divinity: Charm Animals and Plants

Starting at 2nd level, you can use your Channel Divinity to charm animals and plants.

As an [[Action]], you present your holy symbol and invoke the name of your deity. Each beast or plant creature that can see you within 30 feet of you must make a **[[Wisdom]] saving throw**. If the creature fails its saving throw, it is [[Charmed]] by you for 1 minute or until it takes damage. While it is [[Charmed]] by you, it is friendly to you and other creatures you designate.

### Dampen Elements

Starting at 6th level, when you or a creature within 30 feet of you takes [[Acid]], [[Cold]], [[Fire]], [[Lightning]], or [[Thunder]] damage, you can use your [[Reaction]] to grant resistance to the creature against that instance of the damage.

### Divine Strike

At 8th level, you gain the ability to infuse your weapon strikes with divine energy. Once on each of your turns when you hit a creature with a weapon attack, you can cause the attack to deal an extra **1d8 [[Cold]], [[Fire]], or [[Lightning]]** damage (your choice) to the target. When you reach 14th level, the extra damage increases to **2d8**.

### Master of Nature

At 17th level, you gain the ability to command animals and plant creatures. While creatures are [[Charmed]] by your [[#Channel Divinity: Charm Animals and Plants|Charm Animals and Plants]] feature, you can take a [[Bonus Action]] on your turn to verbally command what each of those creatures will do on its next turn.