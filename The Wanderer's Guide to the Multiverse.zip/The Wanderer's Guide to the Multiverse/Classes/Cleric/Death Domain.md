---
aliases:
  - Death Cleric
---
**Class**: [[Cleric]] 

**_The Death domain is concerned with the forces that cause death, as well as the negative energy that gives rise to undead creatures. Deities such as Chemosh, Myrkul, and Wee Jas are patrons of necromancers, death knights, liches, mummy lords, and vampires. Gods of the Death domain also embody murder (Anubis, Bhaal, and Pyremius), pain (Iuz or Loviatar), disease or poison (Incabulos, Talona, or Morgion), and the underworld (Hades and Hel)._**

Source: Dungeon Master's Guide

| Death Domain Spells |                                                 |
| ------------------- | ----------------------------------------------- |
| Cleric Level        | Spells                                          |
| 1st                 | [[False Life]], [[Ray of Sickness]]             |
| 3rd                 | [[Blindness-Deafness]], [[Ray of Enfeeblement]] |
| 5th                 | [[Animate Dead]], [[Vampiric Touch]]            |
| 7th                 | [[Blight]], [[Death Ward]]                      |
| 9th                 | [[Antilife Shell]], [[Cloudkill]]               |

### Bonus Proficiency

When you choose this domain at 1st level, you gain proficiency with [[Martial Weapon|Martial Weapons]].

### Reaper

At 1st level, you learn one necromancy cantrip of your choice from [[All Spells|any spell list]]. When you cast a [[Necromancy#Cantrip|necromancy cantrip]] that normally targets only one creature, the spell can instead target two creatures within range and within 5 feet of each other.

### Channel Divinity: Touch of Death

Starting at 2nd level, you can use Channel Divinity to destroy another creature's life force by touch. When you hit a creature with a melee attack, you can use Channel Divinity to deal extra [[Necrotic]] damage to the target. The damage equals 5 + twice your cleric level.

### Inescapable Destruction

Starting at 6th level, your ability to channel negative energy becomes more potent. [[Necrotic]] damage dealt by your cleric spells and Channel Divinity options ignores resistance to [[Necrotic]] damage.

### Divine Strike

At 8th level, you gain the ability to infuse your weapon strikes with [[Necrotic]] energy. Once on each of your turns when you hit a creature with a weapon attack, you can cause the attack to deal an extra **1d8 [[Necrotic]]** damage to the target. When you reach 14th level, the extra damage increases to 2d8.

### Improved Reaper

Starting at 17th level, when you cast a necromancy spell of 1st through 5th level that targets only one creature, the spell can instead target two creatures within range and within 5 feet of each other. If the spell consumes its material components, you must provide them for each target.