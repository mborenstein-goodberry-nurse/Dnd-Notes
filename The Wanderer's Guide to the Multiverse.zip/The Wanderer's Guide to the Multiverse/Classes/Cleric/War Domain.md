---
aliases:
  - War Cleric
---
**Class**: [[Cleric]] 

**_War has many manifestations. It can make heroes of ordinary people. It can be desperate and horrific, with acts of cruelty and cowardice eclipsing instances of excellence and courage. In either case, the gods of war watch over warriors and reward them for their great deeds. The clerics of such gods excel in battle, inspiring others to fight the good fight or offering acts of violence as prayers. Gods of war include champions of honor and chivalry (such as Torm, Heironeous, and Kiri-Jolith) as well as gods of destruction and pillage (such as Erythnul, the Fury, Gruumsh, and Ares) and gods of conquest and domination (such as Bane, Hextor, and Maglubiyet). Other war gods (such as Tempus, Ni_**_**ke, and Nuada) take a more neutral stance, promoting war in all its manifestations and supporting warriors in any circumstance.**_

Source: Player's Handbook

| War Domain Spells |                                             |
| ----------------- | ------------------------------------------- |
| Cleric Level      | Spells                                      |
| 1st               | [[Divine Favor]], [[Shield of Faith]]       |
| 3rd               | [[Magic Weapon]], [[Spiritual Weapon]]      |
| 5th               | [[Crusader's Mantle]], [[Spirit Guardians]] |
| 7th               | [[Freedom of Movement]], [[Stoneskin]]      |
| 9th               | [[Flame Strike]], [[Hold Monster]]          |

### Bonus Proficiency

At 1st level, you gain proficiency with [[Martial Weapon|Martial Weapons]] and [[Heavy Armor]].

### War Priest

From 1st level, your god delivers bolts of inspiration to you while you are engaged in battle. When you use the [[Attack]] action, you can make one weapon attack as a [[Bonus Action]].

You can use this feature a number of times equal to your [[Wisdom]] modifier (a minimum of once). You regain all expended uses when you finish a [[Long Rest]].

### Channel Divinity: Guided Strike

Starting at 2nd level, you can use your Channel Divinity to strike with supernatural accuracy. When you make an **attack roll**, you can use your Channel Divinity to gain a +**10 bonus** to the roll. You make this choice after you see the roll, but before the DM says whether the attack hits or misses.

### Channel Divinity: War God's Blessing

At 6th level, when a creature within 30 feet of you makes an attack roll, you can use your [[Reaction]] to grant that creature a +10 bonus to the roll, using your [[#Channel Divinity: Guided Strike|Guided Strike]]. You make this choice after you see the roll, but before the DM says whether the attack hits or misses.

### Divine Strike

At 8th level, you gain the ability to infuse your weapon strikes with divine energy. Once on each of your turns when you hit a creature with a weapon attack, you can cause the attack to deal an extra **1d8 damage** of the same type dealt by the weapon to the target. When you reach 14th level, the extra damage increases to **2d8**.

### Avatar of Battle

At 17th level, you gain **resistance** to [[Bludgeoning]], [[Piercing]], and [[Slashing]] damage from nonmagical attacks.