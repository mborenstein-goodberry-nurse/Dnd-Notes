---
aliases:
  - Tempest Cleric
---
**Class**: [[Cleric]] 

**_Gods whose portfolios include the Tempest domain – including Talos, Umberlee, Kord, Zeboim, the Devourer, Zeus, and Thor – govern storms, sea, and, sky. They include gods of lightning and thunder, gods of earthquakes, some fire gods, and certain gods of violence, physical strength, and courage. In some pantheons, a god of this domain rules over other deities and is known for swift justice delivered by thunderbolts. In the pantheons of seafaring people, gods of this domain are ocean deities and the patrons of sailors. Tempest gods send their clerics to inspire fear in the common folk, either to keep those folk on the path of righteousness or to encourage them to offer sacrifices of propitiation to ward off divine wrath._**

Source: Player's Handbook

| Tempest Domain Spells |                                         |
| --------------------- | --------------------------------------- |
| Cleric Level          | Spells                                  |
| 1st                   | [[Fog Cloud]], [[Thunderwave]]          |
| 3rd                   | [[Gust of Wind]], [[Shatter]]           |
| 5th                   | [[Call Lightning]], [[Sleet Storm]]     |
| 7th                   | [[Control Water]], [[Ice Storm]]        |
| 9th                   | [[Destructive Wave]], [[Insect Plague]] |

### Bonus Proficiencies

At 1st level, you gain proficiency with [[Martial Weapon|Martial Weapons]] and [[Heavy Armor]].

### Wrath of the Storm

Also at 1st level, you can thunderously rebuke attackers. When a creature within 5 feet of you that you can see hits you with an attack, you can use your [[Reaction]] to cause the creature to make a **[[Dexterity]] saving throw**. The creature takes **2d8 [[Lightning]] or [[Thunder]]** damage (your choice) on a failed saving throw, and **half** as much damage on a successful one.

You can use this feature a number of times equal to your [[Wisdom]] modifier (a minimum of once). You regain all expended uses when you finish a [[Long Rest]].

### Channel Divinity: Destructive Wrath

Starting at 2nd level, you can use your Channel Divinity to wield the power of the storm with unchecked ferocity.

When you roll [[Lightning]] or [[Thunder]] damage, you can use your Channel Divinity to deal maximum damage, instead of rolling.

### Thunderous Strike

At 6th level, when you deal [[Lightning]] damage to a Large or smaller creature, you can also push it up to 10 feet away from you.

### Divine Strike

At 8th level, you gain the ability to infuse your weapon strikes with divine energy. Once on each of your turns when you hit a creature with a weapon attack, you can cause the attack to deal an extra **1d8 [[Thunder]]** damage to the target. When you reach 14th level, the extra damage increases to **2d8**.

### Stormborn

At 17th level, you have a *flying speed* equal to your current walking speed whenever you are not underground or indoors.