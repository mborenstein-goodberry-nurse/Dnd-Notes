---
aliases:
  - Forge Cleric
---
**Class**: [[Cleric]] 

**_The gods of the forge are patrons of artisans who work with metal, from a humble blacksmith who keeps a village in horseshoes and plow blades to the mighty elf artisan whose diamond-tipped arrows of mithral have felled demon lords. The gods of the forge teach that, with patience and hard work, even the most intractable metal can be transformed from a lump of ore to a beautifully wrought object. Clerics of these deities search for objects lost to the forces of darkness, liberate mines overrun by orcs, and uncover rare and wondrous materials necessary to create potent magic items. Followers of these gods take great pride in their work, and they are willing to craft and use heavy armor and powerful weapons to protect them. Deities of this domain include Gond, Reorx, Onatar, Moradin, Hephaestus, and Goibhniu._**

Source: Xanathar's Guide to Everything

| Forge Domain Spells |                                                  |
| ------------------- | ------------------------------------------------ |
| Cleric Level        | Spells                                           |
| 1st                 | [[Identify]], [[Searing Smite]]                  |
| 3rd                 | [[Heat Metal]], [[Magic Weapon]]                 |
| 5th                 | [[Elemental Weapon]], [[Protection from Energy]] |
| 7th                 | [[Fabricate]], [[Wall of Fire]]                  |
| 9th                 | [[Animate Objects]], [[Creation]]                |

### Bonus Proficiencies

When you choose this domain at 1st level, you gain proficiency with [[Heavy Armor]] and [[Smith's Tools]].

### Blessing of the Forge

At 1st level, you gain the ability to imbue magic into a weapon or armor. At the end of a long rest, you can touch one nonmagical object that is a suit of armor or a [[Simple Weapon|simple]] or [[Martial Weapon|martial weapon]]. Until the end of your next [[Long Rest]] or until you die, the object becomes a magic item, granting a +1 bonus to AC if it's armor or a +1 bonus to attack and damage rolls if it's a weapon.

Once you use this feature, you can't use it again until you finish a [[Long Rest]].

### Channel Divinity: Artisan's Blessing

Starting at 2nd level, you can use your Channel Divinity to create simple items.

You conduct an hour-long [[Ritual]] that crafts a nonmagical item that must include some metal: a simple or martial weapon, a suit of armor, ten pieces of ammunition, a set of tools, or another metal object. The creation is completed at the end of the hour, coalescing in an unoccupied space of your choice on a surface within 5 feet of you.

The thing you create can be something that is worth no more than 100 gp. As part of this ritual, you must lay out metal, which can include coins, with a value equal to the creation. The metal irretrievably coalesces and transforms into the creation at the ritual's end, magically forming even nonmetal parts of the creation.

The ritual can create a duplicate of a nonmagical item that contains metal, such as a key, if you possess the original during the ritual.

### Soul of the Forge

Starting at 6th level, your mastery of the forge grants you special abilities:

- You gain resistance to [[Fire]] damage.

- While wearing [[Heavy Armor]], you gain a +1 bonus to AC.

### Divine Strike

At 8th level, you gain the ability to infuse your weapon strikes with the fiery power of the forge. Once on each of your turns when you hit a creature with a weapon attack, you can cause the attack to deal an extra **1d8 [[Fire]]** damage to the target. When you reach ***14th level***, the extra damage increases to **2d8**.

### Saint of Forge and Fire

At 17th level, your blessed affinity with fire and metal becomes more powerful:

- You gain immunity to [[Fire]] damage.

- While wearing heavy armor, you have resistance to [[Bludgeoning]], [[Piercing]], and [[Slashing]] damage from nonmagical attacks.