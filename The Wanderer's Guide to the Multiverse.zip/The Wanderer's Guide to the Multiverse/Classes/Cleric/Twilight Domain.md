---
aliases:
  - Twilight Cleric
---
**Class**: [[Cleric]] 

**_The twilit transition from light into darkness often brings calm and even joy, as the day's labors end and the hours of rest begin. The darkness can also bring terrors, but the gods of twilight guard against the horrors of the night._**

**_Clerics who serve these deities-examples of which appear on the Twilight Deities table-bring comfort to those who seek rest and protect them by venturing into the encroaching darkness to ensure that the dark is a comfort, not a terror._**

|Twilight Deities|   |
|---|---|
|Example Deity|Pantheon|
|Boldrei|Eberron|
|Celestian|Greyhawk|
|Dol Arrah|Eberron|
|Helm|Forgotten Realms|
|Ilmater|Forgotten Realms|
|Mishakal|Dragonlance|
|Selûne|Forgotten Realms|
|Yondalla|Halfling|

Source: Tasha's Cauldron of Everything

| Twilight Domain Spells |                                              |
| ---------------------- | -------------------------------------------- |
| Cleric Level           | Spells                                       |
| 1st                    | [[Faerie Fire]], [[Sleep]]                   |
| 3rd                    | [[Moonbeam]], [[See Invisibility]]           |
| 5th                    | [[Aura of Vitality]], [[Leomund's Tiny Hut]] |
| 7th                    | [[Aura of Life]], [[Greater Invisibility]]   |
| 9th                    | [[Circle of Power]], [[Mislead]]             |

### Bonus Proficiencies

At 1st level, you gain proficiency with [[Martial Weapon|Martial Weapons]] and [[Heavy Armor]].

### Eyes of Night

Starting at 1st level, you can see through the deepest gloom. You have *darkvision* out to a range of **300 feet**. In that radius, you can see in dim light as if it were bright light and in darkness as if it were dim light.

As an [[Action]], you can magically share the darkvision of this feature with willing creatures you can see within 10 feet of you, up to a number of creatures equal to your [[Wisdom]] modifier (minimum of one creature). The shared darkvision lasts for **1 hour**. Once you share it, you can't do so again until you finish a [[Long Rest]], unless you expend a spell slot of any level to share it again.

### Vigilant Blessing

At 1st level, the night has taught you to be vigilant. As an [[Action]], you give one creature you touch (including possibly yourself) [[Advantage]] on the next [[The Wanderer's Guide to the Multiverse/Gameplay/Initiative|Initiative]] roll the creature makes. This benefit ends immediately after the roll or if you use this feature again.

### Channel Divinity: Twilight Sanctuary

At 2nd level, you can use your Channel Divinity to refresh your allies with soothing twilight.

As an [[Action]], you present your holy symbol, and a sphere of twilight emanates from you. The **sphere** is centered on you, has a **30-foot radius**, and is filled with dim light. The sphere moves with you, and it lasts for 1 minute or until you are [[Incapacitated]] or die. Whenever a creature (including you) ends its turn in the sphere, you can grant that creature one of these benefits:

- You grant it [[temporary hit points]] equal to **1d6 plus your cleric level**.

- You end one effect on it causing it to be [[Charmed]] or [[Frightened]].

### Steps of Night

Starting at 6th level, you can draw on the mystical power of night to rise into the air. As a [[Bonus Action]] when you are in dim light or darkness, you can magically give yourself a **flying speed** equal to your walking speed for 1 minute. You can use this [[Bonus Action]] a number of times equal to your [[Proficiency Bonus]], and you regain all expended uses when you finish a [[Long Rest]].

### Divine Strike

At 8th level, you gain the ability to infuse your weapon strikes with divine energy. Once on each of your turns when you hit a creature with a weapon attack, you can cause the attack to deal an extra **1d8 [[Radiant]]** damage. When you reach 14th level, the extra damage increases to **2d8**.

### Twilight Shroud

At 17th level, the twilight that you summon offers a protective embrace: you and your allies have **half cover** while in the sphere created by your [[#Channel Divinity: Twilight Sanctuary|Twilight Sanctuary]]. 