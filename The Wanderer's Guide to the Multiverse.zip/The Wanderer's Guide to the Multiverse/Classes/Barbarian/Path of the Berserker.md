**_For some [[Barbarian|barbarians]], rage is a means to an end – that end being violence. The Path of the Berserker is a path of untrammeled fury, slick with blood. As you enter the berserker's rage, you thrill in the chaos of battle, heedless of your own health or well-being._**

Source: Player's Handbook

### Frenzy

Starting when you choose this path at 3rd level, you can go into a frenzy when you [[Rage]]. If you do so, for the duration of your [[Rage]] you can make a single melee weapon attack as a [[Bonus Action]] on each of your turns after this one. When your rage ends, you suffer one level of [[Exhaustion]].

### Mindless Rage

Beginning at 6th level, you can't be [[Charmed]] or [[Frightened]] while [[Rage|raging]]. If you are [[Charmed]] or [[Frightened]] when you enter your [[Rage]], the effect is suspended for the duration of the rage.

### Intimidating Presence

Beginning at 10th level, you can use your [[Action]] to [[Frightened|frighten]] someone with your menacing presence. When you do so, choose one creature that you can see within 30 feet of you. If the creature can see or hear you, it must succeed on a [[Wisdom]] saving throw (DC equal to 8 + your proficiency bonus + your [[Charisma]] modifier) or be [[Frightened]] of you until the end of your next turn. On subsequent turns, you can use your [[Action]] to extend the duration of this effect on the frightened creature until the end of your next turn. This effect ends if the creature ends its turn out of line of sight or more than 60 feet away from you.

If the creature succeeds on its saving throw, you can't use this feature on that creature again for 24 hours.

### Retaliation

Starting at 14th level, when you take damage from a creature that is within 5 feet of you, you can use your [[Reaction]] to make a melee weapon attack against that creature.