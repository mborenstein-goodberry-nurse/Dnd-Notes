---
aliases:
  - Barbarians
  - barbarians
  - Barbarian
  - barbarian
---
# Barbarian

### Class Features

As a barbarian, you gain the following class features.

#### Hit Points

**[[Hit Dice]]:** 1d12 per barbarian level 

**[[Hit Points]] at 1st Level:** 12 + your [[Constitution]] modifier

**[[Hit Points]] at Higher Levels:** 1d12 (or 7) + your [[Constitution]] modifier per barbarian level after 1st

#### Proficiencies

**Armor:** [[Light Armor]], [[Medium Armor]], [[The Wanderer's Guide to the Multiverse/Equipment/Shield|Shields]]

**Weapons:** [[Simple Weapon]], [[Martial Weapon]]

**Tools:** None

**Saving Throws:** [[Strength]], [[Constitution]]

**Skills:** Choose two from [[Animal Handling]], [[Athletics]], [[Intimidation]], [[Nature]], [[Perception]], and [[Survival]]

#### Equipment

You start with the following equipment, in addition to the equipment granted by your background:

- (*a*) a greataxe or (*b*) any [[Martial Melee Weapon]]
- (*a*) two handaxes or (*b*) any [[Simple Weapon]]
- An [[Explorer's Pack]] and four javelins

### **Barbarian Table**

| Level | Proficiency Bonus | Features                                | Rages     | Rage Damage |
| ----- | ----------------- | --------------------------------------- | --------- | ----------- |
| 1st   | +2                | [[#Rage]], [[#Unarmored Defense]]       | 2         | +2          |
| 2nd   | +2                | [[#Reckless Attack]], [[#Danger Sense]] | 2         | +2          |
| 3rd   | +2                | [[#Primal Path]]                        | 3         | +2          |
| 4th   | +2                | Ability Score Improvement               | 3         | +2          |
| 5th   | +3                | [[#Extra Attack]], [[#Fast Movement]]   | 3         | +2          |
| 6th   | +3                | Path feature                            | 4         | +2          |
| 7th   | +3                | [[#Feral Instinct]]                     | 4         | +2          |
| 8th   | +3                | Ability Score Improvement               | 4         | +2          |
| 9th   | +4                | [[#Brutal Critical]] (1 die)            | 4         | +3          |
| 10th  | +4                | Path feature                            | 4         | +3          |
| 11th  | +4                | [[#Relentless Rage]]                    | 4         | +3          |
| 12th  | +4                | Ability Score Improvement               | 5         | +3          |
| 13th  | +5                | [[#Brutal Critical]] (2 dice)           | 5         | +3          |
| 14th  | +5                | Path feature                            | 5         | +3          |
| 15th  | +5                | [[#Persistent Rage]]                    | 5         | +3          |
| 16th  | +5                | Ability Score Improvement               | 5         | +4          |
| 17th  | +6                | [[#Brutal Critical]] (3 dice)           | 6         | +4          |
| 18th  | +6                | [[#Indomitable Might]]                  | 6         | +4          |
| 19th  | +6                | Ability Score Improvement               | 6         | +4          |
| 20th  | +6                | [[#Primal Champion]]                    | Unlimited | +4          |
|       |                   |                                         |           |             |

### Rage

In battle, you fight with primal ferocity. On your turn, you can enter a rage as a bonus action.

While raging, you gain the following benefits if you aren't wearing heavy armor:

- You have advantage on [[Strength]] checks and [[Strength]] saving throws.
- When you make a melee weapon attack using [[Strength]], you gain a bonus to the damage roll that increases as you gain levels as a barbarian, as shown in the Rage Damage column of the [[#Barbarian table]].
- You have resistance to [[Bludgeoning]], [[Piercing]], and [[Slashing]] damage.

If you are able to cast spells, you can't cast them or [[Concentration|concentrate]] on them while raging.

Your rage lasts for 1 minute. It ends early if you are knocked [[Unconscious]] or if your turn ends and you haven't attacked a hostile creature since your last turn or taken damage since then. You can also end your [[#rage]] on your turn as a [[Bonus Action]].

Once you have raged the number of times shown for your barbarian level in the Rages column of the Barbarian table, you must finish a [[Long Rest]] before you can rage again.

### Unarmored Defense

While you are not wearing any armor, your Armor Class equals 10 + your [[Dexterity]] modifier + your [[Constitution]] modifier. You can use a [[The Wanderer's Guide to the Multiverse/Equipment/Shield]] and still gain this benefit.

### Reckless Attack

Starting at 2nd level, you can throw aside all concern for defense to attack with fierce desperation. When you make your first attack on your turn, you can decide to attack recklessly. Doing so gives you [[Advantage]] on melee weapon attack rolls using [[Strength]] during this turn, but attack rolls against you have [[Advantage]] until your next turn.

### Danger Sense

At 2nd level, you gain an uncanny sense of when things nearby aren't as they should be, giving you an edge when you dodge away from danger.

You have [[Advantage]] on [[Dexterity]] saving throws against effects that you can see, such as traps and spells. To gain this benefit, you can't be [[Blinded]], [[Deafened]], or [[Incapacitated]].

### Primal Path

At 3rd level, you choose a path that shapes the nature of your rage. Your choice grants you features at 3rd level and again at 6th, 10th, and 14th levels.

| Path                               | Source                              |
| ---------------------------------- | ----------------------------------- |
| [[Path of the Ancestral Guardian]] | Xanathar's Guide to Everything      |
| [[Path of the Battlerager]]        | Sword Coast Adventurer's Guide      |
| [[Path of the Beast]]              | Tasha's Cauldron of Everything      |
| [[Path of the Berserker]]          | Player's Handbook                   |
| [[Path of the Giant]]              | Bigby Presents: Glory of the Giants |
| [[Path of the Storm Herald]]       | Xanathar's Guide to Everything      |
| [[Path of the Totem Warrior]]      | Player's Handbook                   |
| [[Path of Wild Magic]]             | Tasha's Cauldron of Everything      |
| [[Path of the Zealot]]             | Xanathar's Guide to Everything      |

### Ability Score Improvement

When you reach 4th level, and again at 8th, 12th, 16th, and 19th level, you can increase one ability score of your choice by 2, or you can increase two ability scores of your choice by 1. As normal, you can't increase an ability score above 20 using this feature.

### Extra Attack

Beginning at 5th level, you can attack twice, instead of once, whenever you take the [[Attack]] action on your turn.

### Fast Movement

Starting at 5th level, your speed increases by 10 feet while you aren't wearing [[Heavy Armor]].

### Feral Instinct

By 7th level, your instincts are so honed that you have [[Advantage]] on [[The Wanderer's Guide to the Multiverse/Gameplay/Initiative|Initiative]] rolls.

Additionally, if you are surprised at the beginning of combat and aren't [[Incapacitated]], you can act normally on your first turn, but only if you enter your rage before doing anything else on that turn.

### Brutal Critical

Beginning at 9th level, you can roll one additional weapon damage die when determining the extra damage for a [[Critical Hit]] with a melee attack.

This increases to two additional dice at 13th level and three additional dice at 17th level.

### Relentless Rage

Starting at 11th level, your rage can keep you fighting despite grievous wounds. If you drop to 0 hit points while you're raging and don't die outright, you can make a DC 10 [[Constitution]] saving throw. If you succeed, you drop to 1 hit point instead.

Each time you use this feature after the first, the DC increases by 5. When you finish a [[Short Rest|short]] or [[Long Rest]], the DC resets to 10.

### Persistent Rage

Beginning at 15th level, your rage is so fierce that it ends early only if you fall [[Unconscious]] or if you choose to end it.

### Indomitable Might

Beginning at 18th level, if your total for a [[Strength]] check is less than your [[Strength]] score, you can use that score in place of the total.

### Primal Champion

At 20th level, you embody the power of the wilds. Your [[Strength]] and [[Constitution]] scores increase by 4. Your maximum for those scores is now 24.