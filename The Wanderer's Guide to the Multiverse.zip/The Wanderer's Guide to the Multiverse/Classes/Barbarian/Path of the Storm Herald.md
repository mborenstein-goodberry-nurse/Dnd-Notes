---
aliases:
  - Storm Herald
---
**Class**: [[Barbarian]] 

**_Typical barbarians harbor a fury that dwells within. Their rage grants them superior strength, durability, and speed. Barbarians who follow the Path of the Storm Herald learn instead to transform their rage into a mantle of primal magic that swirls around them. When in a fury, a barbarian of this path taps into nature to create powerful, magical effects._**

**_Storm heralds are typically elite champions who train alongside druids, rangers, and others sworn to protect the natural realm. Other storm heralds hone their craft in elite lodges founded in regions wracked by storms, in the frozen reaches at the world’s end, or deep in the hottest deserts._**

Source: Xanathar's Guide to Everything

### Storm Aura

When you select this path at 3rd level, you emanate a stormy, magical aura while you [[Rage]]. The aura extends 10 feet from you in every direction, but not through total cover.

Your aura has an effect that activates when you enter your rage, and you can activate the effect again on each of your turns as a [[Bonus Action]]. Choose desert, sea, or tundra. Your aura's effect depends on that chosen environment, as detailed below. You can change your environment choice whenever you gain a level in this class.

If your aura's effects require a saving throw, the DC equals 8 + your proficiency bonus + your [[Constitution]] modifier.

**_Desert._** When this effect is activated, all other creatures in your aura take 2 [[Fire]] damage each. The damage increases when you reach certain levels in this class, increasing to 3 at 5th level, 4 at 10th level, 5 at 15th level, and 6 at 20th level.

**_Sea._** When this effect is activated, you can choose one other creature you can see in your aura. The target must make a [[Dexterity]] saving throw. The target takes 1d6 [[Lightning]] damage on a failed save, or half as much damage on a successful one. The damage increases when you reach certain levels in this class, increasing to 2d6 at 10th level, 3d6 at 15th level, and 4d6 at 20th level.

**_Tundra._** When this effect is activated, each creature of your choice in your aura gains 2 [[Temporary Hit Points]], as icy spirits inure it to suffering. The [[Temporary Hit Points]] increase when you reach certain levels in this class, increasing to 3 at 5th level, 4 at 10th level, 5 at 15th level, and 6 at 20th level.

### Storm Soul

At 6th level, the storm grants you benefits even when your aura isn't active. The benefits are based on the environment you chose for your [[#Storm Aura]].

**_Desert._** You gain resistance to [[Fire]] damage, and you don’t suffer the effects of extreme heat, as described in the Dungeon Master's Guide. Moreover, as an [[Action]], you can touch a flammable object that isn't being worn or carried by anyone else and set it on fire.

**_Sea._** You gain resistance to [[Lightning]] damage, and you can breathe underwater. You also gain a [[Climbing, Swimming, and Crawling|Swimming]] speed of 30 feet.

**_Tundra._** You gain resistance to [[Cold]] damage, and you don’t suffer the effects of extreme cold, as described in the Dungeon Master's Guide. Moreover, as an [[Action]], you can touch water and turn a 5-foot cube of it into ice, which melts after 1 minute. This action fails if a creature is in the cube.

### Shielding Storm

At 10th level, you learn to use your mastery of the storm to protect others. Each creature of your choice has the damage resistance you gained from the [[#Storm Soul]] feature while the creature is in your [[#Storm Aura]].

### Raging Storm

At 14th level, the power of the storm you channel grows mightier, lashing out at your foes. The effect is based on the environment you chose for your Storm Aura.

**_Desert._** Immediately after a creature in your aura hits you with an attack, you can use your [[Reaction]] to force that creature to make a [[Dexterity]] saving throw. On a failed save, the creature takes [[Fire]] damage equal to half your [[Barbarian]] level.

**_Sea._** When you hit a creature in your aura with an attack, you can use your reaction to force that creature to make a [[Strength]] saving throw. On a failed save, the creature is knocked [[Prone]], as if struck by a wave.

**_Tundra._** Whenever the effect of your [[#Storm Aura]] is activated, you can choose one creature you can see in the aura. That creature must succeed on a [[Strength]] saving throw, or its speed is reduced to 0 until the start of your next turn, as magical frost covers it.