---
aliases:
  - Ancestral Guardian
---
**Class**: [[Barbarian]] 

**_Some barbarians hail from cultures that revere their ancestors. These tribes teach that the warriors of the past linger in the world as mighty spirits, who can guide and protect the living. When a barbarian who follows this path rages, the barbarian contacts the spirit world and calls on these guardian spirits for aid._**

**_Barbarians who draw on their ancestral guardians can better fight to protect their tribes and their allies. In order to cement ties to their ancestral guardians, barbarians who follow this path cover themselves in elaborate tattoos that celebrate their ancestors’ deeds. These tattoos tell sagas of victories against terrible monsters and other fearsome rivals._**

Source: Xanathar's Guide to Everything

### Ancestral Protectors

Starting when you choose this path at 3rd level, spectral warriors appear when you enter your [[Rage]]. While you're raging, the first creature you hit with an [[Attack]] on your turn becomes the target of the warriors, which hinder its attacks. Until the start of your next turn, that target has [[Disadvantage]] on any attack roll that isn't against you, and when the target hits a creature other than you with an attack, that creature has resistance to the damage dealt by the attack. The effect on the target ends early if your rage ends.

### Spirit Shield

Beginning at 6th level, the guardian spirits that aid you can provide supernatural protection to those you defend. If you are [[Rage|Raging]] and another creature you can see within 30 feet of you takes damage, you can use your [[Reaction]] to reduce that damage by 2d6.

When you reach certain levels in this class, you can reduce the damage by more: by 3d6 at 10th level and by 4d6 at 14th level.

### Consult the Spirits

At 10th level, you gain the ability to consult with your ancestral spirits. When you do so, you cast the [[Augury]] or [[Clairvoyance]] spell, without using a spell slot or material components. Rather than creating a spherical sensor, this use of clairvoyance invisibly summons one of your ancestral spirits to the chosen location. [[Wisdom]] is your spellcasting ability for these spells.

After you cast either spell in this way, you can't use this feature again until you finish a [[Short Rest|short]] or [[Long Rest]].

### Vengeful Ancestors

At 14th level, your ancestral spirits grow powerful enough to retaliate. When you use your Spirit Shield to reduce the damage of an attack, the attacker takes an amount of force damage that your Spirit Shield prevents.