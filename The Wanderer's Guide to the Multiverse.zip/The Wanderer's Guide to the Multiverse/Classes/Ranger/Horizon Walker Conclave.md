---
aliases:
  - Horizon Walker
  - Horizon Walker Ranger
---
**Class**: [[Ranger]] 

**_Horizon walkers guard the world against threats that originate from other planes or that seek to ravage the mortal realm with otherworldly magic. They seek out planar portals and keep watch over them, venturing to the Inner Planes and the Outer Planes as needed to pursue their foes. These rangers are also friends to any forces in the multiverse – especially benevolent dragons, fey, and elementals – that work to preserve life and the order of the planes._**

Source: Xanathar's Guide to Everything

### Horizon Walker Magic

Starting at 3rd level, you learn an additional spell when you reach certain levels in this class, as shown in the Horizon Walker Spells table. The spell counts as a ranger spell for you, but it doesn’t count against the number of ranger spells you know.

| Horizon Walker Spells |                                   |
| --------------------- | --------------------------------- |
| Ranger Level          | Spells                            |
| 3rd                   | [[Protection from Evil and Good]] |
| 5th                   | [[Misty Step]]                    |
| 9th                   | [[Haste]]                         |
| 13th                  | [[Banishment]]                    |
| 17th                  | [[Teleportation Circle]]          |

### Detect Portal

At 3rd level, you gain the ability to magically sense the presence of a planar portal. As an [[Action]], you detect the distance and direction to the closest planar portal within **1 mile** of you.

Once you use this feature, you can't use it again until you finish a [[Short Rest|short]] or [[Long Rest]].

See the "Planar Travel" section in chapter 2 of the Dungeon Master's Guide for examples of planar portals.

### Planar Warrior

At 3rd level, you learn to draw on the energy of the multiverse to augment your attacks.

As a [[Bonus Action]], choose one creature you can see within **30 feet** of you. The next time you hit that creature on this turn with a weapon attack, all damage dealt by the attack becomes [[Force]] damage, and the creature takes an extra **1d8 [[Force]]** damage from the attack. When you reach 11th level in this class, the extra damage increases to **2d8**.

### Ethereal Step

At 7th level, you learn to step through the Ethereal Plane. As a [[Bonus Action]] on your turn, you can cast the [[Etherealness]] spell with this feature, without expending a spell slot, but the spell ends at the end of the current turn.

Once you use this feature, you can’t use it again until you finish a [[Short Rest|short]] or [[Long Rest]].

### Distant Strike

At 11th level, you gain the ability to pass between the planes in a blink of an eye. When you use the [[Attack]] action, you can teleport up to **10 feet** before each attack to an unoccupied space you can see.

If you attack at least two different creatures with the action, you can make one additional attack with it against a third creature.

### Spectral Defense

At 15th level, your ability to move between planes enables you to slip through the planar boundaries to lessen the harm done to you during battle. When you take damage from an attack, you can use your [[Reaction]] to give yourself resistance to all of that attack's damage on this turn.