---
aliases:
---
**Class**: [[Ranger]] 

**_Your connection to the natural world takes the form of a draconic spirit, which can manifest in physical form as a drake. As your powers grow, your drake grows as well, blossoming from a small four-legged companion to a majestic winged creature large and strong enough for you to ride. Along the way, you gain an increasing share of the awe-inspiring power of dragons._**

_**Consider the source of the draconic spirit you have bonded with. The Drakewarden Origin table offers examples.**_

Source: Fizban's Treasury of Dragons

|Drakewarden Origin|   |
|---|---|
|d6|Origin|
|1|You studied a dragon’s scale or claw, or a trinket from a dragon’s hoard, creating your bond through that token’s lingering draconic magic.|
|2|A secret order of rangers who collect and guard draconic lore taught you their ways.|
|3|A dragon gave you a geode or gemstone to care for. To your surprise, the drake hatched from that stone.|
|4|You ingested a few drops of dragon blood, forever infusing your nature magic with draconic power.|
|5|An ancient Draconic inscription on a standing stone empowered you when you read it aloud.|
|6|You had a vivid dream of a mysterious figure accompanied by seven yellow canaries, who warned you of impending doom. When you awoke, your drake was there, watching you.|

### Draconic Gift

At 3rd level, the bond you share with your drake creates a connection to dragonkind, granting you understanding and empowering your presence.

You gain the following benefits:

- **Thaumaturgy**. You learn the [[Thaumaturgy]] cantrip, which is a ranger spell for you.

- **Tongue of Dragons**. You learn to speak, read, and write [[Draconic]] or one other [[Languages|language]] of your choice.

### Drake Companion

At 3rd level, as an [[Action]], you can magically summon the drake that is bound to you. It appears in an unoccupied space of your choice **within 30 feet** of you.

The drake is friendly to you and your companions, and it obeys your commands. See its game statistics in the accompanying Drake Companion stat block, which uses your [[Proficiency Bonus]] (PB) in several places. Whenever you summon the drake, choose a damage type listed in its Draconic Essence trait. You can determine the cosmetic characteristics of the drake, such as its color, its scale texture, or any visible effect of its Draconic Essence; your choice has no effect on its game statistics.

In combat, the drake shares your [[The Wanderer's Guide to the Multiverse/Gameplay/Initiative]] count, but it takes its turn immediately after yours. It can move and use its [[Reaction]] on its own, but the only action it takes on its turn is the [[Dodge]] action, unless you take a [[Bonus Action]] on your turn to command it to take another action. That action can be one in its stat block or some other action. If you are [[Incapacitated]], the drake can take any action of its choice, not just [[Dodge]].

The drake remains until it is reduced to 0 hit points, until you use this feature to summon the drake again, or until you die. Anything the drake was wearing or carrying is left behind when the drake vanishes.

Once you summon the drake, you can’t do so again until you finish a [[Long Rest]], unless you expend a spell slot of 1st level or higher to summon it.

|Drake Companion|   |   |   |   |   |
|---|---|---|---|---|---|
|_Small dragon_|   |   |   |   |   |
|**Armor Class:** 14 + PB (natural armor)|   |   |   |   |   |
|**Hit Points:** 5 + five times your ranger level (the drake has a number of hit dice [d10s] equal to your ranger level)|   |   |   |   |   |
|**Speed:** 40 ft.|   |   |   |   |   |
|STR|DEX|CON|INT|WIS|CHA|
|16 (+3)|12 (+1)|15 (+2)|8 (−1)|14 (+2)|8 (−1)|
|**Saving Throws:** Dex +1 plus PB, Wis +2 plus PB|   |   |   |   |   |
|**Damage Immunities:** determined by the drake’s Draconic Essence trait|   |   |   |   |   |
|**Senses:** darkvision 60 ft., passive Perception 12|   |   |   |   |   |
|**Languages:** Draconic|   |   |   |   |   |
|**Challenge:** **Proficiency Bonus (PB)** equals your bonus|   |   |   |   |   |
|**Draconic Essence.** When you summon the drake, choose a damage type: acid, cold, fire, lightning, or poison. The chosen type determines the drake’s damage immunity and the damage of its Infused Strikes trait.|   |   |   |   |   |
|Actions|   |   |   |   |   |
|**Bite.** _Melee Weapon Attack:_ +3 plus PB to hit, reach 5 ft., one target. Hit: 1d6 plus PB piercing damage.|   |   |   |   |   |
|Reactions|   |   |   |   |   |
|**Infused Strikes.** When another creature within 30 feet of the drake that it can see hits a target with a weapon attack, the drake infuses the strike with its essence, causing the target to take an extra 1d6 damage of the type determined by its Draconic Essence.|   |   |   |   |   |

### Bond of Fang and Scale

At 7th level the bond you share with your drake intensifies, protecting you and stoking the drake’s fury. When you summon your drake, it grows wings on its back and gains a flying speed equal to its walking speed.

In addition, while your drake is summoned, you and the drake gain the following benefits:

**Drake Mount.** The drake grows to Medium size. Reflecting your special bond, you can use the drake as a mount if your size is Medium or smaller. While you are riding your drake, it can’t use the flying speed of this feature.

**Magic Fang.** The drake’s Bite attack deals an extra **1d6** damage of the type chosen for the drake’s Draconic Essence.

**Resistance.** You gain resistance to the damage type chosen for the drake’s Draconic Essence.

### Drake’s Breath

At 11th level, as an [[Action]], you can exhale a **30-foot cone** of damaging breath or cause your drake to exhale it. Choose [[Acid]], [[Cold]], [[Fire]], [[Lightning]], or [[The Wanderer's Guide to the Multiverse/Dictionary/Damage Types/Poison]] damage (your choice doesn’t have to match your drake’s Draconic Essence). Each creature in the cone must make a **[[Dexterity]] saving throw** against your spell save DC, taking **8d6** damage on a failed save, or half as much damage on a successful one.

This damage increases to **10d6** when you reach 15th level in this class.

Once you use this feature, you can’t do so again until you finish a [[Long Rest]], unless you expend a spell slot of 3rd level or higher to use it again.

### Perfected Bond

At 15th level, your bond to your drake reaches the pinnacle of its power. While your drake is summoned, you and the drake gain the following benefits:

**Empowered Bite.** The drake’s Bite attack deals an extra **1d6** damage of the type chosen for its Draconic Essence (for a total of **2d6** extra damage).

**Large Drake.** The drake grows to Large size. When you ride your drake, it is no longer prohibited from using the flying speed of Bond of Fang and Scale.

**Reflexive Resistance.** When either you or the drake takes damage while you’re within **30 feet** of each other, you can use your [[Reaction]] to give yourself or the drake resistance to that instance of damage. You can use this [[Reaction]] a number of times equal to your [[Proficiency Bonus]], and you regain all expended uses when you finish a [[Long Rest]]. 