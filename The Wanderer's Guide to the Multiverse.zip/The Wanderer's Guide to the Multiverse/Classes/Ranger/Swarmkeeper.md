---
aliases:
---
**Class**: [[Ranger]] 

**_Feeling a deep connection to the environment around them, some rangers reach out through their magical connection to the world and bond with a swarm of nature spirits. The swarm becomes a potent force in battle, as well as helpful company for the ranger. Some Swarmkeepers are outcasts or hermits, keeping to themselves and their attendant swarms rather than dealing with the discomfort of others. Other Swarmkeepers enjoy building vibrant communities that work for the mutual benefit of all those they consider part of their swarm._**

Source: Tasha's Cauldron of Everything

### Gathered Swarm

At 3rd level, a swarm of intangible nature spirits has bonded itself to you and can assist you in battle. While you’re alive, the swarm remains in your space, crawling on you or flying and skittering around you within your space. You determine its appearance, or you generate its appearance by rolling on the Swarm Appearance table.

| Swarm Appearance |                        |
| ---------------- | ---------------------- |
| d4               | Appearance             |
| 1                | Swarming insects       |
| 2                | Miniature twig blights |
| 3                | Fluttering birds       |
| 4                | Playful pixies         |

Once on each of your turns, you can cause the swarm to assist you in one of the following ways, immediately after you hit a creature with an attack:

- The attack's target takes **1d6 [[Piercing]]** damage from the swarm.

- The attack's target must succeed on a **[[Strength]] saving throw** against your spell save DC or be moved by the swarm up to **15 feet** horizontally in a direction of your choice.

- You are moved by the swarm **5 feet** horizontally in a direction of your choice.

### Swarmkeeper Magic

Also at 3rd level, you learn the [[Mage Hand]] cantrip if you don't already know it. When you cast it, the hand takes the form of your swarming nature spirits.

You also learn an additional spell of 1st level or higher when you reach certain levels in this class, as shown in the Swarmkeeper Spells table. Each spell counts as a ranger spell for you, but it doesn't count against the number of ranger spells you know.

| Swarmkeeper spells |                                |
| ------------------ | ------------------------------ |
| Ranger Level       | Spell                          |
| 3rd                | [[Faerie Fire]], [[Mage Hand]] |
| 5th                | [[Web]]                        |
| 9th                | [[Gaseous Form]]               |
| 13th               | [[Arcane Eye]]                 |
| 17th               | [[Insect Plague]]              |

### Writhing Tide

Beginning at 7th level, you can condense part of your swarm into a focused mass that lifts you up. As a [[Bonus Action]], you gain a flying speed of 10 feet and can hover. This effect lasts for 1 minute or until you are [[Incapacitated]].

You can use this feature a number of times equal to your [[Proficiency Bonus]], and you regain all expended uses when you finish a [[Long Rest]].

### Mighty Swarm

At 11th level, your Gathered Swarm grows mightier in the following ways:

- The damage of Gathered Swarm increases to **1d8**.

- If a creature fails its saving throw against being moved by the [[#Gathered Swarm]], you can also cause the swarm to knock the creature [[Prone]].

- When you are moved by [[#Gathered Swarm]], it gives you half cover until the start of your next turn.

### Swarming Dispersal

When you reach 15th level, you can discorporate into your swarm, avoiding danger. When you take damage, you can use your [[Reaction]] to give yourself resistance to that damage. You vanish into your swarm and then teleport to an unoccupied space that you can see within **30 feet** of you, where you reappear with the swarm.

You can use this feature a number of times equal to your [[Proficiency Bonus]], and you regain all expended uses when you finish a [[Long Rest]].