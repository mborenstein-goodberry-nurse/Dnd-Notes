---
aliases:
  - Monster Slayer
---
**Class**: [[Ranger]] 

**_You have dedicated yourself to hunting down creatures of the night and wielders of grim magic. A monster slayer seeks out vampires, dragons, evil fey, fiends, and other magical threats. Trained in supernatural techniques to overcome such monsters, slayers are experts at unearthing and defeating mighty, mystical foes._**

Source: Xanathar's Guide to Everything

### Monster Slayer Magic

Starting at 3rd level, you learn an additional spell when you reach certain levels in this class, as shown in the Monster Slayer Spells table. The spell counts as a ranger spell for you, but it doesn't count against the number of ranger spells you know.

| Monster Slayer Spells |                                   |
| --------------------- | --------------------------------- |
| Ranger Level          | Spells                            |
| 3rd                   | [[Protection from Evil and Good]] |
| 5th                   | [[Zone of Truth]]                 |
| 9th                   | [[Magic Circle]]                  |
| 13th                  | [[Banishment]]                    |
| 17th                  | [[Hold Monster]]                  |

### Hunter's Sense

At 3rd level, you gain the ability to peer at a creature and magically discern how best to hurt it. As an [[Action]], choose one creature you can see within **60 feet** of you. You immediately learn whether the creature has any damage immunities, resistances, or vulnerabilities and what they are. If the creature is hidden from divination magic, you sense that it has no damage immunities, resistances, or vulnerabilities.

You can use this feature a number of times equal to your [[Wisdom]] modifier (minimum of once). You regain all expended uses of it when you finish a [[Long Rest]].

### Slayer's Prey

Starting at 3rd level, you can focus your ire on one foe, increasing the harm you inflict on it. As a [[Bonus Action]], you designate one creature you can see within **60 feet** of you as the target of this feature. The first time each turn that you hit that target with a weapon attack, it takes an extra **1d6** damage from the weapon.

This benefit lasts until you finish a [[Short Rest|short]] or [[Long Rest]]. It ends early if you designate a different creature.

### Supernatural Defense

At 7th level, you gain extra resilience against your prey's assaults on your mind and body. Whenever the target of your [[#Slayer's Prey]] forces you to make a saving throw and whenever you make an ability check to escape that target's grapple, add **1d6** to your roll.

### Magic-User's Nemesis

At 11th level, you gain the ability to thwart someone else's magic. When you see a creature casting a spell or teleporting within **60 feet** of you, you can use your [[Reaction]] to try to magically foil it. The creature must succeed on a **[[Wisdom]] saving throw** against your spell save DC, or its spell or teleport fails and is wasted.

Once you use this feature, you can't use it again until you finish a [[Short Rest|short]] or [[Long Rest]].

### Slayer's Counter

At 15th level, you gain the ability to counterattack when your prey tries to sabotage you. If the target of your Slayer’s Prey forces you to make a saving throw, you can use your [[Reaction]] to make one weapon attack against the quarry. You make this attack immediately before making the saving throw. If the attack hits, your save automatically succeeds, in addition to the attack’s normal effects.