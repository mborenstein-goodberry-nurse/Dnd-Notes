---
aliases:
  - Bards
---
# Bard

### Class Features

As a bard, you gain the following class features.

#### Hit Points

**[[Hit Dice]]:** 1d8 per bard level

**[[Hit Points]] at 1st Level:** 8 + your [[Constitution]] modifier

**[[Hit Points]] at Higher Levels:** 1d8 (or 5) + your [[Constitution]] modifier per bard level after 1st

#### Proficiencies

**Armor:** [[Light Armor]]

**Weapons:** [[Simple Weapon|Simple Weapons]], hand crossbows, longswords, rapiers, shortswords

**Tools:** Three [[Musical Instrument]] of your choice

**Saving Throws:** [[Dexterity]], [[Charisma]]

**Skills:** Choose any three

#### Equipment

You start with the following equipment, in addition to the equipment granted by your background:

- (*a*) a rapier, (*b*) a longsword, or (*c*) any [[Simple Weapon]]
- (*a*) a [[Diplomat's Pack]] or (*b*) an [[Entertainer's Pack]]
- (*a*) a lute or (*b*) any other [[Musical Instrument|musical instrument]]
- Leather armor and a dagger

##### Bard Table

| Level | Proficiency Bonus | Features                                                            | Cantrips Known | Spells Known | 1st | 2nd | 3rd | 4th | 5th | 6th | 7th | 8th | 9th |
| ----- | ----------------- | ------------------------------------------------------------------- | -------------- | ------------ | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1st   | +2                | [[#Spellcasting]], [[#Bardic Inspiration]] (d6)                     | 2              | 4            | 2   | -   | -   | -   | -   | -   | -   | -   | -   |
| 2nd   | +2                | [[#Jack of All Trades]], [[#Song of Rest]] (d6)                     | 2              | 5            | 3   | -   | -   | -   | -   | -   | -   | -   | -   |
| 3rd   | +2                | [[#Bard College]], [[#Expertise]]                                   | 2              | 6            | 4   | 2   | -   | -   | -   | -   | -   | -   | -   |
| 4th   | +2                | Ability Score Improvement                                           | 3              | 7            | 4   | 3   | -   | -   | -   | -   | -   | -   | -   |
| 5th   | +3                | [[#Bardic Inspiration]] (d8), [[#Font of Inspiration]]              | 3              | 8            | 4   | 3   | 2   | -   | -   | -   | -   | -   | -   |
| 6th   | +3                | [[#Countercharm]], Bard College Feature                             | 3              | 9            | 4   | 3   | 3   | -   | -   | -   | -   | -   | -   |
| 7th   | +3                | -                                                                   | 3              | 10           | 4   | 3   | 3   | 1   | -   | -   | -   | -   | -   |
| 8th   | +3                | Ability Score Improvement                                           | 3              | 11           | 4   | 3   | 3   | 2   | -   | -   | -   | -   | -   |
| 9th   | +4                | [[#Song of Rest]] (d8)                                              | 3              | 12           | 4   | 3   | 3   | 3   | 1   | -   | -   | -   | -   |
| 10th  | +4                | [[#Bardic Inspiration]] (d10), [[#Expertise]], [[#Magical Secrets]] | 4              | 14           | 4   | 3   | 3   | 3   | 2   | -   | -   | -   | -   |
| 11th  | +4                | -                                                                   | 4              | 15           | 4   | 3   | 3   | 3   | 2   | 1   | -   | -   | -   |
| 12th  | +4                | Ability Score Improvement                                           | 4              | 15           | 4   | 3   | 3   | 3   | 2   | 1   | -   | -   | -   |
| 13th  | +5                | [[#Song of Rest]] (d10)                                             | 4              | 16           | 4   | 3   | 3   | 3   | 2   | 1   | 1   | -   | -   |
| 14th  | +5                | [[#Magical Secrets]], Bard College Feature                          | 4              | 18           | 4   | 3   | 3   | 3   | 2   | 1   | 1   | -   | -   |
| 15th  | +5                | [[#Bardic Inspiration]] (d12)                                       | 4              | 19           | 4   | 3   | 3   | 3   | 2   | 1   | 1   | 1   | -   |
| 16th  | +5                | Ability Score Improvement                                           | 4              | 19           | 4   | 3   | 3   | 3   | 2   | 1   | 1   | 1   | -   |
| 17th  | +6                | [[#Song of Rest]] (d12)                                             | 4              | 20           | 4   | 3   | 3   | 3   | 2   | 1   | 1   | 1   | 1   |
| 18th  | +6                | [[#Magical Secrets]]                                                | 4              | 22           | 4   | 3   | 3   | 3   | 3   | 1   | 1   | 1   | 1   |
| 19th  | +6                | Ability Score Improvement                                           | 4              | 22           | 4   | 3   | 3   | 3   | 3   | 2   | 1   | 1   | 1   |
| 20th  | +6                | [[#Superior Inspiration]]                                           | 4              | 22           | 4   | 3   | 3   | 3   | 3   | 2   | 2   | 1   | 1   |
|       |                   |                                                                     |                |              |     |     |     |     |     |     |     |     |     |

### Spellcasting

You have learned to untangle and reshape the fabric of reality in harmony with your wishes and music.

Your spells are part of your vast repertoire, magic that you can tune to different situations.

#### Cantrips

You know two cantrips of your choice from the [[Bard Spells#Cantrip|bard spell list]]. You learn additional bard cantrips of your choice at higher levels, as shown in the Cantrips Known column of the [[#Bard table]].

#### Spell Slots

The Bard table shows how many spell slots you have to cast your bard spells of 1st level and higher. To cast one of these spells, you must expend a slot of the spell's level or higher. You regain all expended spell slots when you finish a long rest.

For example, if you know the 1st-level spell *cure wounds* and have a 1st-level and a 2nd-level spell slot available, you can cast *cure wounds* using either slot.

#### Spells Known of 1st Level and Higher

You know four 1st-level spells of your choice from the [[Bard Spells|bard spell list]].

The Spells Known column of the [[#Bard table]] shows when you learn more bard spells of your choice. Each of these spells must be of a level for which you have spell slots, as shown on the table. For instance, when you reach 3rd level in this class, you can learn one new spell of 1st or 2nd level.

Additionally, when you gain a level in this class, you can choose one of the bard spells you know and replace it with another spell from the bard spell list, which also must be of a level for which you have spell slots.

#### Spellcasting Ability

Charisma is your spellcasting ability for your bard spells. Your magic comes from the heart and soul you pour into the performance of your music or oration. You use your [[Charisma]] whenever a spell refers to your spellcasting ability. In addition, you use your [[Charisma]] modifier when setting the saving throw DC for a bard spell you cast and when making an attack roll with one.

**Spell save DC** = 8 + your proficiency bonus + your [[Charisma]] modifier

**Spell attack modifier** = your proficiency bonus + your [[Charisma]] modifier

#### Ritual Casting

You can cast any bard spell you know as a [[Ritual]] if that spell has the ritual tag.

#### Spellcasting Focus

You can use a musical instrument as a spellcasting focus for your bard spells.

### Bardic Inspiration

You can inspire others through stirring words or music. To do so, you use a [[Bonus Action]] on your turn to choose one creature other than yourself within 60 feet of you who can hear you. That creature gains one Bardic Inspiration die, a d6.

Once within the next 10 minutes, the creature can roll the die and add the number rolled to one ability check, attack roll, or saving throw it makes. The creature can wait until after it rolls the d20 before deciding to use the Bardic Inspiration die, but must decide before the GM says whether the roll succeeds or fails. Once the Bardic Inspiration die is rolled, it is lost. A creature can have only one Bardic Inspiration die at a time.

You can use this feature a number of times equal to your [[Charisma]] modifier (a minimum of once). You regain any expended uses when you finish a [[Long Rest]].

Your Bardic Inspiration die changes when you reach certain levels in this class. The die becomes a d8 at 5th level, a d10 at 10th level, and a d12 at 15th level.

### Jack of All Trades

Starting at 2nd level, you can add half your [[Proficiency Bonus]], rounded down, to any ability check you make that doesn't already include your proficiency bonus.

### Song of Rest

Beginning at 2nd level, you can use soothing music or oration to help revitalize your wounded allies during a [[Short Rest]]. If you or any friendly creatures who can hear your performance regain [[Hit Points]] at the end of the [[Short Rest]] by spending one or more [[Hit Dice]], each of those creatures regains an extra 1d6 [[Hit Points]].

The extra hit points increase when you reach certain levels in this class: to 1d8 at 9th level, to 1d10 at 13th level, and to 1d12 at 17th level.

### Bard College

At 3rd level, you delve into the advanced techniques of a bard college of your choice. Your choice grants you features at 3rd level and again at 6th and 14th level.

| College                  | Source                                                        |
| ------------------------ | ------------------------------------------------------------- |
| [[College of Creation]]  | Tasha's Cauldron of Everything                                |
| [[College of Eloquence]] | Mythic Odysseys of Theros  <br>Tasha's Cauldron of Everything |
| [[College of Glamour]]   | Xanathar's Guide to Everything                                |
| [[College of Lore]]      | Player's Handbook                                             |
| [[College of Spirits]]   | Van Richten's Guide to Ravenloft                              |
| [[College of Swords]]    | Xanathar's Guide to Everything                                |
| [[College of Valor]]     | Player's Handbook                                             |
| [[College of Whispers]]  | Xanathar's Guide to Everything                                |
### Expertise

At 3rd level, choose two of your skill proficiencies. Your [[Proficiency Bonus]] is doubled for any ability check you make that uses either of the chosen proficiencies.

At 10th level, you can choose another two skill proficiencies to gain this benefit.

### Ability Score Improvement

When you reach 4th level, and again at 8th, 12th, 16th, and 19th level, you can increase one ability score of your choice by 2, or you can increase two ability scores of your choice by 1. As normal, you can't increase an ability score above 20 using this feature.

### Bardic Versatility (Optional)

Whenever you reach a level in this class that grants the Ability Score Improvement feature, you can do one of the following, representing a change in focus as you use your skills and magic:

- Replace one of the skills you chose for the [[#Expertise]] feature with one of your other skill proficiencies that isn't benefiting from Expertise.

- Replace one cantrip you learned from this class's Spellcasting feature with another cantrip from the [[Bard Spells|bard spell list]].

### Font of Inspiration

Beginning when you reach 5th level, you regain all of your expended uses of Bardic Inspiration when you finish a [[Short Rest|short]] or [[Long Rest]].

### Countercharm

At 6th level, you gain the ability to use musical notes or words of power to disrupt mind-influencing effects. As an [[Action]], you can start a performance that lasts until the end of your next turn. During that time, you and any friendly creatures within 30 feet of you have [[Advantage]] on saving throws against being [[Frightened]] or [[Charmed]]. A creature must be able to hear you to gain this benefit. The performance ends early if you are [[Incapacitated]] or silenced or if you voluntarily end it (no action required).

### Magical Secrets

By 10th level, you have plundered magical knowledge from a wide spectrum of disciplines. Choose two spells from any classes, including this one. A spell you choose must be of a level you can cast, as shown on the Bard table, or a cantrip.

The chosen spells count as bard spells for you and are included in the number in the Spells Known column of the Bard table.

You learn two additional spells from any classes at 14th level and again at 18th level.

### Superior Inspiration

At 20th level, when you roll initiative and have no uses of Bardic Inspiration left, you regain one use. 