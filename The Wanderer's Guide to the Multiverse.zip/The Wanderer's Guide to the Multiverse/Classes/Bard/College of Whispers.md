---
aliases:
  - Whisper Bard
---
**Class**: [[Bard]] 

**_Most folk are happy to welcome a bard into their midst. Bards of the College of Whispers use this to their advantage. They appear to be like any other bard, sharing news, singing songs, and telling tales to the audiences they gather. In truth, the College of Whispers teaches its students that they are wolves among sheep. These bards use their knowledge and magic to uncover secrets and turn them against others through extortion and threats._**

**_Many other bards hate the College of Whispers, viewing it as a parasite that uses the bards’ reputation to acquire wealth and power. For this reason, these bards rarely reveal their true nature unless they must. They typically claim to follow some other college, or keep their true nature secret in order to better infiltrate and exploit royal courts and other settings of power._**

Source: Xanathar's Guide to Everything

### Psychic Blades

When you join the College of Whispers at 3rd level, you gain the ability to make your weapon attacks magically toxic to a creature's mind.

When you hit a creature with a weapon attack, you can expend one use of your [[Bardic Inspiration]] to deal an additional 2d6 [[Psychic]] damage to that target. You can do so only once per round on your turn.

The psychic damage increases when you reach certain levels in this class, increasing to 3d6 at 5th level, 5d6 at 10th level, and 8d6 at 15th level.

### Words of Terror

At 3rd level, you learn to infuse innocent-seeming words with an insidious magic that can inspire terror.

If you speak to a humanoid alone for at least 1 minute, you can attempt to seed paranoia and fear into its mind. At the end of the conversation, the target must succeed on a [[Wisdom]] saving throw against your spell save DC or be [[Frightened]] of you or another creature of your choice. The target is [[Frightened]] in this way for 1 hour, until it is attacked or damaged, or until it witnesses its allies being attacked or damaged.

If the target succeeds on its saving throw, the target has no hint that you tried to frighten it.

Once you use this feature, you can't use it again until you finish a [[Short Rest]] or [[Long Rest]].

### Mantle of Whispers

At 6th level, you gain the ability to adopt a humanoid's persona. When a humanoid dies within 30 feet of you, you can magically capture its shadow using your [[Reaction]]. You retain this shadow until you use it or you finish a [[Long Rest]].

You can use the shadow as an [[Action]]. When you do so, it vanishes, magically transforming into a disguise that appears on you. You now look like the dead person, but healthy and alive. This disguise lasts for 1 hour or until you end it as a [[Bonus Action]].

While you're in the disguise, you gain access to all information that the humanoid would freely share with a casual acquaintance. Such information includes general details on its background and personal life, but doesn't include secrets. The information is enough that you can pass yourself off as the person by drawing on its memories.

Another creature can see through this disguise by succeeding on a [[Insight|Wisdom (Insight)]] check contested by your [[Deception|Charisma (Deception)]] check. You gain a +5 bonus to your check.

Once you capture a shadow with this feature, you can't capture another one with it until you finish a [[Short Rest|short]] or [[Long Rest]]. 

### Shadow Lore

At 14th level, you gain the ability to weave dark magic into your words and tap into a creature’s deepest fears.

As an [[Action]], you magically whisper a phrase that only one creature of your choice within 30 feet of you can hear. The target must make a [[Wisdom]] saving throw against your spell save DC. It automatically succeeds if it doesn’t share a language with you or if it can’t hear you. On a successful saving throw, your whisper sounds like unintelligible mumbling and has no effect.

If the target fails its saving throw, it is [[Charmed]] by you for the next 8 hours or until you or your allies attack or damage it. It interprets the whispers as a description of its most mortifying secret.

While you gain no knowledge of this secret, the target is convinced you know it. While [[Charmed]] in this way, the creature obeys your commands for fear that you will reveal its secret. It won’t risk its life for you or fight for you, unless it was already inclined to do so. It grants you favors and gifts it would offer to a close friend.

When the effect ends, the creature has no understanding of why it held you in such fear.

Once you use this feature, you can’t use it again until you finish a [[Long Rest]].
