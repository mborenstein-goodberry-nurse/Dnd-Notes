---
aliases:
  - Sword Bard
---
**Class**: [[Bard]] 

**_Bards of the College of Swords are called blades, and they entertain through daring feats of weapon prowess. Blades perform stunts such as sword swallowing, knife throwing and juggling, and mock combats. Though they use their weapons to entertain, they are also highly trained and skilled warriors in their own right._**

**_Their talent with weapons inspires many blades to lead double lives. One blade might use a circus troupe as cover for nefarious deeds such as assassination, robbery, and blackmail. Other blades strike at the wicked, bringing justice to bear against the cruel and powerful. Most troupes are happy to accept a blade’s talent for the excitement it adds to a performance, but few entertainers fully trust a blade in their ranks._**

**_Blades who abandon their lives as entertainers have often run into trouble that makes maintaining their secret activities impossible. A blade caught stealing or engaging in vigilante justice is too great a liability for most troupes. With their weapon skills and magic, these blades either take up work as enforcers for thieves’ guilds or strike out on their own as adventurers._**

Source: Xanathar's Guide to Everything

### Bonus Proficiencies

When you join the College of Swords at 3rd level, you gain proficiency with [[Medium Armor]] and the scimitar.

If you’re proficient with a simple or martial melee weapon, you can use it as a spellcasting focus for your bard spells.

### Fighting Style

At 3rd level, you adopt a particular style of fighting as your specialty. Choose one of the following options. You can't take a Fighting Style option more than once, even if you later get to choose again.

- **Dueling.** When you are wielding a melee weapon in one hand and no other weapons, you gain a +2 bonus to damage rolls with that weapon.

- **Two-Weapon Fighting.** When you engage in two-weapon fighting, you can add your ability modifier to the damage of the second attack.

### Blade Flourish

At 3rd level, you learn to conduct impressive displays of martial prowess and speed.

Whenever you take the [[Attack]] action on your turn, your walking speed increases by 10 feet until the end of the turn, and if a weapon attack that you make as part of this action hits a creature, you can use one of the following Blade Flourish options of your choice. You can use only one Blade Flourish option per turn.

**_Defensive Flourish._** You can expend one use of your [[Bardic Inspiration]] to cause the weapon to deal extra damage to the target you hit. The damage equals the number you roll on the [[Bardic Inspiration]] die. You also add the number rolled to your AC until the start of your next turn.

**_Slashing Flourish._** You can expend one use of your [[Bardic Inspiration]] to cause the weapon to deal extra damage to the target you hit and to any other creature of your choice that you can see within 5 feet of you. The damage equals the number you roll on the [[Bardic Inspiration]] die.

**_Mobile Flourish._** You can expend one use of your [[Bardic Inspiration]] to cause the weapon to deal extra damage to the target you hit. The damage equals the number you roll on the [[Bardic Inspiration]] die. You can also push the target up to 5 feet away from you, plus a number of feet equal to the number you roll on that die. You can then immediately use your [[Reaction]] to move up to your walking speed to an unoccupied space within 5 feet of the target.

### Extra Attack

Starting at 6th level, you can attack twice, instead of once, whenever you take the Attack action on your turn.

### Master's Flourish

Starting at 14th level, whenever you use a [[#Blade Flourish]] option, you can roll a d6 and use it instead of expending a Bardic Inspiration die.