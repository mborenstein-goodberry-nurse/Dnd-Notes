---
aliases:
  - Arcane Archer Fighter
---
**Class**: [[Fighter]] 

**_An Arcane Archer studies a unique elven method of archery that weaves magic into attacks to produce supernatural effects. Arcane Archers are some of their most elite warriors among the elves. They stand watch over the fringes of elven domains, keeping a keen eye out for trespassers and using magic-infused arrows to defeat monsters and invaders before they can reach elven settlements. Over the centuries, the methods of these elf archers have been learned by members of other races who can also balance arcane aptitude with archery._**

Source: Xanathar's Guide to Everything

### Arcane Archer Lore

At 3rd level, you learn magical theory or some of the secrets of nature – typical for practitioners of of this elven martial tradition. You choose to gain proficiency in either the [[Arcana]] or the [[Nature]] skill, and you choose to learn either the [[Prestidigitation]] or [[Druidcraft]] cantrip.

### Arcane Shot

At 3rd level, you learn to unleash special magical effects with some of your shots. When you gain this feature, you learn two Arcane Shot options of your choice (see "[[#Arcane Shot Options]]" below).

Once per turn when you fire an arrow from a shortbow or longbow as part of the [[Attack]] action, you can apply one of your Arcane Shot options to that arrow. You decide to use the option when the arrow hits, unless the option doesn’t involve an attack roll. You have **two** uses of this ability, and you regain all expended uses of it when you finish a [[Short Rest|short]] or [[Long Rest]].

You gain an additional Arcane Shot option of your choice when you reach certain levels in this class: 7th, 10th, 15th, and 18th level. Each option also improves when you become an 18th-level fighter.

### Magic Arrow

At 7th level, you gain the ability to infuse arrows with magic. Whenever you fire a nonmagical arrow from a shortbow or longbow, you can make it magical for the purpose of overcoming **resistance** and **immunity** to nonmagical attacks and damage. The magic fades from the arrow immediately after it hits or misses its target.

### Curving Shot

At 7th level, you learn how to direct an errant arrow toward a new target. When you make an attack roll with a magic arrow and miss, you can use a [[Bonus Action]] to reroll the attack roll against a different target within 60 feet of the original target.

### Ever-Ready Shot

Starting at 15th level, your magical archery is available whenever battle starts. If you roll [[The Wanderer's Guide to the Multiverse/Gameplay/Initiative|Initiative]] and have no uses of Arcane Shot remaining, you regain one use of it.

### Arcane Shot Options

The Arcane Shot feature lets you choose options for it at certain levels. The options are presented here in alphabetical order. They are all magical effects, and each one is associated with one of the schools of magic.

If an option requires a saving throw, your Arcane Shot save DC equals 8 + your proficiency bonus + your [[Intelligence]] modifier.

**_Banishing Arrow._** You use [[Abjuration]] magic to try to temporarily banish your target to a harmless location in the Feywild. The creature hit by the arrow must also succeed on a **[[Charisma]] saving throw** or be banished. While banished in this way, its **speed is 0**, and it is [[Incapacitated]]. At the end of its next turn, the target reappears in the space it vacated or in the nearest unoccupied space if that space is occupied.

After you reach 18th level in this class, a target also takes **2d6 [[Force]]** damage when the arrow hits it.

**_Beguiling Arrow._** Your [[Enchantment]] magic causes this arrow to temporarily beguile its target. The creature hit by the arrow takes an extra **2d6 [[Psychic]]** damage, and choose one of your allies within 30 feet of the target. The target must succeed on a **[[Wisdom]] saving throw**, or it is [[Charmed]] by the chosen ally until the start of your next turn. This effect ends early if the chosen ally attacks the [[Charmed]] target, deals damage to it, or forces it to make a saving throw.

The [[Psychic]] damage increases to **4d6** when you reach 18th level in this class.

**_Bursting Arrow._** You imbue your arrow with force energy drawn from the school of [[Evocation]]. The arrow detonates after your attack. Immediately after the arrow hits the creature, the target and all other creatures within **10 feet** of it take **2d6** force damage each.

The [[Force]] damage increases to **4d6** when you reach 18th level in this class.

**_Enfeebling Arrow._** You weave necromantic magic into your arrow. The creature hit by the arrow takes an extra **2d6 [[Necrotic]]** damage. The target must also succeed on a **[[Constitution]] saving throw**, or the damage dealt by its weapon attacks is halved until the start of your next turn.

The [[Necrotic]] damage increases to **4d6** when you reach 18th level in this class.

**_Grasping Arrow._** When this arrow strikes its target, [[Conjuration]] magic creates grasping, poisonous brambles, which wrap around the target. The creature hit by the arrow takes an extra **2d6 [[The Wanderer's Guide to the Multiverse/Dictionary/Damage Types/Poison|Poison]]** damage, its **speed is reduced by 10 feet**, and it takes **2d6 [[Slashing]]** damage the first time on each turn it moves 1 foot or more without teleporting. The target or any creature that can reach it can use its action to remove the brambles with a successful [[Athletics|Strength (Athletics)]] check against your Arcane Shot save DC. Otherwise, the brambles last for 1 minute or until you use this option again.

The poison damage and slashing damage both increase to **4d6** when you reach 18th level in this class.

**_Piercing Arrow._** You use [[Transmutation]] magic to give your arrow an ethereal quality. When you use this option, you don’t make an attack roll for the attack. Instead, the arrow fires forward in a line, which is **1 foot wide** and **30 feet long**, before disappearing. The arrow passes harmlessly through objects, ignoring cover. Each creature in that line must make a **[[Dexterity]] saving throw**. On a failed save, a creature takes damage as if it were hit by the arrow, plus an extra **1d6 [[Piercing]]** damage. On a successful save, a target takes **half** as much damage.

The [[Piercing]] damage increases to **2d6** when you reach 18th level in this class.

**_Seeking Arrow._** Using [[The Wanderer's Guide to the Multiverse/Spells/Lists/Divination|Divination]] magic, you grant your arrow the ability to seek out your target, allowing the arrow to curve and twist its path in search of its prey. When you use this option, you don’t make an attack roll for the attack. Instead, choose one creature you have seen in the past minute. The arrow flies toward that creature, moving around corners if necessary and **ignoring three-quarters cover and half cover**. If the target is within the weapon’s range and there is a path large enough for the arrow to travel to the target, the target must make a **[[Dexterity]] saving throw**. On a failed save, it takes damage as if it were hit by the arrow, plus an extra **1d6 [[Force]]** damage, and you learn the target’s current location. On a successful save, the target takes **half** as much damage, and you don’t learn its location.

The [[Force]] damage increases to **2d6** when you reach 18th level in this class.

**_Shadow Arrow._** You weave [[Illusion]] magic into your arrow, causing it to occlude your foe’s vision with shadows. The creature hit by the arrow takes an extra **2d6 [[Psychic]]** damage, and it must succeed on a **[[Wisdom]] saving throw** or be unable to see anything farther than 5 feet away until the start of your next turn.

The [[Psychic]] damage increases to **4d6** when you reach 18th level in this class. 