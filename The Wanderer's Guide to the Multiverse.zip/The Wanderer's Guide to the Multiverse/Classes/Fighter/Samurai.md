---
aliases:
  - Samurai Fighter
---
**Class**: [[Fighter]] 

**_The Samurai is a fighter who draws on an implacable fighting spirit to overcome enemies. A samurai’s resolve is nearly unbreakable, and the enemies in a samurai’s path have two choices: yield or die fighting._**

Source: Xanathar's Guide to Everything

### Bonus Proficiency

When you choose this archetype at 3rd level, you gain proficiency in one of the following skills of your choice: [[History]], [[Insight]], [[Performance]], or [[Persuasion]]. Alternatively, you learn one [[Languages|language]] of your choice.

### Fighting Spirit

Starting at 3rd level, your intensity in battle can shield you and help you strike true. As a [[Bonus Action]] on your turn, you can give yourself [[Advantage]] on all weapon attack rolls until the end of the current turn. When you do so, you also gain 5 [[Temporary Hit Points]]. The number of [[Hit Points]] increases when you reach certain levels in this class, increasing to **10** at 10th level and 15 at 15th level.

You can use this feature three times. You regain all expended uses of it when you finish a [[Long Rest]].

### Elegant Courtier

Starting at 7th level, your discipline and attention to detail allow you to excel in social situations. Whenever you make a [[Persuasion|Charisma (Persuasion)]] check, you gain a bonus to the check equal to your [[Wisdom]] modifier.

Your self-control also causes you to gain proficiency in [[Wisdom]] saving throws. If you already have this proficiency, you instead gain proficiency in [[Intelligence]] or [[Charisma]] saving throws (your choice).

### Tireless Spirit

Starting at 10th level, when you roll initiative and have no uses of [[#Fighting Spirit]] remaining, you regain one use.

### Rapid Strike

Starting at 15th level, you learn to trade accuracy for swift strikes. If you take the [[Attack]] action on your turn and have [[Advantage]] on an attack roll against one of the targets, you can forgo the [[Advantage]] for that roll to make an additional weapon attack against that target, as part of the same action. You can do so no more than once per turn.

### Strength Before Death

Starting at 18th level, your fighting spirit can delay the grasp of death. If you take damage that reduces you to 0 hit points, you can use your [[Reaction]] to delay falling [[Unconscious]], and you can immediately take an extra turn. While you have 0 hit points during that extra turn, taking damage causes [[Death Saving Throw]] failures as normal, and three [[Death Saving Throw]] failures can still kill you. When the extra turn ends, you fall [[Unconscious]] if you still have 0 hit points.

Once you use this feature, you can’t use it again until you finish a [[Long Rest]].