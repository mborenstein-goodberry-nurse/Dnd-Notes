---
aliases:
  - Cavalier Fighter
---
**Class**: [[Fighter]] 

**_The archetypal cavalier excels at mounted combat. Usually born among the nobility and raised at court, a cavalier is equally at home leading a cavalry charge or exchanging repartee at a state dinner. Cavaliers also learn how to guard those in their charge from harm, often serving as the protectors of their superiors and of the weak. Compelled to right wrongs or earn prestige, many of these fighters leave their lives of comfort to embark on glorious adventure._**

Source: Xanathar's Guide to Everything

### Bonus Proficiency

When you choose this archetype at 3rd level, you gain proficiency in one of the following skills of your choice: [[Animal Handling]], [[History]], [[Insight]], [[Performance]], or [[Persuasion]]. Alternatively, you learn [[Languages|one language of your choice]].

### Born to the Saddle

Starting at 3rd level, your mastery as a rider becomes apparent. You have [[Advantage]] on saving throws made to avoid falling off your mount. If you fall off your mount and descend no more than **10 feet**, you can land on your feet if you’re not [[Incapacitated]].

Finally, mounting or dismounting a creature costs you only **5 feet** of movement, rather than half your speed.

### Unwavering Mark

Starting at 3rd level, you can menace your foes, foiling their attacks and punishing them for harming others. When you hit a creature with a melee weapon attack, you can mark the creature until the end of your next turn. This effect ends early if you are [[Incapacitated]] or you die, or if someone else marks the creature.

While it is within 5 feet of you, a creature marked by you has [[Disadvantage]] on any attack roll that doesn't target you.

In addition, if a creature marked by you deals damage to anyone other than you, you can make a special melee weapon attack against the marked creature as a [[Bonus Action]] on your next turn. You have [[Advantage]] on the attack roll, and if it hits, the attack's weapon deals extra damage to the target equal to half your fighter level.

Regardless of the number of creatures you mark, you can make this special attack a number of times equal to your [[Strength]] modifier (a minimum of once), and you regain all expended uses of it when you finish a [[Long Rest]].

### Warding Maneuver

At 7th level, you learn to fend off strikes directed at you, your mount, or other creatures nearby. If you or a creature you can see within 5 feet of you is hit by an attack, you can roll **1d8** as a [[Reaction]] if you're wielding a melee weapon or a shield. Roll the die, and add the number rolled to the target's AC against that attack. If the attack still hits, the target has resistance against the attack's damage.

You can use this feature a number of times equal to your [[Constitution]] modifier (a minimum of once), and you regain all expended uses of it when you finish a [[Long Rest]].

### Hold the Line

At 10th level, you become a master of locking down your enemies. Creatures provoke an opportunity attack from you when they move 5 feet or more while within your reach, and if you hit a creature with an [[Opportunity Attack]], the target's speed is reduced to **0** until the end of the current turn.

### Ferocious Charger

Starting at 15th level, you can run down your foes, whether you're mounted or not. If you move at least 10 feet in a straight line right before attacking a creature and you hit it with the attack, that target must succeed on a [[Strength]] saving throw (DC 8 + your [[Proficiency Bonus]] + your [[Strength]] modifier) or be knocked [[Prone]]. You can use this feature only once on each of your turns.

### Vigilant Defender

Starting at 18th level, you respond to danger with extraordinary vigilance. In combat, you get a special [[Reaction]] that you can take once on every creature's turn, except your turn. You can use this special [[Reaction]] only to make an [[Opportunity Attack]], and you can't use it on the same turn that you take your normal [[Reaction]]. 