---
aliases:
  - Fighters
---
# Fighter

### Class Features

As a fighter, you gain the following class features.

#### Hit Points

**[[Hit Dice]]:** 1d10 per fighter level

**[[Hit Points]] at 1st Level:** 10 + your [[Constitution]] modifier

**[[Hit Points]] at Higher Levels:** 1d10 (or 6) + your [[Constitution]] modifier per fighter level after 1st

#### Proficiencies

**Armor:** All [[Armor]], [[The Wanderer's Guide to the Multiverse/Equipment/Shield|Shields]]

**Weapons:** [[Simple Weapon|Simple Weapons]], [[Martial Weapon|Martial Weapons]]

**Tools:** None

**Saving Throws:** [[Strength]], [[Constitution]]

**Skills:** Choose two skills from [[Acrobatics]], [[Animal Handling]], [[Athletics]], [[History]], [[Insight]], [[Intimidation]], [[Perception]], and [[Survival]]

#### Equipment

You start with the following equipment, in addition to the equipment granted by your background:

- (*a*) chain mail or (*b*) leather armor, longbow, and 20 arrows
- (*a*) a [[Martial Weapon|martial weapon]] and a [[The Wanderer's Guide to the Multiverse/Equipment/Shield|Shield]] or (*b*) two [[Martial Weapon|Martial Weapons]]
- (*a*) a light crossbow and 20 bolts or (*b*) two handaxes
- (*a*) a [[Dungeoneer's Pack]] or (*b*) an [[Explorer's Pack]]

### Fighter Table 

| Level | Proficiency Bonus | Features                                                    |
| ----- | ----------------- | ----------------------------------------------------------- |
| 1st   | +2                | [[#Fighting Style]], [[#Second Wind]]                       |
| 2nd   | +2                | [[#Action Surge]] (one use)                                 |
| 3rd   | +2                | [[#Martial Archetype]]                                      |
| 4th   | +2                | Ability Score Improvement                                   |
| 5th   | +3                | [[#Extra Attack]]                                           |
| 6th   | +3                | Ability Score Improvement                                   |
| 7th   | +3                | Martial Archetype Feature                                   |
| 8th   | +3                | Ability Score Improvement                                   |
| 9th   | +4                | [[#Indomitable]] (one use)                                  |
| 10th  | +4                | Martial Archetype Feature                                   |
| 11th  | +4                | [[#Extra Attack]] (2)                                       |
| 12th  | +4                | Ability Score Improvement                                   |
| 13th  | +5                | [[#Indomitable]] (two uses)                                 |
| 14th  | +5                | Ability Score Improvement                                   |
| 15th  | +5                | Martial Archetype Feature                                   |
| 16th  | +5                | Ability Score Improvement                                   |
| 17th  | +6                | [[#Action Surge]] (two uses), [[#Indomitable]] (three uses) |
| 18th  | +6                | Martial Archetype Feature                                   |
| 19th  | +6                | Ability Score Improvement                                   |
| 20th  | +6                | [[#Extra Attack]] (3)                                       |
|       |                   |                                                             |

### Fighting Style

You adopt a particular style of fighting as your specialty. Choose one of the following options. You can't take a Fighting Style option more than once, even if you later get to choose again.

- **Archery (PHB).** You gain a +2 bonus to attack rolls you make with ranged weapons.

- **Blind Fighting (TCE).** You have [[blindsight]] with a range of 10 feet. Within that range, you can effectively see anything that isn't behind total cover, even if you're [[Blinded]] or in darkness. Moreover, you can see an [[Invisible]] creature within that range, unless the creature successfully hides from you.

- **Defense (PHB).** While you are wearing armor, you gain a **+1 bonus** to AC.

- **Dueling (PHB).** When you are wielding a melee weapon in one hand and no other weapons, you gain a **+2 bonus** to damage rolls with that weapon.

- **Great Weapon Fighting (PHB).** When you roll a 1 or 2 on a damage die for an attack you make with a melee weapon that you are wielding with two hands, you can reroll the die and must use the new roll, even if the new roll is a 1 or a 2. The weapon must have the two-handed or versatile property for you to gain this benefit.

- **Interception (TCE).** When a creature you can see hits a target, other than you, within 5 feet of you with an attack, you can use your [[Reaction]] to reduce the damage the target takes by **1d10 + your [[Proficiency Bonus]]** (to a minimum of 0 damage). You must be wielding a shield or a [[Simple Weapon|simple]] or [[Martial Weapon|martial weapon]] to use this [[Reaction]].

- **Protection (PHB).** When a creature you can see attacks a target other than you that is within 5 feet of you, you can use your [[Reaction]] to impose [[Disadvantage]] on the attack roll. You must be wielding a shield.

- **Superior Technique (TCE).** You learn one [[Battle Master Manuevers|maneuver]] of your choice from among those available to the [[Battle Master]] archetype. If a maneuver you use requires your target to make a saving throw to resist the maneuver's effects, the saving throw DC equals 8 + your [[Proficiency Bonus]] + your [[Strength]] or [[Dexterity]] modifier (your choice.)
    - You gain one superiority die, which is a **d6** (this die is added to any superiority dice you have from another source). This die is used to fuel your maneuvers. A superiority die is expended when you use it. You regain your expended superiority dice when you finish a short or long rest.

- **Thrown Weapon Fighting (TCE).** You can draw a weapon that has the [[Thrown]] property as part of the attack you make with the weapon.
    - In addition, when you hit with a ranged attack using a [[Thrown]] weapon, you gain a **+2 bonus** to the damage roll.

- **Two-Weapon Fighting (PHB).** When you engage in two-weapon fighting, you can add your ability modifier to the damage of the second attack.

- **Unarmed Fighting (TCE).** Your unarmed strikes can deal [[Bludgeoning]] damage equal to **1d6 + your [[Strength]] modifier** on a hit. If you aren't wielding any weapons or a shield when you make the attack roll, the d6 becomes a d8.
    - At the start of each of your turns, you can deal **1d4 [[Bludgeoning]]** damage to one creature [[Grappled]] by you.**

### Second Wind

You have a limited well of stamina that you can draw on to protect yourself from harm. On your turn, you can use a [[Bonus Action]] to regain hit points equal to **1d10 + your fighter level**.

Once you use this feature, you must finish a [[Short Rest|short]] or [long rest] before you can use it again.

### Action Surge

Starting at 2nd level, you can push yourself beyond your normal limits for a moment. On your turn, you can take one additional [[Action]].

Once you use this feature, you must finish a [[Short Rest|short]] or [[Long Rest]] before you can use it again. Starting at 17th level, you can use it **twice** before a rest, but only once on the same turn.

### Martial Archetype

At 3rd level, you choose an archetype that you strive to emulate in your combat styles and techniques. The archetype you choose grants you features at 3rd level and again at 7th, 10th, 15th, and 18th level.

| Archetype           | Source                         |
| ------------------- | ------------------------------ |
| [[Arcane Archer]]   | Xanathar's Guide to Everything |
| [[Banneret]]        | Sword Coast Adventurer's Guide |
| [[Battle Master]]   | Player's Handbook              |
| [[Cavalier]]        | Xanathar's Guide to Everything |
| [[Champion]]        | Player's Handbook              |
| [[Echo Knight]]     | Explorer's Guide to Wildemount |
| [[Eldritch Knight]] | Player's Handbook              |
| [[Psi Warrior]]     | Tasha's Cauldron of Everything |
| [[Rune Knight]]     | Tasha's Cauldron of Everything |
| [[Samurai]]         | Xanathar's Guide to Everything |

### Ability Score Improvement

When you reach 4th level, and again at 6th, 8th, 12th, 14th, 16th, and 19th level, you can increase one ability score of your choice by 2, or you can increase two ability scores of your choice by 1. As normal, you can't increase an ability score above 20 using this feature.

### Martial Versatility (Optional)

Whenever you reach a level in this class that grants the Ability Score Improvement feature, you can do one of the following, as you shift the focus of your martial practice:

- Replace a [[#fighting style]] you know with another fighting style available to fighters.

- If you know any [[Battle Master Manuevers|maneuvers]] from the [[Battle Master]] archetype, you can replace one maneuver you know with a different maneuver.

### Extra Attack

Beginning at 5th level, you can attack twice, instead of once, whenever you take the [[Attack]] action on your turn.

The number of attacks increases to three when you reach 11th level in this class and to four when you reach 20th level in this class.

### Indomitable

Beginning at 9th level, you can reroll a saving throw that you fail. If you do so, you must use the new roll, and you can't use this feature again until you finish a [[Long Rest]].

You can use this feature twice between [[Long Rest|long rests]] starting at 13th level and three times between long rests starting at 17th level. 