---
aliases:
  - Echo Fighter
---
**Class**: [[Fighter]] 

**_A mysterious and feared frontline warrior of the Kryn Dynasty, the Echo Knight has mastered the art of using dunamis to summon the fading shades of unrealized timelines to aid them in battle. Surrounded by echoes of their own might, they charge into the fray as a cycling swarm of shadows and strikes._**

Source: Explorer's Guide to Wildemount

### Manifest Echo

At 3rd level, you can use a [[Bonus Action]] to magically manifest an echo of yourself in an unoccupied space you can see within 15 feet of you. This echo is a magical, translucent, gray image of you that lasts until it is destroyed, until you dismiss it as a [[Bonus Action]], until you manifest another echo, or until you're [[Incapacitated]].

Your echo has AC 14 + your [[Proficiency Bonus]], **1 [[hit points|hit point]]**, and immunity to all [[Conditions]]. If it has to make a saving throw, it uses your saving throw bonus for the roll. It is the same size as you, and it occupies its space. On your turn, you can mentally command the echo to move up to **30 feet** in any direction (no action required). If your echo is ever more than 30 feet from you at the end of your turn, it is destroyed.

- As a [[Bonus Action]], you can teleport, magically swapping places with your echo at a cost of 15 feet of your movement, regardless of the distance between the two of you.

- When you take the [[Action#Attack|Attack action]] on your turn, any attack you make with that action can originate from your space or the echo's space. You make this choice for each attack.

- When a creature that you can see within 5 feet of your echo moves at least 5 feet away from it, you can use your [[Reaction]] to make an opportunity attack against that creature as if you were in the echo's space.

### Unleash Incarnation

At 3rd level, you can heighten your echo's fury. Whenever you take the [[Action#Attack|Attack action]], you can make one additional melee attack from the echo's position.

You can use this feature a number of times equal to your [[Constitution]] modifier (a minimum of once). You regain all expended uses when you finish a [[Long Rest]].

### Echo Avatar

Starting at 7th level, you can temporarily transfer your consciousness to your echo. As an [[Action]], you can see through your echo's eyes and hear through its ears. During this time, you are [[Deafened]] and [[Blinded]]. You can sustain this effect for up to 10 minutes, and you can end it at any time (requires no action). While your echo is being used in this way, it can be up to 1,000 feet away from you without being destroyed.

### Shadow Martyr

Starting at 10th level, you can make your echo throw itself in front of an attack directed at another creature that you can see. Before the attack roll is made, you can use your [[Reaction]] to teleport the echo to an unoccupied space within 5 feet of the targeted creature. The attack roll that triggered the reaction is instead made against your echo.

Once you use this feature, you can't use it again until you finish a [[Short Rest|short]] or [[Long Rest]].

### Reclaim Potential

By 15th level, you've learned to absorb the fleeting magic of your echo. When an echo of yours is destroyed by taking damage, you can gain a number of [[Temporary Hit Points]] equal to 2d6 + your [[Constitution]] modifier, provided you don't already have [[Temporary Hit Points]].

You can use this feature a number of times equal to your [[Constitution]] modifier (a minimum of once). You regain all expended uses when you finish a [[Long Rest]].

### Legion of One

At 18th level, you can use a [[Bonus Action]] to create two echos with your Manifest Echo feature, and these echoes can co-exist. If you try to create a third echo, the previous two echoes are destroyed. Anything you can do from one echo's position can be done from the other's instead.

In addition, when you roll [[The Wanderer's Guide to the Multiverse/Gameplay/Initiative]] and have no uses of your [[#Unleash Incarnation]] feature left, you regain one use of that feature.