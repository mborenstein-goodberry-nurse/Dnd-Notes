---
aliases:
  - Land Druid
---
**Class**: [[Druid]] 

**_The Circle of the Land is made up of mystics and sages who safeguard ancient knowledge and rites through a vast oral tradition. These druids meet within sacred circles of trees or standing stones to whisper primal secrets in Druidic. The circle's wisest members preside as the chief priests of communities that hold to the Old Faith and serve as advisors to the rulers of those folk. As a member of this circle, your magic is influenced by the land where you were initiated into the circle's mysterious rites._**

Source: Player's Handbook

### Bonus Cantrip

When you choose this circle at 2nd level, you learn one additional [[Druid Spells#Cantrip|druid cantrip]] of your choice. This cantrip doesn’t count against the number of druid cantrips you know.

### Natural Recovery

Starting at 2nd level, you can regain some of your magical energy by sitting in meditation and communing with nature. During a [[Short Rest]], you choose expended spell slots to recover. The spell slots can have a combined level that is equal to or less than **half your druid level (rounded up)**, and none of the slots can be 6th level or higher. You can't use this feature again until you finish a [[Long Rest]].

For example, when you are a 4th-level druid, you can recover up to two levels worth of spell slots. You can recover either a 2nd-level slot or two 1st-level slots.

### Circle Spells

Your mystical connection to the land infuses you with the ability to cast certain spells. At 3rd, 5th, 7th, and 9th level you gain access to circle spells connected to the land where you became a druid. Choose that land – arctic, coast, desert, forest, grassland, mountain, swamp, or Underdark – and consult the associated list of spells.

Once you gain access to a circle spell, you always have it prepared, and it doesn't count against the number of spells you can prepare each day. If you gain access to a spell that doesn't appear on the druid spell list, the spell is nonetheless a druid spell for you.

| Arctic      |                                           |
| ----------- | ----------------------------------------- |
| Druid Level | Circle Spells                             |
| 3rd         | [[Hold Person]], [[Spike Growth]]         |
| 5th         | [[Sleet Storm]], [[Slow]]                 |
| 7th         | [[Freedom of Movement]], [[Ice Storm]]    |
| 9th         | [[Commune with Nature]], [[Cone of Cold]] |

| Coast       |                                            |
| ----------- | ------------------------------------------ |
| Druid Level | Circle Spells                              |
| 3rd         | [[Mirror Image]], [[Misty Step]]           |
| 5th         | [[Water Breathing]], [[Water Walk]]        |
| 7th         | [[Control Water]], [[Freedom of Movement]] |
| 9th         | [[Conjure Elemental]], [[Scrying]]         |

| Desert      |                                                       |
| ----------- | ----------------------------------------------------- |
| Druid Level | Circle Spells                                         |
| 3rd         | [[Blur]], [[Silence]]                                 |
| 5th         | [[Create Food and Water]], [[Protection from Energy]] |
| 7th         | [[Blight]], [[Hallucinatory Terrain]]                 |
| 9th         | [[Insect Plague]], [[Wall of Stone]]                  |

| Forest      |                                          |
| ----------- | ---------------------------------------- |
| Druid Level | Circle Spells                            |
| 3rd         | [[Barkskin]], [[Spider Climb]]           |
| 5th         | [[Call Lightning]], [[Plant Growth]]     |
| 7th         | [[The Wanderer's Guide to the Multiverse/Spells/Divination]], [[Freedom of Movement]]  |
| 9th         | [[Commune with Nature]], [[Tree Stride]] |

| Grassland   |                                          |
| ----------- | ---------------------------------------- |
| Druid Level | Circle Spells                            |
| 3rd         | [[Invisibility]], [[Pass Without Trace]] |
| 5th         | [[Daylight]], [[Haste]]                  |
| 7th         | [[The Wanderer's Guide to the Multiverse/Spells/Divination]], [[Freedom of Movement]]  |
| 9th         | [[Dream]], [[Insect Plague]]             |

| Mountain    |                                         |
| ----------- | --------------------------------------- |
| Druid Level | Circle Spells                           |
| 3rd         | [[Spider Climb]], [[Spike Growth]]      |
| 5th         | [[Lightning Bolt]], [[Meld into Stone]] |
| 7th         | [[Stone Shape]], [[Stoneskin]]          |
| 9th         | [[Passwall]], [[Wall of Stone]]         |

| Swamp       |                                              |
| ----------- | -------------------------------------------- |
| Druid Level | Circle Spells                                |
| 3rd         | [[Darkness]], [[Melf's Acid Arrow]]          |
| 5th         | [[Water Walk]], [[Stinking Cloud]]           |
| 7th         | [[Freedom of Movement]], [[Locate Creature]] |
| 9th         | [[Insect Plague]], [[Scrying]]               |

| Underdark   |                                           |
| ----------- | ----------------------------------------- |
| Druid Level | Circle Spells                             |
| 3rd         | [[Spider Climb]], [[Web]]                 |
| 5th         | [[Gaseous Form]], [[Stinking Cloud]]      |
| 7th         | [[Greater Invisibility]], [[Stone Shape]] |
| 9th         | [[Cloudkill]], [[Insect Plague]]          |

### Land's Stride

Starting at 6th level, moving through nonmagical [[Difficult Terrain]] costs you no extra movement. You can also pass through nonmagical plants without being slowed by them and without taking damage from them if they have thorns, spines, or a similar hazard.

In addition, you have [[Advantage]] on saving throws against plants that are magically created or manipulated to impede movement, such as those created by the [[Entangle]] spell.

### Nature's Ward

When you reach 10th level, you can't be [[Charmed]] or [[Frightened]] by elementals or fey, and you are **immune** to **poison** and **disease**.

### Nature's Sanctuary

When you reach 14th level, creatures of the natural world sense your connection to nature and become hesitant to attack you. When a beast or plant creature attacks you, that creature must make a **[[Wisdom]] saving throw** against your druid spell save DC. On a failed save, the creature must choose a different target, or the attack automatically misses. On a successful save, the creature is immune to this effect for 24 hours.

The creature is aware of this effect before it makes its attack against you. 