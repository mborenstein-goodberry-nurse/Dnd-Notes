---
aliases:
  - Moon Druid
---
**Class**: [[Druid]] 

**_Druids of the Circle of the Moon are fierce guardians of the wilds. Their order gathers under the full moon to share news and trade warnings. They haunt the deepest parts of the wilderness, where they might go for weeks on end before crossing paths with another humanoid creature, let alone another druid._**

**_Changeable as the moon, a druid of this circle might prowl as a great cat one night, soar over the treetops as an eagle the next day, and crash through the undergrowth in bear form to drive off a trespassing monster. The wild is in the druid's blood._**

Source: Player's Handbook

### Combat Wild Shape

When you choose this circle at 2nd level, you gain the ability to use [[Wild Shape]] on your turn as a [[Bonus Action]], rather than as an [[Action]].

Additionally, while you are transformed by [[Wild Shape]], you can use a [[Bonus Action]] to expend one spell slot to regain **1d8 [[Hit Points]]** per level of the spell slot expended.

### Circle Forms

The rites of your circle grant you the ability to transform into more dangerous animal forms. Starting at 2nd level, you can use your [[Wild Shape]] to transform into a beast with a challenge rating as high as **1**. You ignore the **Max. CR** column of the [[Wild Shape#^6e5fae|Beast Shapes table]], but must abide by the other limitations there.

Starting at 6th level, you can transform into a beast with a challenge rating as high as your **druid level divided by 3, rounded down**.

### Primal Strike

Starting at 6th level, your attacks in beast form count as **magical** for the purpose of overcoming **resistance** and **immunity** to nonmagical attacks and damage.

### Elemental Wild Shape

At 10th level, you can expend **two** uses of Wild Shape at the same time to transform into an [[air elemental]], an [[earth elemental]], a [[fire elemental]], or a [[water elemental]].

### Thousand Forms

By 14th level, you have learned to use magic to alter your physical form in more subtle ways. You can cast the [[Alter Self]] spell at will.