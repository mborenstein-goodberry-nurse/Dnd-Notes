---
aliases:
  - Spores Druid
---
**Class**: [[Druid]] 

**_Druids of the Circle of Spores find beauty in decay. They see within mold and other fungi the ability to transform lifeless material into abundant, albeit somewhat strange, life. These druids believe that life and death are parts of a grand cycle, with one leading to the other and then back again. Death isn't the end of life, but instead a change of state that sees life shift into a new form._**

**_Druids of this circle have a complex relationship with the undead. They see nothing inherently wrong with undeath, which they consider to be a companion to life and death. But these druids believe that the natural cycle is healthiest when each segment of it is vibrant and changing. Undead that seek to replace all life with undeath, or that try to avoid passing to a final rest, violate the cycle and must be thwarted._**

Source: Guildmaster's Guide to Ravnica, Tasha's Cauldron of Everything

### Circle Spells

Your symbiotic link to fungi and your ability to tap into the cycle of life and death grants you access to certain spells. At 2nd level, you learn the [[Chill Touch]] cantrip.

At 3rd, 5th, 7th, and 9th level you gain access to the spells listed for that level in the [[#Circle of Spore Spells Table]]. Once you gain access to one of these spells, you always have it prepared, and it doesn't count against the number of spells you can prepare each day. If you gain access to a spell that doesn't appear on the druid spell list, the spell is nonetheless a druid spell for you.

#### Circle of Spore Spells Table

| Circle of Spores Spells |                                                               |
| ----------------------- | ------------------------------------------------------------- |
| Druid Level             | Circle Spells                                                 |
| 2nd                     | [[Chill Touch]]                                               |
| 3rd                     | [[Blindness-Deafness\|Blindness/Deafness]], [[Gentle Repose]] |
| 5th                     | [[Animate Dead]], [[Gaseous Form]]                            |
| 7th                     | [[Blight]], [[Confusion]]                                     |
| 9th                     | [[Cloudkill]], [[Contagion]]                                  |

### Halo of Spores

Starting at 2nd level, you are surrounded by invisible, necrotic spores that are harmless until you unleash them on a creature nearby. When a creature you can see **moves** into a space within **10 feet of you** or **starts its turn** there, you can use your [[Reaction]] to deal **1d4 [[Necrotic]]** damage to that creature unless it succeeds on a **[[Constitution]] saving throw** against your spell save DC. The [[Necrotic]] damage increases to **1d6** at 6th level, **1d8** at 10th level, and **1d10** at 14th level.

### Symbiotic Entity

Also at 2nd level, you gain the ability to channel magic into your spores. As an [[Action]], you can expend a use of your [[Wild Shape]] feature to awaken those spores, rather than transforming into a beast form, and you gain **4 [[Temporary Hit Points]]** for each level you have in this class. While this feature is active, you gain the following benefits:

- When you deal your Halo of Spores damage, roll the damage die a second time and add it to the total.

- Your melee weapon attacks deal an extra **1d6 [[Necrotic]]** damage to any target they hit.

These benefits last for 10 minutes, until you lose all these [[Temporary Hit Points]]. or until you use your [[Wild Shape]] again.

### Fungal Infestation

At 6th level, your spores gain the ability to infest a corpse and animate it. If a beast or a humanoid that is Small or Medium dies **within 10 feet of you**, you can use your reaction to animate it, causing it to stand up immediately with **1 hit point**. The creature uses the [[Zombie]] stat block in the Monster Manual. It remains animate for **1 hour**, after which time it collapses and dies.

In combat, the zombie's **turn** comes **immediately after yours**. It obeys your *mental* commands, and the only action it can take is the **Attack action**, making one melee attack.

You can use this feature a number of times equal to your [[Wisdom]] modifier (minimum of once), and you regain all expended uses of it when you finish a [[Long Rest]].

### Spreading Spores

At 10th level, you gain the ability to seed an area with deadly spores. As a [[Bonus Action]] while your [[#Symbiotic Entity]] feature is active, you can hurl spores up to **30 feet** away, where they swirl in a **10-foot cube** for **1 minute**. The spores disappear early if you use this feature again, if you dismiss them as a [[Bonus Action]], or if your [[#Symbiotic Entity]] feature is no longer active.

Whenever a creature moves into the cube or starts its turn there, that creature takes your [[#Halo of Spores]] damage, unless the creature succeeds on a **[[Constitution]] saving throw** against your spell save DC. A creature can take this damage no more than once per turn.

While the cube of spores persists, you can't use your [[#Halo of Spores]] reaction.

### Fungal Body

At 14th level, the fungal spores in your body alter you: you can't be [[Blinded]], [[Deafened]], [[Frightened]], or [[Poisoned]], and any [[Critical Hit]] against you counts as a normal hit instead, unless you're [[Incapacitated]]. 