```statblock
monster: Kobold
```
