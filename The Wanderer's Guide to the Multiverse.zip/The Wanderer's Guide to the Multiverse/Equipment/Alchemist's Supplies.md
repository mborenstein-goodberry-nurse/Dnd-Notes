---
type: Equipment
---
Alchemist's supplies enable a character to produce useful concoctions, such as acid or alchemist's fire.

**_Components._** Alchemist's supplies include two glass beakers, a metal frame to hold a beaker in place over an open flame, a glass stirring rod, a small mortar and pestle, and a pouch of common alchemical ingredients, including salt, powdered iron, and purified water.

**_[[Arcana]]._** Proficiency with alchemist's supplies allows you to unlock more information on Arcana checks involving potions and similar materials.

**_[[Investigation]]._** When you inspect an area for clues, proficiency with alchemist's supplies grants additional insight into any chemicals or other substances that might have been used in the area.

**_Alchemical Crafting._** You can use this tool proficiency to create alchemical items. A character can spend money to collect raw materials, which weigh 1 pound for every 50 gp spent. The DM can allow a character to make a check using the indicated skill with advantage. As part of a long rest, you can use alchemist's supplies to make one dose of acid, alchemist's fire, antitoxin, oil, perfume, or soap. Subtract half the value of the created item from the total gp worth of raw materials you are carrying.

|Activity|DC|
|---|---|
|Create a puff of thick smoke|10|
|Identify a poison|10|
|Identify a substance|15|
|Start a fire|15|
|Neutralize acid|20|
