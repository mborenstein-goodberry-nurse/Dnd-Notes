---
type: Equipment
---
Calligraphy treats writing as a delicate, beautiful art. Calligraphers produce text that is pleasing to the eye, using a style that is difficult to forge. Their supplies also give them some ability to examine scripts and determine if they are legitimate, since a calligrapher's training involves long hours of studying writing and attempting to replicate its style and design.

**_Components._** Calligrapher's supplies include ink, a dozen sheets of parchment, and three quills.

**_[[Arcana]]._** Although calligraphy is of little help in deciphering the content of magical writings, proficiency with these supplies can aid in identifying who wrote a script of a magical nature.

**_[[History]]._** This tool proficiency can augment the benefit of successful checks made to analyze or investigate ancient writings, scrolls, or other texts, including runes etched in stone or messages in frescoes or other displays.

**_Decipher Treasure Map._** This tool proficiency grants you expertise in examining maps. You can make an [[Intelligence]] check to determine a map's age, whether a map includes any hidden messages, or similar facts.

|Activity|DC|
|---|---|
|Identify writer of nonmagical script|10|
|Determine writer's state of mind|15|
|Spot forged text|15|
|Forge a signature|20|