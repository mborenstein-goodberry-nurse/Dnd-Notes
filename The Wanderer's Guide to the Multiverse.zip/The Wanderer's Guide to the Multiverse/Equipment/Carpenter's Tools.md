---
type: Equipment
---
Skill at carpentry enables a character to construct wooden structures. A carpenter can build a house, a shack, a wooden cabinet, or similar items.

**_Components._** Carpenter's tools include a saw, a hammer, nails, a hatchet, a square, a ruler, an adze, a plane, and a chisel.

**_[[History]]._** This tool proficiency aids you in identifying the use and the origin of wooden buildings and other large wooden objects.

**_[[Investigation]]._** You gain additional insight when inspecting areas within wooden structures, because you know tricks of construction that can conceal areas from discovery.

**_[[Perception]]._** You can spot irregularities in wooden walls or floors, making it easier to find trap doors and secret passages.

**_[[Stealth]]._** You can quickly assess the weak spots in a wooden floor, making it easier to avoid the places that creak and groan when they're stepped on.

**_Fortify._** With 1 minute of work and raw materials, you can make a door or window harder to force open. Increase the DC needed to open it by 5.

**_Temporary Shelter._** As part of a long rest, you can construct a lean-to or a similar shelter to keep your group dry and in the shade for the duration of the rest. Because it was fashioned quickly from whatever wood was available, the shelter collapses 1d3 days after being assembled.

|Activity|DC|
|---|---|
|Build a simple wooden structure|10|
|Design a complex wooden structure|15|
|Find a weak point in a wooden wall|15|
|Pry apart a door|20|