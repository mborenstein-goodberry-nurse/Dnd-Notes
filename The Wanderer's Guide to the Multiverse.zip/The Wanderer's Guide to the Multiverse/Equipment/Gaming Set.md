---
type: Equipment
---
Proficiency with a gaming set applies to one type of game, such as Three-Dragon Ante or games of chance that use dice.

**_Components._** A gaming set has all the pieces needed to play a specific game or type of game, such as a complete deck of cards or a board and tokens.

**_[[History]]._** Your mastery of a game includes knowledge of its history, as well as of important events it was connected to or prominent historical figures involved with it.

**_[[Insight]]._** Playing games with someone is a good way to gain understanding of their personality, granting you a better ability to discern their lies from their truths and read their mood.

**_[[Sleight of Hand]]._** Sleight of Hand is a useful skill for cheating at a game, as it allows you to swap pieces, palm cards, or alter a die roll. Alternatively, engrossing a target in a game by manipulating the components with dexterous movements is a great distraction for a pickpocketing attempt.

| Activity                                    | DC  |
| ------------------------------------------- | --- |
| Catch a player cheating                     | 15  |
| Gain insight into an opponent's personality | 15  |