When you take your action on your turn, you can take one of the actions presented here, an action you gained from your class or a special feature, or an action that you improvise. Many monsters have action options of their own in their stat blocks.  
  
When you describe an action not detailed elsewhere in the rules, the GM tells you whether that action is possible and what kind of roll you need to make, if any, to determine success or failure.  
  

### Attack

The most common action to take in combat is the Attack action, whether you are swinging a sword, firing an arrow from a bow, or brawling with your fists.  
With this action, you make one melee or ranged attack. See the “[[Combat#Making an Attack|Making an Attack]]” section for the rules that govern attacks.  
  
Certain features, such as the [[Fighter#Extra Attack|Extra Attack]] feature of the [[Fighter]], allow you to make more than one attack with this action.  
  

### Cast a Spell

Spellcasters such as [[Wizard|wizards]] and [[Cleric|clerics]], as well as many monsters, have access to spells and can use them to great effect in combat. Each spell has a [[Spellcasting#Casting Time|casting time]], which specifies whether the caster must use an action, a [[Reaction]], minutes, or even hours to cast the spell. [[Spellcasting#Casting Time|Casting a spell]] is, therefore, not necessarily an action. Most spells do have a casting time of 1 action, so a spellcaster often uses his or her action in combat to cast such a spell.  
  

### Dash

When you take the Dash action, you gain extra [[Movement]] for the current turn. The increase equals your [[Speed]], after applying any modifiers. With a speed of 30 feet, for example, you can move up to 60 feet on your turn if you [[Dash]].  
Any increase or decrease to your speed changes this additional movement by the same amount. If your speed of 30 feet is reduced to 15 feet, for instance, you can move up to 30 feet this turn if you dash.  
  

### Disengage

If you take the Disengage action, your [[Movement]] doesn’t provoke [[Opportunity Attack|Opportunity Attacks]] for the rest of the turn.  
  

### Dodge

When you take the Dodge action, you focus entirely on avoiding [[Attack|attacks]]. Until the start of your next turn, any attack roll made against you has [[Disadvantage]] if you can see the attacker, and you make [[Dexterity]] saving throws with [[Advantage]]. You lose this benefit if you are [[Incapacitated]] (as explained in [[Conditions]]), or if your speed drops to 0.  
  

### Help

You can lend your aid to another creature in the completion of a task. When you take the Help action, the creature you aid gains [[Advantage]] on the next ability check it makes to perform the task you are helping with, provided that it makes the check before the start of your next turn.  
  
Alternatively, you can aid a friendly creature in attacking a creature within 5 feet of you. You feint, distract the target, or in some other way team up to make your ally’s attack more effective. If your ally attacks the target before your next turn, the first attack roll is made with [[Advantage]].  
  

### Hide

When you take the Hide action, you make a [[Stealth|Dexterity (Stealth)]] check in an attempt to hide, following the rules for [[Hiding]]. If you succeed, you gain certain benefits, as described in the “[Unseen Attackers and Targets](https://roll20.net/compendium/dnd5e/Rules:Combat?expansion=34047#toc_35)” section.  
  

### Ready

Sometimes you want to get the jump on a foe or wait for a particular circumstance before you act. To do so, you can take the Ready action on your turn, which lets you act using your [[Reaction]] before the start of your next turn.  
First, you decide what perceivable circumstance will trigger your reaction. Then, you choose the action you will take in response to that trigger, or you choose to [[Movement|move]] up to your speed in response to it. Examples include “If the cultist steps on the trapdoor, I’ll pull the lever that opens it,” and “If the Goblin steps next to me, I move away.”  
  
When the trigger occurs, you can either take your reaction right after the trigger finishes or ignore the trigger. Remember that you can take only one reaction per round.  
  
When you ready a spell, you cast it as normal but hold its energy, which you release with your reaction when the trigger occurs. To be readied, a spell must have a casting time of 1 [[Action]], and holding onto the spell’s magic requires [[Concentration]]. If your [[Concentration]] is broken, the spell dissipates without taking effect. For example, if you are concentrating on the _[[Web]]_ spell and ready _[[Magic Missile]]_, your _[[Web]]_ spell ends, and if you take damage before you release _[[Magic Missile]]_ with your [[Reaction]], your [[Concentration]] might be broken.  
  

### Search

When you take the Search action, you devote your attention to finding something. Depending on the nature of your search, the GM might have you make a [[Perception|Wisdom (Perception)]] or an [[Investigation|Intelligence (Investigation)]] check.  
  

### Use an Object

You normally interact with an object while doing something else, such as when you draw a sword as part of an attack. When an object requires your action for its use, you take the Use an Object action. This action is also useful when you want to interact with more than one object on your turn.