Of all the armor categories, heavy armor offers the best protection. These suits of armor cover the entire body and are designed to stop a wide range of attacks. Only proficient warriors can manage their weight and bulk.

Heavy armor doesn't let you add your Dexterity modifier to your Armor Class, but it also doesn't penalize you if your Dexterity modifier is negative.

| Armor            | Cost     | Armor Class (AC)          | Strength | Stealth      | Weight |
|------------------|----------|---------------------------|----------|--------------|--------|
| **Heavy Armor**  |          |                           |          |              |        |
| Ring mail        | 30 gp    | 14                        | -        | Disadvantage | 40 lb. |
| Chain mail       | 75 gp    | 16                        | Str 13   | Disadvantage | 55 lb. |
| Splint           | 200 gp   | 17                        | Str 15   | Disadvantage | 60 lb. |
| Plate            | 1,500 gp | 18                        | Str 15   | Disadvantage | 65 lb. |
| Shield           | 10 gp    | +2                        | -        | -            | 6 lb.  |
