The best way to save a creature with 0 hit points is to heal it. If healing is unavailable, the creature can at least be stabilized so that it isn’t killed by a failed [[Death Saving Throw]].  
  
You can use your action to administer first aid to an [[Unconscious]] creature and attempt to stabilize it, which requires a successful DC 10 [[Medicine|Wisdom (Medicine)]] check.   
  
A **stable** creature doesn’t make [[Death Saving Throw|death saving throws]], even though it has 0 hit points, but it does remain unconscious. The creature stops being stable, and must start making [[Death Saving Throw|death saving throws]] again, if it takes any damage. A stable creature that isn’t healed regains 1 hit point after 1d4 hours.