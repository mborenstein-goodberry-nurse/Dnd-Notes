---
aliases:
  - Ranged Attacks
  - Ranged Weapon Attack
  - Ranged Weapon Attacks
---
When you make a ranged attack, you fire a bow or a crossbow, hurl a handaxe, or otherwise send projectiles to strike a foe at a distance. A monster might shoot spines from its tail. Many spells also involve making a ranged attack.  
  
#### Range

You can make ranged attacks only against targets within a specified range.  
If a ranged attack, such as one made with a spell, has a single range, you can’t attack a target beyond this range.  
  
Some ranged attacks, such as those made with a longbow or a shortbow, have two ranges. The smaller number is the normal range, and the larger number is the long range. Your attack roll has [[Disadvantage]] when your target is beyond normal range, and you can’t attack a target beyond the long range.  
  

#### Ranged Attacks in Close Combat

Aiming a ranged attack is more difficult when a foe is next to you. When you make a ranged attack with a weapon, a spell, or some other means, you have [[Disadvantage]] on the attack roll if you are within 5 feet of a hostile creature who can see you and who isn’t [[Incapacitated]].
