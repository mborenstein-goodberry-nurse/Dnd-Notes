---
type: Background
---
**_You understand wealth, power, and privilege. You carry a noble title, and your family owns land, collects taxes, and wields significant political influence. You might be a pampered aristocrat unfamiliar with work or discomfort, a former merchant just elevated to the nobility, or a disinherited scoundrel with a disproportionate sense of entitlement. Or you could be an honest, hard-working landowner who cares deeply about the people who live and work on your land, keenly aware of your responsibility to them._**

**_Work with your DM to come up with an appropriate title and determine how much authority that title carries. A noble title doesn't stand on its own-it's connected to an entire family, and whatever title you hold, you will pass it down to your own children. Not only do you need to determine your noble title, but you should also work with the DM to describe your family and their influence on you._**

**_Is your family old and established, or was your title only recently bestowed? How much influence do they wield, and over what area? What kind of reputation does your family have among the other aristocrats of the region? How do the common people regard them?_**

**_What's your position in the family? Are you the heir to the head of the family? Have you already inherited the title? How do you feel about that responsibility? Or are you so far down the line of inheritance that no one cares what you do, as long as you don't embarrass the family? How does the head of your family feel about your adventuring career? Are you in your family's good graces, or shunned by the rest of your family?_**

**_Does your family have a coat of arms? An insignia you might wear on a signet ring? Particular colors you wear all the time? An animal you regard as a symbol of your line or even a spiritual member of the family?_**

**_These details help establish your family and your title as features of the world of the campaign._**

Source: Player's Handbook

**Skill Proficiencies:** [[History]], [[Persuasion]]  
**Tool Proficiencies:** One type of [[Gaming Set]]  
**Languages:** [[Languages|One of your choice]]  
**Equipment:** A set of fine clothes, a signet ring, a scroll of pedigree, and a purse containing 25gp

# Variants

## Noble: Knight

A knighthood is among the lowest noble titles in most societies, but it can be a path to higher status. If you wish to be a knight, choose the Retainers feature below instead of the Position of Privilege feature. One of your commoner retainers is replaced by a noble who serves as your squire, aiding you in exchange for training on his or her own path to knighthood. Your two remaining retainers might include a groom to care for your horse and a servant who polishes your armor (and even helps you put it on).

As an emblem of chivalry and the ideals of courtly love, you might include among your equipment a banner or other token from a noble lord or lady to whom you have given your heart – in a chaste sort of devotion. (This person could be your bond.)

## Variant Feature: Retainers

If your character has a noble background, you may select this background feature instead of Position of Privilege.

You have the service of three retainers loyal to your family. These retainers can be attendants or messengers, and one might be a majordomo. Your retainers are commoners who can perform mundane tasks for you, but they do not fight for you, will not follow you into obviously dangerous areas (such as dungeons), and will leave if they are frequently endangered or abused.

# Features

## Position of Privilege

Thanks to your noble birth, people are inclined to think the best of you. You are welcome in high society, and people assume you have the right to be wherever you are. The common folk make every effort to accommodate you and avoid your displeasure, and other people of high birth treat you as a member of the same social sphere. You can secure an audience with a local noble if you need to.

# Suggested Characteristics

Nobles are born and raised to a very different lifestyle than most people ever experience, and their personalities reflect that upbringing. A noble title comes with a plethora of bonds –responsibilities to family, to other nobles (including the sovereign), to the people entrusted to the family's care, or even to the title itself. But this responsibility is often a good way to undermine a noble.

## Personality Traits

|d8|Personality Trait|
|---|---|
|1|My eloquent flattery makes everyone I talk to feel like the most wonderful and important person in the world.|
|2|The common folk love me for my kindness and generosity.|
|3|No one could doubt by looking at my regal bearing that I am a cut above the unwashed masses.|
|4|I take great pains to always look my best and follow the latest fashions.|
|5|I don't like to get my hands dirty, and I won't be caught dead in unsuitable accommodations.|
|6|Despite my noble birth, I do not place myself above other folk. We all have the same blood.|
|7|My favor, once lost, is lost forever.|
|8|If you do me an injury, I will crush you, ruin your name, and salt your fields.|

## Ideals

|d6|Ideal|
|---|---|
|1|**Respect.** Respect is due to me because of my position, but all people regardless of station deserve to be treated with dignity. (Good)|
|2|**Responsibility.** It is my duty to respect the authority of those above me, just as those below me must respect mine. (Lawful)|
|3|**Independence.** I must prove that I can handle myself without the coddling of my family. (Chaotic)|
|4|**Power.** If I can attain more power, no one will tell me what to do. (Evil)|
|5|**Family.** Blood runs thicker than water. (Any)|
|6|**Noble Obligation.** It is my duty to protect and care for the people beneath me. (Good)|

## Bonds

|d6|Bond|
|---|---|
|1|I will face any challenge to win the approval of my family.|
|2|My house's alliance with another noble family must be sustained at all costs.|
|3|Nothing is more important than the other members of my family.|
|4|I am in love with the heir of a family that my family despises.|
|5|My loyalty to my sovereign is unwavering.|
|6|The common folk must see me as a hero of the people.|

## Flaws

|d6|Flaw|
|---|---|
|1|I secretly believe that everyone is beneath me.|
|2|I hide a truly scandalous secret that could ruin my family forever.|
|3|I too often hear veiled insults and threats in every word addressed to me, and I'm quick to anger.|
|4|I have an insatiable desire for carnal pleasures.|
|5|In fact, the world does revolve around me.|
|6|By my words and actions, I often bring shame to my family.|