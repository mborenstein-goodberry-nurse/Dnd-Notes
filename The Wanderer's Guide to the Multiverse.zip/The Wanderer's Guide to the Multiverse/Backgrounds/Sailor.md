---
type: Background
---
**_You sailed on a seagoing vessel for years. In that time, you faced down mighty storms, monsters of the deep, and those who wanted to sink your craft to the bottomless depths. Your first love is the distant line of the horizon, but the time has come to try your hand at something new._**

**_Discuss the nature of the ship you previously sailed with your DM. Was it a merchant ship, a naval vessel, a ship of discovery, or a pirate ship? How famous (or infamous) is it? Is it widely traveled? Is it still sailing, or is it missing and presumed lost with all hands?_**

**_What were your duties on board – boatswain, captain, navigator, cook, or some other position? Who were the captain and first mate? Did you leave your ship on good terms with your fellows, or on the run?_**

Source: Player's Handbook

**Skill Proficiencies:** [[Athletics]], [[Perception]]  
**Tool Proficiencies:** [[Navigator's Tools]], [[Vehicles (Water)]] 
**Languages:** None  
**Equipment:** A belaying pin (club), 50 feet of silk rope, a lucky charm such as a rabbit foot or a small stone with a hole in the center (or you may roll for a random trinket on the [[Trinkets]] table in chapter 5), a set of common clothes, and a pouch containing 10gp

# Variants

## Pirate

You spent your youth under the sway of a dread pirate, a ruthless cutthroat who taught you how to survive in a world of sharks and savages. You've indulged in larceny on the high seas and sent more than one deserving soul to a briny grave. Fear and bloodshed are no strangers to you, and you've garnered a somewhat unsavory reputation in many a port town.

If you decide that your sailing career involved piracy, you can choose the Bad Reputation feature below instead of the Ship's Passage feature.

# Features

## Ship's Passage

When you need to, you can secure free passage on a sailing ship for yourself and your adventuring companions. You might sail on the ship you served on, or another ship you have good relations with (perhaps one captained by a former crewmate). Because you're calling in a favor, you can't be certain of a schedule or route that will meet your every need. Your DM will determine how long it takes to get where you need to go. In return for your free passage, you and your companions are expected to assist the crew during the voyage.

## Alternative: Bad Reputation

If your character has a pirate background, you may select this background feature instead of Ship's Passage.

No matter where you go, people are afraid of you due to your reputation. When you are in a civilized settlement, you can get away with minor criminal offenses, such as refusing to pay for food at a tavern or breaking down doors at a local shop, since most people will not report your activity to the authorities.

# Suggested Characteristics

Sailors can be a rough lot, but the responsibilities of life on a ship make them generally reliable as well. Life aboard a ship shapes their outlook and forms their most important attachments.

## Personality Traits

|d8|Personality Trait|
|---|---|
|1|My friends know they can rely on me, no matter what.|
|2|I work hard so that I can play hard when the work is done.|
|3|I enjoy sailing into new ports and making new friends over a flagon of ale.|
|4|I stretch the truth for the sake of a good story.|
|5|To me, a tavern brawl is a nice way to get to know a new city.|
|6|I never pass up a friendly wager.|
|7|My language is as foul as an otyugh nest.|
|8|I like a job well done, especially if I can convince someone else to do it.|

## Ideals

|d6|Ideal|
|---|---|
|1|**Respect.** The thing that keeps a ship together is mutual respect between captain and crew. (Good)|
|2|**Fairness.** We all do the work, so we all share in the rewards. (Lawful)|
|3|**Freedom.** The sea is freedom-the freedom to go anywhere and do anything. (Chaotic)|
|4|**Mastery.** I'm a predator, and the other ships on the sea are my prey. (Evil)|
|5|**People.** I'm committed to my crewmates, not to ideals. (Neutral)|
|6|**Aspiration.** Someday I'll own my own ship and chart my own destiny. (Any)|

## Bonds

|d6|Bond|
|---|---|
|1|I'm loyal to my captain first, everything else second.|
|2|The ship is most important – crewmates and captains come and go.|
|3|I'll always remember my first ship.|
|4|In a harbor town, I have a paramour whose eyes nearly stole me from the sea.|
|5|I was cheated out of my fair share of the profits, and I want to get my due.|
|6|Ruthless pirates murdered my captain and crewmates, plundered our ship, and left me to die. Vengeance will be mine.|

## Flaws

|d6|Flaw|
|---|---|
|1|I follow orders, even if I think they're wrong.|
|2|I'll say anything to avoid having to do extra work.|
|3|Once someone questions my courage, I never back down no matter how dangerous the situation.|
|4|Once I start drinking, it's hard for me to stop.|
|5|I can't help but pocket loose coins and other trinkets I come across.|
|6|My pride will probably lead to my destruction.|