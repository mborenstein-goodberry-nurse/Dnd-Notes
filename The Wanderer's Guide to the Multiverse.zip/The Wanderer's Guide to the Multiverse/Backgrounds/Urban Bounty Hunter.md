---
type: Background
---
**_Before you became an adventurer, your life was already full of conflict and excitement, because you made a living tracking down people for pay. Unlike some people who collect bounties, though, you aren't a savage who follows quarry into or through the wilderness. You're involved in a lucrative trade, in the place where you live, that routinely tests your skills and survival instincts. What's more, you aren't alone, as a bounty hunter in the wild would be: you routinely interact with both the criminal subculture and other bounty hunters, maintaining contacts in both areas to help you succeed._**

**_You might be a cunning thief-catcher, prowling the rooftops to catch one of the myriad burglars of the city. Perhaps you are someone who has your ear to the street, aware of the doings of thieves' guilds and street gangs. You might be a "velvet mask" bounty hunter, one who blends in with high society and noble circles in order to catch the criminals that prey on the rich, whether pickpockets or con artists. The community where you plied your trade might have been one of Faenûn's great metropolises, such as Waterdeep or Baldur's Gate, or a less populous location, perhaps Luskan or Yartar – any place that's large enough to have a steady supply of potential quarries._**

**_As a member of an adventuring party, you might find it more difficult to pursue a personal agenda that doesn't fit with the group's objectives – but on the other hand, you can take down much more formidable targets with the help of your companions._**

Source: Sword Coast Adventurer's Guide

**Skill Proficiencies:** Choose two from among [[Deception]], [[Insight]], [[Persuasion]], and [[Stealth]]  
**Tool Proficiencies:** Choose two from among one type of [[Gaming Set]], one [[Musical Instrument]], and [[Thieves' Tools]]  
**Languages:** None  
**Equipment:** A set of clothes appropriate to your duties and a pouch containing 20gp

# Features

## Ear to the Ground

You are in frequent contact with people in the segment of society that your chosen quarries move through. These people might be associated with the criminal underworld, the rough-and-tumble folk of the streets, or members of high society. This connection comes in the form of a contact in any city you visit, a person who provides information about the people and places of the local area.

# Suggested Characteristics

Use the tables for the [[The Wanderer's Guide to the Multiverse/Backgrounds/Criminal#Suggested Characteristics|Criminal]] background as the basis for your traits and motivations, modifying the entries when appropriate to suit your identity.

For instance, your bond might involve other bounty hunters or the organizations or individuals that employ you. Your ideal could be associated with your determination always to catch your quarry or your desire to maintain your reputation for being dependable.