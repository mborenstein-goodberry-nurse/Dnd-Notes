---
type: Background
---
**_The Stout Folk are well known for their artisanship and the worth of their handiworks, and you have been trained in that ancient tradition. For years you labored under a dwarf master of the craft, enduring long hours and dismissive, sour-tempered treatment in order to gain the fine skills you possess today._**

**_You are most likely a dwarf, but not necessarily- particularly in the North, the shield dwarf clans learned long ago that only proud fools who are more concerned for their egos than their craft turn away promising apprentices, even those of other races. If you aren't a dwarf, however, you have taken a solemn oath never to take on an apprentice in the craft: it is not for non-dwarves to pass on the skills of Moradin's favored children. You would have no difficulty, however, finding a dwarf master who was willing to receive potential apprentices who came with your recommendation._**

Source: Sword Coast Adventurer's Guide

**Skill Proficiencies:** [[History]], [[Insight]]  
**Tool Proficiencies:** One type of [[Artisan's Tools]]  
**Languages:** [[Languages|Dwarvish]] or one other of your choice if you already speak [[Languages|Dwarvish]]  
**Equipment:** A set of [[Artisan's Tools]] with which you are proficient, a maker's mark chisel used to mark your handiwork with the symbol of the clan of crafters you learned your skill from, a set of traveler's clothes, and a pouch containing 5gp and a gem worth 10gp

# Features

## Respect of the Stout Folk

As well respected as clan crafters are among outsiders, no one esteems them quite so highly as dwarves do. You always have free room and board in any place where shield dwarves or gold dwarves dwell, and the individuals in such a settlement might vie among themselves to determine who can offer you (and possibly your compatriots) the finest accommodations and assistance.

# Suggested Characteristics

Use the tables for the [[Guild Artisan]] background as the basis for your traits and motivations, modifying the entries when appropriate to suit your identity. (For instance, consider the words "guild" and "clan" to be interchangeable.)

Your bond is almost certainly related to the master or the clan that taught you, or else to the work that you produce. Your ideal might have to do with maintaining the high quality of your work or preserving the dwarven traditions of craftsmanship.