---
type: Background
---
**_You grew up in the wilds, far from civilization and the comforts of town and technology. You've witnessed the migration of herds larger than forests, survived weather more extreme than any city-dweller could comprehend, and enjoyed the solitude of being the only thinking creature for miles in any direction. The wilds are in your blood, whether you were a nomad, an explorer, a recluse, a hunter-gatherer, or even a marauder. Even in places where you don't know the specific features of the terrain, you know the ways of the wild._**

Source: Player's Handbook

**Skill Proficiencies:** [[Athletics]], [[Survival]]  
**Tool Proficiencies:** One type of [[Musical Instrument]]  
**Languages:** [[Languages|One of your choice]]  
**Equipment:** A staff, a hunting trap, a trophy from an animal you killed, a set of traveler's clothes, and a pouch containing 10gp

# Features

## Origin

You've been to strange places and seen things that others cannot begin to fathom. Consider some of the distant lands you have visited, and how they impacted you. You can roll on the following table to determine your occupation during your time in the wild, or choose one that best fits your character.

|d10|Origin|
|---|---|
|1|Forester|
|2|Trapper|
|3|Homesteader|
|4|Guide|
|5|Exile or outcast|
|6|Bounty hunter|
|7|Pilgrim|
|8|Tribal nomad|
|9|Hunter-gatherer|
|10|Tribal marauder|

## Wanderer

You have an excellent memory for maps and geography, and you can always recall the general layout of terrain, settlements, and other features around you. In addition, you can find food and fresh water for yourself and up to five other people each day, provided that the land offers berries, small game, water, and so forth.

# Suggested Characteristics

Often considered rude and uncouth among civilized folk, outlanders have little respect for the niceties of life in the cities. The ties of tribe, clan, family, and the natural world of which they are a part are the most important bonds to most outlanders.

## Personality Traits

|d8|Personality Trait|
|---|---|
|1|I'm driven by a wanderlust that led me away from home.|
|2|I watch over my friends as if they were a litter of newborn pups.|
|3|I once ran twenty-five miles without stopping to warn my clan of an approaching orc horde. I'd do it again if I had to.|
|4|I have a lesson for every situation, drawn from observing nature.|
|5|I place no stock in wealthy or well-mannered folk. Money and manners won't save you from a hungry owlbear.|
|6|I'm always picking things up, absently fiddling with them, and sometimes accidentally breaking them.|
|7|I feel far more comfortable around animals than people.|
|8|I was, in fact, raised by wolves.|

## Ideals

|d6|Ideal|
|---|---|
|1|**Change.** Life is like the seasons, in constant change, and we must change with it. (Chaotic)|
|2|**Greater Good.** It is each person's responsibility to make the most happiness for the whole tribe. (Good)|
|3|**Honor.** If I dishonor myself, I dishonor my whole clan. (Lawful)|
|4|**Might.** The strongest are meant to rule. (Evil)|
|5|**Nature.** The natural world is more important than all the constructs of civilization. (Neutral)|
|6|**Glory.** I must earn glory in battle, for myself and my clan. (Any)|

## Bonds

|d6|Bond|
|---|---|
|1|My family, clan, or tribe is the most important thing in my life, even when they are far from me.|
|2|An injury to the unspoiled wilderness of my home is an injury to me.|
|3|I will bring terrible wrath down on the evildoers who destroyed my homeland.|
|4|I am the last of my tribe, and it is up to me to ensure their names enter legend.|
|5|I suffer awful visions of a coming disaster and will do anything to prevent it.|
|6|It is my duty to provide children to sustain my tribe.|

## Flaws

|d6|Flaw|
|---|---|
|1|I am too enamored of ale, wine, and other intoxicants.|
|2|There's no room for caution in a life lived to the fullest.|
|3|I remember every insult I've received and nurse a silent resentment toward anyone who's ever wronged me.|
|4|I am slow to trust members of other races, tribes, and societies.|
|5|Violence is my answer to almost any challenge.|
|6|Don't expect me to save those who can't save themselves. It is nature's way that the strong thrive and the weak perish.|
