---
type: Background
---
**_You have sworn fealty to a dragonmarked house. If you have a dragonmark, you're likely a member of one of the house's influential families; otherwise you're an outsider who hopes to make your fortune through the house. Your main task is to serve as the eyes of your house, but you could be called on at any time to act as its hand. Such missions can be perilous but lucrative._**

Source: Eberron - Rising from the Last War

**Skill Proficiencies:** [[Investigation]], [[Persuasion]]  
**Tool Proficiencies:** Two proficiencies from the House Tool Proficiencies table  
**Languages:** None  
**Equipment:** A set of fine clothes, the signet ring of your house, identification papers, and a purse containing 20gp

| Your House | House Tool Proficiencies                                                         |     |
| ---------- | -------------------------------------------------------------------------------- | --- |
| Cannith    | [[Alchemist's Supplies]] and [[Tinker's Tools]]                                  |     |
| Deneith    | One [[Gaming Set]] and [[Vehicles (Land)]]                                       |     |
| Ghallanda  | [[Brewer's Supplies]] and [[Cook's Utensils]]                                    |     |
| Jorasco    | [[Alchemist's Supplies]] and [[Herbalism Kit]]                                   |     |
| Kundarak   | [[Thieves' Tools]] and [[Tinker's Tools]]                                        |     |
| Lyrandar   | [[Navigator's Tools]] and Vehicles (Air and [[Vehicles (Land or Water)\|Water]]) |     |
| Medani     | [[Disguise Kit]] and [[Thieves' Tools]]                                          |     |
| Orien      | One [[Gaming Set]] and [[Vehicles (Land or Water)\|Vehicles (Land)]]             |     |
| Phiarlan   | [[Disguise Kit]] and one [[Musical Instrument]]                                  |     |
| Sivis      | [[Calligrapher's Supplies]] and [[Forgery Kit]]                                  |     |
| Tharashk   | One [[Gaming Set]] and [[Thieves' Tools]]                                        |     |
| Thuranni   | One [[Musical Instrument]] and [[Poisoner's Kit]]                                |     |
| Vadalis    | [[Herbalism Kit]] and [[Vehicles (Land or Water)\|Vehicles (Land)]]              |     |

# Features

## Role

You always gather information for your house, but when a baron gives you a specific mission, what sort of work do you do? The House Agent Role table gives possibilities.

|d8|House Agent Role|
|---|---|
|1|Acquisition|
|2|Investigation|
|3|Research & Development|
|4|Security|
|5|Intimidation|
|6|Exploration|
|7|Negotiation|
|8|Covert Operations|

## House Connection

As an agent of your house, you can always get food and lodging for yourself and your friends at a house enclave. When the house assigns you a mission, it will usually provide you with the necessary supplies and transportation. Beyond this, you have many old friends, mentors, and rivals in your house, and you may encounter one of them when you interact with a house business. The degree to which such acquaintances are willing to help you depends on your current standing in your house.

# Suggested Characteristics

House agents are diverse. Consider the house you serve and the work you do when choosing characteristics.

## Personality Traits

|d6|Personality Trait|
|---|---|
|1|I'm always looking to improve efficiency.|
|2|I love to share trivia about my house's business.|
|3|I never forget an insult against me or my house.|
|4|I'm enthusiastic about everything my house does.|
|5|I represent my house and take pride in my looks.|
|6|I'm critical of monarchies and limits on the houses.|

## Ideals

|d6|Ideal|
|---|---|
|1|**Common Good.** My house serves a vital function, and its prosperity will help everyone. (Good)|
|2|**Tradition.** I uphold traditions of my house and bring honor to my family. (Lawful)|
|3|**Innovation.** Abandon old traditions and find better ways to do things. (Chaotic)|
|4|**Power.** I want to ensure the prosperity of my house and wield its power myself. (Evil)|
|5|**Discovery.** I want to learn all I can, both for my house and for my own curiosity. (Any)|
|6|**Comfort.** I want to ensure that me and mine enjoy the best things in life. (Any)|

## Bonds

|d6|Bond|
|---|---|
|1|My house is my family. I would do anything for it.|
|2|I love someone from another house, but the relationship is forbidden.|
|3|Someone I love was killed by a rival faction within my house, and I will have revenge.|
|4|I don't care about the house as a whole, but I would do anything for my old mentor.|
|5|My house must evolve, and I'll lead the evolution.|
|6|I'm determined to impress the leaders of my house, and to become a leader myself.|

## Flaws

|d6|Flaw|
|---|---|
|1|I'm fixated on following official protocols.|
|2|I'm obsessed with conspiracy theories and worried about secret societies and hidden demons.|
|3|My house and blood line make me the best!|
|4|My secret could get me expelled from my house.|
|5|My religious beliefs aren't widespread in my house.|
|6|I'm working for a hidden faction in my house that gives me secret assignments.|