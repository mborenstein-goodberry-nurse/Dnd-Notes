When you make your character, you can roll once on the Trinkets table to gain a trinket, a simple item lightly touched by mystery. The DM might also use this table. It can help stock a room in a dungeon or fill a creature's pockets.

*Source: Curse of Strahd*

| d100   | Trinket                                                                                               |
| ------ | ----------------------------------------------------------------------------------------------------- |
| 1-2    | A picture you drew as a child of your imaginary friend                                                |
| 3-4    | A lock that opens when blood is dripped in its keyhole                                                |
| 5-6    | Clothes stolen from a scarecrow                                                                       |
| 7-8    | A spinning top carved with four faces: happy, sad, wrathful, and dead                                 |
| 9-10   | The necklace of a sibling who died on the day you were born                                           |
| 11-12  | A wig from someone executed by beheading                                                              |
| 13-14  | The unopened letter to you from your dying father                                                     |
| 15-16  | A pocket watch that runs backward for an hour every midnight                                          |
| 17-18  | A winter coat stolen from a dying soldier                                                             |
| 19-20  | A bottle of invisible ink that can only be read at sunset                                             |
| 21-22  | A wineskin that refills when interred with a dead person for a night                                  |
| 23-34  | A set of silverware used by a king for his last meal                                                  |
| 25-26  | A spyglass that always shows the world suffering a terrible storm                                     |
| 27-28  | A cameo with the profile's face scratched away                                                        |
| 29-30  | A lantern with a black candle that never runs out and that burns with green flame                     |
| 31-32  | A teacup from a child's tea set, stained with blood                                                   |
| 33-34  | A little black book that records your dreams, and yours alone, when you sleep                         |
| 35-36  | A necklace formed of the interlinked holy symbols of a dozen deities                                  |
| 37-38  | A hangman's noose that feels heavier than it should                                                   |
| 39-40  | A birdcage into which small birds fly but once inside never eat or leave                              |
| 41-42  | A lepidopterist's box filled dead moths with skulllike patterns on their wings                        |
| 43-44  | A jar of pickled ghouls' tongues                                                                      |
| 45-56  | The wooden hand of a notorious pirate                                                                 |
| 47-48  | An urn with the ashes of a dead relative                                                              |
| 49-50  | A hand mirror backed with a bronze depiction of a medusa                                              |
| 51-52  | Pallid leather gloves crafted with ivory fingernails                                                  |
| 53-54  | Dice made from the knuckles of a notorious charlatan                                                  |
| 55-56  | A ring of keys for forgotten locks                                                                    |
| 57-58  | Nails from the coffin of a murderer                                                                   |
| 59-60  | A key to the family crypt                                                                             |
| 61-62  | A bouquet of funerary flowers that always looks and smells fresh                                      |
| 63-64  | A switch used to discipline you as a child                                                            |
| 65-66  | A music box that plays by itself whenever someone holding it dances                                   |
| 67-68  | A walking cane with an iron ferrule that strikes sparks on stone                                      |
| 69-70  | A flag from a ship lost at sea                                                                        |
| 71-72  | Porcelain doll's head that always seems to be looking at you                                          |
| 73-74  | A wolf's head wrought in silver that is also a whistle                                                |
| 75-76  | A small mirror that shows a much older version of the viewer                                          |
| 77-78  | Small, worn book of children's nursery rhymes                                                         |
| 79-80  | A mummified raven claw                                                                                |
| 81-82  | A broken pendent of a silver dragon that's always cold to the touch                                   |
| 83-84  | A small locked box that quietly hums a lovely melody at night but you always forget it in the morning |
| 85-86  | An inkwell that makes one a little nauseous when staring at it                                        |
| 87-88  | An old little doll made from a dark, dense wood and missing a hand and a foot                         |
| 89-90  | A black executioner's hood                                                                            |
| 91-92  | A pouch made of flesh, with a sinew drawstring                                                        |
| 93-94  | A tiny spool of black thread that never runs out                                                      |
| 95-96  | A tiny clockwork figurine of a dancer that's missing a gear and doesn't work                          |
| 97-98  | A black wooden pipe that creates puffs of smoke that look like skulls                                 |
| 99-100 | A vial of perfume, the scent of which only certain creatures can detect                               |