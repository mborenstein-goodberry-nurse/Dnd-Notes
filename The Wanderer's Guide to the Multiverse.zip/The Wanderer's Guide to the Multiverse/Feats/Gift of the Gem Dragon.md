Source: Fizban's Treasury of Dragons

You’ve manifested some of the power of gem dragons, granting you the following benefits:

- **Ability Score Increase.** Increase your [[Intelligence]], [[Wisdom]], or [[Charisma]] score by 1, to a maximum of 20.

- **Telekinetic Reprisal.** When you take damage from a creature that is within 10 feet of you, you can use your [[Reaction]] to emanate telekinetic energy. The creature that dealt damage to you must make a [[Strength]] saving throw (DC equals 8 + your proficiency bonus + the ability modifier of the score increased by this feat). On a failed save, the creature takes 2d8 [[Force]] damage and is pushed up to 10 feet away from you. On a successful save, the creature takes half as much damage and isn’t pushed. You can use this [[Reaction]] a number of times equal to your proficiency bonus, and you regain all expended uses when you finish a [[Long Rest]].