Source: Tasha's Cauldron of Everything

_Prerequisite: Spellcasting or Pact Magic feature_

You've learned how to exert your will on your spells to alter how they function:

- You learn two [[Sorcerer#Metamagic|Metamagic options]] of your choice from the sorcerer class. You can use only one [[Sorcerer#Metamagic|Metamagic]] option on a spell when you cast it, unless the option says otherwise. Whenever you reach a level that grants the Ability Score Improvement feature, you can replace one of these [[Sorcerer#Metamagic|Metamagic]] options with another one from the sorcerer class.

- You gain 2 sorcery points to spend on [[Sorcerer#Metamagic|Metamagic]] (these points are added to any sorcery points you have from another source but can be used only on Metamagic). You regain all spent sorcery points when you finish a [[Long Rest]].
