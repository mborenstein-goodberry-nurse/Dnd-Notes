Source: Tasha's Cauldron of Everything

Your exposure to the Shadowfell's magic has changed you, granting you the following benefits:

- Increase your [[Intelligence]], [[Wisdom]], or [[Charisma]] score by 1, to a maximum of 20.

- You learn the [[Invisibility]] spell and one 1st-level spell of your choice. The 1st-level spell must be from the [[Illusion]] or [[Necromancy]] school of magic. You can cast each of these spells without expending a spell slot. Once you cast either of these spells in this way, you can't cast that spell in this way again until you finish a [[Long Rest]]. You can also cast these spells using spell slots you have of the appropriate level. The spells' spellcasting ability is the ability increased by this feat.