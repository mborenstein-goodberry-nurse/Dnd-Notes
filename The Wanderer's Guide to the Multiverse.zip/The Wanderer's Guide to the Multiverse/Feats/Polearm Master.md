Source: Player's Handbook

You gain the following benefits:

- When you take the [[Attack]] action and attack with only a glaive, halberd, quarterstaff, or spear, you can use a [[Bonus Action]] to make a melee attack with the opposite end of the weapon. This attack uses the same ability modifier as the primary attack. The weapon's damage die for this attack is a d4, and it deals [[Bludgeoning]] damage.

- While you are wielding a glaive, halberd, pike, quarterstaff, or spear, other creatures provoke an [[Opportunity Attack]] from you when they enter the reach you have with that weapon.