---
type: Feat
subtype: Normal
---
Source: Player's Handbook

Skilled at mimicry and dramatics, you gain the following benefits:

- Increase your [[Charisma]] score by 1, to a maximum of 20.

- You have an advantage on [[Deception|Charisma (Deception)]] and [[Performance|Charisma (Performance)]] checks when trying to pass yourself off as a different person.

- You can mimic the speech of another person or the sounds made by other creatures. You must have heard the person speaking, or heard the creature make the sound, for at least 1 minute. A successful [[Insight|Wisdom (Insight)]] check contested by your [[Deception|Charisma (Deception)]] check allows a listener to determine that the effect is faked.