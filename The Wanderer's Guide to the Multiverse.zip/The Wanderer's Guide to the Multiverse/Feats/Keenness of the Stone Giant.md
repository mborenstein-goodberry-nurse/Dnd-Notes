Source: Bigby Presents - Glory of the Giants

_Prerequisite: 4th Level, [[Strike of the Giants]] (Stone Strike) Feat_

You’ve manifested the physical talents emblematic of stone giants, granting you the following benefits:

- **Ability Score Increase.** Increase your [[Strength]], [[Constitution]], or [[Wisdom]] score by 1, to a maximum of 20.
- **Cavernous Sight.** You gain [[Darkvision]] with a range of 60 feet. If you already have darkvision from another source, its range increases by 60 feet.
- **Stone Throw.** As a [[Bonus Action]], you can take a rock and make a magical attack with it. The attack is a ranged spell attack with a range of 60 feet that uses the ability score you increased with this feat as the spellcasting ability. On a hit, the rock deals 1d10 [[Force]] damage, and the target must succeed on a [[Strength]] saving throw (DC equals 8 + your proficiency bonus + the spellcasting ability modifier) or have the [[Prone]] condition. You can use this [[Bonus Action]] a number of times equal to your proficiency bonus, and you regain all expended uses when you finish a [[Long Rest]].