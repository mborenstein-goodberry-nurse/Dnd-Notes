---
type: Feat
subtype: Normal
---
Source: Player's Handbook

You master fighting with two weapons, gaining the following benefits:

- You gain a +1 bonus to AC while you are wielding a separate melee weapon in each hand.

- You can use two-weapon fighting even when the one-handed melee weapons you are wielding aren't [[The Wanderer's Guide to the Multiverse/Dictionary/Light|light]].

- You can draw or stow two one-handed weapons when you would normally be able to draw or stow only one.