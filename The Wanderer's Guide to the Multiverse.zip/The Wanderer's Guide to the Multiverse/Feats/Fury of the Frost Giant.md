Source: Bigby Presents - Glory of the Giants

_Prerequisite: 4th Level, [[Strike of the Giants]] (Frost Strike) Feat_

You’ve manifested the icy might emblematic of frost giants, granting you the following benefits:

- **Ability Score Increase.** Increase your [[Strength]], [[Constitution]], or [[Wisdom]] score by 1, to a maximum of 20.
- **Born of Ice.** You have resistance to cold damage.
- **Frigid Retaliation.** Immediately after a creature you can see within 30 feet of you hits you with an [[Attack]] roll and deals damage, you can use your [[Reaction]] to retaliate with a conjured blast of ice. The creature must make a [[Constitution]] saving throw (DC equals 8 + your proficiency bonus + the modifier of the ability increased by this feat). On a failed save, the creature takes [[Cold]] damage equal to 1d8 + your proficiency bonus, and its speed is reduced to 0 until the end of its next turn. You can use this [[Reaction]] a number of times equal to your proficiency bonus, and you regain all expended uses when you finish a [[Long Rest]].