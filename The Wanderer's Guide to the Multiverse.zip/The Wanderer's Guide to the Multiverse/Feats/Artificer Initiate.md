---
type: Feat
subtype: Normal
---
Source: Tasha's Cauldron of Everything

You’ve learned some of an artificer’s inventiveness:

- You learn one cantrip of your choice from the [[Artificer Spells|Artificer Spell List]], and you learn one 1st-level spell of your choice from that list. [[Intelligence]] is your spellcasting ability for these spells.

- You can cast this feat's 1st-level spell without a spell slot, and you must finish a [[Long Rest]] before you can cast it in this way again. You can also cast the spell using any spell slots you have.

- You gain proficiency with one type of [[Artisan's Tools]] of your choice, and you can use that type of tool as a spellcasting focus for any spell you cast that uses [[Intelligence]] as its spellcasting ability. 