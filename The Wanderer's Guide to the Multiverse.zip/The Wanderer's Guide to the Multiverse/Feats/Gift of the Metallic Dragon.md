Source: Fizban's Treasury of Dragons

You’ve manifested some of the power of metallic dragons, granting you the following benefits:

- **Draconic Healing.** You learn the [[Cure Wounds]] spell. You can cast this spell without expending a spell slot. Once you cast this spell in this way, you can’t do so again until you finish a [[Long Rest]]. You can also cast this spell using spell slots you have. The spell’s spellcasting ability is [[Intelligence]], [[Wisdom]], or [[Charisma]] when you cast it with this feat (choose when you gain the feat).

- **Protective Wings.** You can manifest protective wings that can shield you or others. When you or another creature you can see within 5 feet of you is hit by an [[Attack]] roll, you can use your [[Reaction]] to manifest spectral wings from your back for a moment. You grant a bonus to the target’s AC equal to your proficiency bonus against that [[Attack]] roll, potentially causing it to miss. You can use this [[Reaction]] a number of times equal to your proficiency bonus, and you regain all expended uses when you finish a [[Long Rest]].