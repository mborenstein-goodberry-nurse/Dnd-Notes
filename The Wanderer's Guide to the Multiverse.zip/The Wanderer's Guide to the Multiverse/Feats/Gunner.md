Source: Tasha's Cauldron of Everything

You have a quick hand and keen eye when employing firearms, granting you the following benefits:

- Increase your [[Dexterity]] score by 1, to a maximum of 20.

- You gain proficiency with firearms (see “Firearms” in the **_Dungeon Master’s Guide_**).

- You ignore the loading property of firearms.

- Being within 5 feet of a hostile creature doesn't impose [[Disadvantage]] on your ranged attack rolls.