Source: Bigby Presents - Glory of the Giants

_Prerequisite: 4th Level, [[Strike of the Giants]] (Fire Strike) Feat_

You’ve manifested the fiery combat emblematic of fire giants, granting you the following benefits:

- **Ability Score Increase.** Increase your [[Strength]], [[Constitution]], or [[Wisdom]] score by 1, to a maximum of 20.

- **Born of Flame.** You have resistance to [[Fire]] damage.

- **Searing Ignition.** When you take the [[Attack]] action on your turn, you can replace a single attack with a magical burst of flame. Each creature of your choice in a 15-foot-radius sphere centered on you must make a [[Dexterity]] saving throw (DC equals 8 + your proficiency bonus + the modifier of the ability increased by this feat). On a failed save, a creature takes fire damage equal to 1d8 + your proficiency bonus, and it has the [[Blinded]] condition until the start of your next turn. On a successful save, the creature takes half as much damage only. You can use your Searing Ignition a number of times equal to your proficiency bonus (but no more than once per turn), and you regain all expended uses when you finish a [[Long Rest]].