Source: Player's Handbook

You have mastered ranged weapons and can make shots that others find impossible. You gain the following benefits:

- Attacking at [[Ranged Attack#Range|long range]] doesn't impose [[Disadvantage]] on your [[Ranged Attack|Ranged Weapon Attack]] rolls.

- Your [[Ranged Attack|Ranged Weapon Attacks]] ignore half and three-quarters cover.

- Before you make an attack with a ranged weapon that you are proficient with, you can choose to take a -5 penalty to the attack roll. If that attack hits, you add +10 to the attack's damage.