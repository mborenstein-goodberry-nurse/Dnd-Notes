Source: Player's Handbook

You have practiced extensively with a variety of weapons, gaining the following benefits:

- Increase your [[Strength]] or [[Dexterity]] score by 1, to a maximum of 20.

- You gain proficiency with four [[Weapons]] of your choice. Each one must be a simple or a martial weapon.