Source: Bigby Presents - Glory of the Giants

_Prerequisite: Spellcasting Feature or Rune Carver Background_

You’ve studied the magic of Giant runes, granting you the following benefits:

- **Comprehend Languages.** You learn the [[Comprehend Languages]] spell. You can cast this spell without expending a spell slot, and you must finish a [[Long Rest]] before you can cast it in this way again. You can also cast this spell using any spell slots you have.

- **Rune Magic.** You know a number of runes equal to half your proficiency bonus (rounded down), chosen from the [[#Rune Spells|Rune Spells table]]. Whenever you finish a [[Long Rest]], you can inscribe each rune you know onto one nonmagical weapon, armor, piece of clothing, or other object you touch. You temporarily learn the 1st-level spells that correspond to the runes you inscribed, as specified on the Rune Spells table, and you know those spells until you finish a long rest, when the runes fade. While you are wearing or carrying any rune-marked object, you can cast the spells associated with those runes using any spell slots you have.  
    You can also invoke a rune inscribed on an object you are wearing or carrying and cast its associated spell without expending a spell slot or using material components. Once you cast the spell in this way, you can’t do so again until you finish a long rest. Your spellcasting ability for this feat is [[Intelligence]], [[Wisdom]], or [[Charisma]] (choose when you select this feat).  
    Each time you gain a level, you can replace one of the runes you know with another one from the Rune Spells table.

##### Rune Spells

| Rune     | Spell                  |
| -------- | ---------------------- |
| Cloud    | [[Fog Cloud]]          |
| Death    | [[Inflict Wounds]]     |
| Dragon   | [[Chromatic Orb]]      |
| Enemy    | [[Disguise Self]]      |
| Fire     | [[Burning Hands]]      |
| Friend   | [[Speak with Animals]] |
| Frost    | [[Armor of Agathys]]   |
| Hill     | [[Goodberry]]          |
| Journey  | [[Longstrider]]        |
| King     | [[Command]]            |
| Mountain | [[Entangle]]           |
| Stone    | [[Sanctuary]]          |
| Storm    | [[Thunderwave]]        |
