Source: Tasha's Cauldron of Everything

You learn to move things with your mind, granting you the following benefits:

- Increase your [[Intelligence]], [[Wisdom]], or [[Charisma]] score by 1, to a maximum of 20.

- You learn the _[[Mage Hand]]_ cantrip. You can cast it without verbal or somatic components, and you can make the spectral hand [[Invisible]]. If you already know this spell, its range increases by 30 feet when you cast it. Its spellcasting ability is the ability increased by this feat.

- As a [[Bonus Action]], you can try to telekinetically shove one creature you can see within 30 feet of you. When you do so, the target must succeed on a [[Strength]] saving throw (DC 8 + your proficiency bonus + the ability modifier of the score increased by this feat) or be moved 5 feet toward or away from you. A creature can willingly fail this save.