Source: Player's Handbook

You use shields not just for protection but also for offense. You gain the following benefits while you are wielding a [[The Wanderer's Guide to the Multiverse/Equipment/Shield]]:

- If you take the [[Attack]] action on your turn, you can use a [[Bonus Action]] to try to [[Shove]] a creature within 5 feet of you with your shield.

- If you aren't [[Incapacitated]], you can add your shield's AC bonus to any [[Dexterity]] saving throw you make against a spell or other harmful effect that targets only you.

- If you are subjected to an effect that allows you to make a [[Dexterity]] saving throw to take only half damage, you can use your reaction to take no damage if you succeed on the saving throw, interposing your shield between yourself and the source of the effect.